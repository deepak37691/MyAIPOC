const fs=require('fs');
const p='automation-ui/public/app.js';
const s=fs.readFileSync(p,'utf8');
const checks=[
 ['Scenario completion popup exists', /function showScenarioCompletionPrompt\(\)/],
 ['Scenario popup requires explicit eligibility', /!completionPromptEligible\.scenarios/],
 ['Scenario start arms completion prompt', /if\(n==='scenarios'\|\|n==='strategy'\).*completionPromptEligible\[n\]=true/],
 ['Scenario start directly shows popup after completed response', /if\(n==='scenarios' && session\?\.stages\?\.scenarios\?\.status==='completed'\) setTimeout\(showScenarioCompletionPrompt,0\)/],
 ['Restored completed artifacts do not auto-arm on first session render', /observedStageStatuses\.scenarios=session\?\.stages\?\.scenarios\?\.status/],
 ['Run All blocks unacknowledged completed scenarios', /current\.status==='completed'&&!runAllState\.acknowledgedStages\?\.\[n\]/],
 ['Immediate completed Scenario/Strategy responses do not bypass completion gate', /if\(isRunAllTerminal\(after\.status\) && n!==['\"]scenarios['\"] && n!==['\"]strategy['\"]\) continue;/],
];
let failed=0;
for(const [name,re] of checks){if(!re.test(s)){console.error('FAIL:',name);failed++;}else console.log('PASS:',name);}
if(failed)process.exit(1);
console.log('Scenario completion regression checks passed.');

