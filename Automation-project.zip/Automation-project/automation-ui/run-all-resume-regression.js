const fs = require('fs');
const app = fs.readFileSync('automation-ui/public/app.js','utf8');
const server = fs.readFileSync('automation-ui/src/server.ts','utf8');
const checks = [
  ['Run-All has resumable state', /function resumeStages\(\)/.test(app)],
  ['Stop All preserves the interrupted stage for resume', /runAllState\.waitingStage=current\|\|null/.test(app) && /resumeMode=stoppedStatus==='ready'\?'current':'next'/.test(app)],
  ['Resume can restart an interrupted stage instead of skipping it', /resumeMode==='current'\?runAllState\.index:runAllState\.index\+1/.test(app)],
  ['Run All derives its starting point from persisted stage statuses', /function firstRunAllPendingIndex\(\)/.test(app) && /const startIndex=firstRunAllPendingIndex\(\)/.test(app)],
  ['Completed and not-required stages are skipped during Run-All resume', /function isRunAllTerminal\(status\)/.test(app) && /if\(isRunAllTerminal\(current\.status\)\) continue/.test(app)],
  ['Run-All header uses actual stage status', /currentStatus==='running'.*setRunAllStatus/.test(app)],
  ['button says Resume Stages when paused', /resumable\?['"]Resume Stages['"]/.test(app)],
  ['Run All does not reset a paused session', /runAllState\.sessionId===session\.id&&runAllState\.waitingStage!==null/.test(app)],
  ['New sessions reset old Run-All state', /runAllState=\{active:false,sessionId:null,index:0,waitingStage:null,resumeMode:null,acknowledgedStages:\{\}\}/.test(app)],
  ['saving Strategy no longer auto-continues', !/if\(shouldResumeRunAll\)\{setTimeout\(\(\)=>continueRunAll\(\),500\)\}/.test(app)],
  ['saving Strategy preserves paused stage', /wasRunAllPaused.*runAllState\.waitingStage=n/.test(app)],
  ['Squash start requires explicit acknowledgement in frontend', /if\(n==='squash'\)body\.explicitStart=true/.test(app)],
  ['Squash start requires explicit acknowledgement in backend', /n==='squash' && b\.explicitStart!==true/.test(server)],
  ['Resume does not bypass approval gate', /current\?\.status==='waiting_for_approval'.*Review and approve/.test(app)],
  ['Stopped stages do not retain a completion timestamp', /status:'ready',completedAt:undefined,message:'Stopped by user\.'/ .test(server)],
];
let failed = checks.filter(([,ok])=>!ok);
for (const [name,ok] of checks) console.log(`${ok?'PASS':'FAIL'}: ${name}`);
if(failed.length) process.exit(1);

// Regression: completed Scenario/Strategy are explicit Run-All checkpoints and
// stale completion dialogs must not survive while Run-All waits at another stage.
const hasAck = /acknowledgedStages/.test(app);
const firstIndexGuardsCompleted = /function firstRunAllPendingIndex\(\).*?if\(isRunAllTerminal\(status\)\)\{if\(\(n==='scenarios'\|\|n==='strategy'\).*?return i;continue;\}/s.test(app);
const runLoopGuardsCompleted = /if\(\(n==='scenarios'\|\|n==='strategy'\)&&current\.status==='completed'&&!runAllState\.acknowledgedStages\?\.\[n\]\)/.test(app);
const stalePromptCleanup = /function closeStaleWorkflowPromptsForRunAll\(stageName\)/.test(app) && /closeStaleWorkflowPromptsForRunAll\(stageName\)/.test(app);
const promptSuppression = (()=>{
  const names=['showStrategyCompletionPrompt','showSquashUploadPrompt','showScriptGenerationPrompt'];
  return names.every(name=>{const i=app.indexOf(`function ${name}()`);if(i<0)return false;const j=app.indexOf('function ',i+10);const body=app.slice(i,j<0?app.length:j);return !body.includes('runAllState.active ||');});
})();
for (const [name,ok] of [
  ['Run-All persists explicit Scenario/Strategy acknowledgements', hasAck],
  ['Run-All first pending index stops at unacknowledged completed Scenario/Strategy', firstIndexGuardsCompleted],
  ['Run-All loop gates completed Scenario/Strategy before terminal skip', runLoopGuardsCompleted],
  ['Run-All closes stale completion prompts when pausing at another stage', stalePromptCleanup],
  ['Completion prompts are not suppressed by Run-All state', promptSuppression],
]) console.log(`${ok?'PASS':'FAIL'}: ${name}`);
if(!hasAck || !firstIndexGuardsCompleted || !runLoopGuardsCompleted || !stalePromptCleanup || !promptSuppression) process.exit(1);
