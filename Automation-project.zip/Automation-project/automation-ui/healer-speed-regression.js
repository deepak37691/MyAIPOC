const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const app = fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8');
const source = fs.readFileSync(path.join(root, 'src', 'server.ts'), 'utf8');
const dist = fs.readFileSync(path.join(root, 'dist', 'server.js'), 'utf8');
const runner = fs.readFileSync(path.join(root, 'agent-runner.js'), 'utf8');
const agent = fs.readFileSync(path.join(root, '..', '.github', 'agents', 'test-healer-agent.md'), 'utf8');
const css = fs.readFileSync(path.join(root, 'public', 'app.css'), 'utf8');
const server = `${source}\n${dist}`;
const checks = [
  ['Healer diagnosis timeout is bounded to 60s', /HEALER_DIAGNOSIS_TIMEOUT_MS \|\| 60000/.test(source)],
  ['Healer approval timeout is bounded to 300s', /HEALER_REPAIR_TIMEOUT_MS \|\| 300000/.test(source)],
  ['Healer heartbeat runs every 10s', /setInterval\(\(\)=>\{[\s\S]*?\},10000\)/.test(source)],
  ['Approved healer receives exact proposal', /HEALING_PROPOSAL/.test(source) && /HEALING_PROPOSAL/.test(runner)],
  ['Approved healer applies only the exact proposal', /Apply ONLY the exact approved healing proposal/.test(runner) && /apply ONLY the exact approved proposal/.test(agent)],
  ['Approved healer verifies once', /runner will execute exactly one targeted verification/.test(runner) && /runner executes exactly one targeted verification/.test(agent)],
  ['Approved healer uses a fresh Playwright JSON report', /HEALER_VERIFICATION_REPORT_FILE/.test(source) && /readHealerVerification/.test(source)],
  ['Healer does not block on issue-specific result JSON', /Do NOT spend time searching for test-results/.test(runner) && /do not block on it/.test(agent)],
  ['Healer uses focused MCP reconnaissance', /one targeted live DOM\/accessibility check/.test(agent)],
  ['Healer skips GitLab MCP', !/if \(stage === 'healer'\)/.test(runner) || !/GitLab-MCP/.test(runner.slice(runner.indexOf('if (stage === \'healer\')')))],
];
const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  console.error(failed.map(([name]) => `FAIL: ${name}`).join('\n'));
  process.exit(1);
}
console.log('Healer speed/configuration regression checks passed.');
