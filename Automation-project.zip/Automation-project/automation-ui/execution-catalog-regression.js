// Regression: the Test Execution selector needs stages.execution.output.catalog BEFORE the first run.
const fs = require('node:fs'); const path = require('node:path'); const assert = require('node:assert');
const src = fs.readFileSync(path.join(__dirname, 'src', 'server.ts'), 'utf8');
assert.ok(/function syncExecutionCatalog\(/.test(src), 'syncExecutionCatalog helper missing');
assert.ok(/syncExecutionCatalog\(s\); s\.mcp=mcpStatus\(\)/.test(src), 'GET /api/session/:id must sync the execution catalog');
assert.ok(/syncExecutionCatalog\(s\); save\(s\);\s*unlockAfter\(s,n\)/.test(src), 'Script Generation completion must populate the catalog');
console.log('execution-catalog-regression: OK');
