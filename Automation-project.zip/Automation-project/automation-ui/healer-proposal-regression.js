const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, 'src', 'server.ts'), 'utf8');
const dist = fs.readFileSync(path.join(__dirname, 'dist', 'server.js'), 'utf8');
const checks = [
  ['source recognizes healer proposal hand-off', /const healerProposalReady\s*=\s*stageName\s*===\s*['\"]healer['\"]/.test(src)],
  ['source does not fail proposal hand-off', src.includes('!defectCreationConfirmed && !healerProposalReady')],
  ['compiled server contains healer proposal handling', dist.includes("const healerProposalReady = stageName === 'healer'")],
  ['compiled server does not fail proposal hand-off', dist.includes('!defectCreationConfirmed && !healerProposalReady')],
  ['defect unlock remains tied to actual healer failure', src.includes("if(n==='healer')")],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed++; }
process.exit(failed ? 1 : 0);
