const fs=require('fs');
const app=fs.readFileSync('automation-ui/public/app.js','utf8');
const checks=[
 ['Strategy popup is completion-gated', /function showStrategyCompletionPrompt\(\).*?status==='completed'.*?completionPromptEligible\.strategy/s],
 ['Strategy popup is not suppressed by Run All state', !/function showStrategyCompletionPrompt\(\)[\s\S]*?runAllState\.active \|\| \(runAllState\.waitingStage && runAllState\.waitingStage!==['"]strategy['"]\)/.test(app)],
 ['Squash popup is completion-gated', /function showSquashUploadPrompt\(\).*?status==='completed'.*?squashUploadPromptEligible/s],
 ['Squash popup is not suppressed by Run All state', !/function showSquashUploadPrompt\(\)[\s\S]*?runAllState\.active \|\| \(runAllState\.waitingStage && runAllState\.waitingStage!==['"]squash['"]\)/.test(app)],
 ['Script popup is completion-gated', /function showScriptGenerationPrompt\(\).*?status==='completed'.*?scriptGenerationPromptEligible/s],
 ['Script popup is not suppressed by Run All state', !/function showScriptGenerationPrompt\(\)[\s\S]*?runAllState\.active \|\| \(runAllState\.waitingStage && runAllState\.waitingStage!==['"]scriptGeneration['"]\)/.test(app)],
 ['Squash completion transition arms popup', /previousSquash[\s\S]*?currentSquash==='completed'[\s\S]*?squashUploadPromptEligible=true/],
 ['Script completion transition arms popup', /previousScript[\s\S]*?currentScript==='completed'[\s\S]*?scriptGenerationPromptEligible=true/],
 ['Strategy approval directly shows popup', /n==='strategy' && session\?\.stages\?\.strategy\?\.status==='completed'[\s\S]*?setTimeout\(showStrategyCompletionPrompt,0\)/],
];
let failed=0;for(const [name,ok] of checks){if(ok)console.log('PASS:',name);else{console.error('FAIL:',name);failed++;}}
if(failed)process.exit(1);console.log('Completion gate regression checks passed.');
