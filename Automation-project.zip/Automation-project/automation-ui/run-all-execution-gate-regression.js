const fs = require('fs');
const app = fs.readFileSync('automation-ui/public/app.js', 'utf8');

const checks = [
  [
    'Run-All does not auto-advance a freshly completed stage',
    /IMPORTANT: do not terminal-skip a freshly completed stage here[\s\S]*?only path that advances Run All after a completion/.test(app)
  ],
  [
    'Old terminal continue shortcut is removed',
    !/if\(isRunAllTerminal\(after\.status\) && n!==['"]scenarios['"] && n!==['"]strategy['"]\) continue/.test(app)
  ],
  [
    'Execution completion uses the Run-All completion prompt',
    /if\(after\.status==='completed'\)[\s\S]*?showRunAllCompletionPrompt\(n,'completed'\)/.test(app)
  ],
  [
    'Next stage skips NOT_REQUIRED stages',
    /function nextRunAllStageName\(stageName\)[\s\S]*?if\(status==='not_required'\)continue/.test(app)
  ],
  [
    'Next stage skips locked defect reporting',
    /function nextRunAllStageName\(stageName\)[\s\S]*?name==='defect'&&status==='locked'/.test(app)
  ],
  [
    'Passing execution points directly to Squash Test Case Execution',
    /function nextRunAllStageName\(stageName\)[\s\S]*?if\(status==='not_required'\)continue[\s\S]*?if\(name==='defect'&&status==='locked'\)continue[\s\S]*?return name/.test(app)
  ],
];
let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
console.log('Run-All execution completion gate regression checks passed.');
