let session=null,poll=null,stageSignature='';
let runAllState={active:false,sessionId:null,index:0,waitingStage:null};
const RUN_ALL_SEQUENCE=['businessReview','scenarios','strategy','squash','scriptGeneration','execution','healer','defect','squashExecution','gitlabCommit'];
let projectSetupCollapsed=false;
function projectSetupReady(){return !!($('issueUrl')?.value.trim() && $('appUrl')?.value.trim() && Number($('testCaseFolderId')?.value)>0 && $('executionFolderName')?.value.trim() && $('campaignName')?.value.trim() && $('iterationName')?.value.trim());}
function toggleProjectSetup(){if(!projectSetupReady() && !projectSetupCollapsed){return;} projectSetupCollapsed=!projectSetupCollapsed; renderProjectSetup();}
function renderProjectSetup(){const body=$('projectSetupBody'),btn=$('setupToggle'),card=$('projectSetup'); if(!body||!btn||!card)return; body.hidden=projectSetupCollapsed; card.classList.toggle('collapsed',projectSetupCollapsed); btn.disabled=!projectSetupReady() && !projectSetupCollapsed; btn.textContent=projectSetupCollapsed?'Expand setup':'Collapse setup'; btn.setAttribute('aria-expanded',String(!projectSetupCollapsed));}

const labels={businessReview:'Business Requirements Review',scenarios:'Test Scenarios',strategy:'Test Strategy',squash:'Squash Upload',scriptGeneration:'Test Script Generation',execution:'Test Execution',healer:'Test Healer',defect:'GitLab Defect Reporting',squashExecution:'Squash Test Case Execution',gitlabCommit:'GitLab Commit'};
const descriptions={businessReview:'Validate completeness, ambiguity, and testability before generating E2E scenarios.',scenarios:'Generate structured test scenarios from the GitLab issue.',strategy:'Review the automation scope and approve the selected test cases.',squash:'Upload the approved test cases to Squash.',scriptGeneration:'Generate Playwright data, page objects, and test scripts.',execution:'Select test cases, configure the run, and review results.',healer:'Review proposed fixes for failed test cases and approve the repair.',defect:'Create a GitLab defect as a Task child item under the current requirement when Test Execution or Test Healer fails.',squashExecution:'Create the Squash Executions workspace hierarchy and executions from a Test Case Folder.',gitlabCommit:'Review the final changes and approve the GitLab commit.'};
const $=id=>document.getElementById(id);
const statusLabels={locked:'Locked',ready:'Ready',running:'Running',completed:'Completed',failed:'Failed',waiting_for_approval:'Needs approval'};
function stageStatusLabel(status){return statusLabels[status]||String(status||'').replaceAll('_',' ');}
function stageMessage(s,n){
  if(s?.status==='failed') return n==='healer'?'Repair application failed. Review the diagnostic details below and retry when ready.':'This stage failed. Review the details and retry when ready.';
  if(s?.status==='waiting_for_approval') return n==='healer'?'A healing proposal is ready for review.':'Review the proposed changes and approve to continue.';
  if(s?.status==='running') return n==='healer' ? ((s.output?.approvalStatus==='approved' || s.output?.proposalStatus==='approved') ? 'Applying the approved repair and validating the result…' : 'Preparing the healing proposal for your review…') : 'Stage is running. You can monitor progress in the Activity log.';
  if(s?.status==='completed') return 'Stage completed successfully.';
  return s?.message||'Ready to run.';
}

async function api(url,opt={}){const r=await fetch(url,{headers:{'Content-Type':'application/json'},...opt});const d=await r.json();if(!r.ok)throw new Error(d.error||'Request failed');return d}
async function saveTokens(){try{const g=$('gitlabToken').value.trim(),q=$('squashToken').value.trim();if(!g&&!q)throw new Error('Enter at least one token.');const d=await api('/api/secrets',{method:'POST',body:JSON.stringify({gitlabToken:g||undefined,squashToken:q||undefined})});$('gitlabToken').value='';$('squashToken').value='';renderSecrets(d)}catch(e){alert(e.message)}}
async function clearTokens(){try{const d=await api('/api/secrets/clear',{method:'POST',body:'{}'});$('gitlabToken').value='';$('squashToken').value='';renderSecrets(d);renderMcp(await api('/api/mcp/status'))}catch(e){alert(e.message)}}
async function refreshSecrets(){try{renderSecrets(await api('/api/secrets/status'))}catch{}}function renderSecrets(d){$('tokenStatus').textContent=d.gitlabConfigured&&d.squashConfigured?'GitLab configured • Squash configured':d.gitlabConfigured?'GitLab configured • Squash not configured':d.squashConfigured?'GitLab not configured • Squash configured':'Tokens not configured'}
async function mcp(kind,action){try{renderMcp(await api('/api/mcp/'+action,{method:'POST',body:JSON.stringify({kind})}))}catch(e){alert(e.message)}}
async function refreshMcp(){try{renderMcp(await api('/api/mcp/status'))}catch{}}function renderMcp(d){[['gitlab','GitLab'],['playwright','Playwright']].forEach(([k])=>{const el=$(k==='gitlab'?'gitlabStatus':'pwStatus');el.textContent=d[k]?'Running':'Stopped';el.className='dot '+(d[k]?'running':'stopped')});$('health').textContent=d.gitlab&&d.playwright?'MCP READY':'MCP NOT READY';$('health').className='health '+(d.gitlab&&d.playwright?'ok':'')}
async function createSession(){try{expandedStages.clear();stageSignature='';if(!issueUrl.value.trim())throw new Error('Enter a GitLab issue URL.');session=await api('/api/session',{method:'POST',body:JSON.stringify({issueUrl:issueUrl.value.trim(),testCaseFolderId:$('testCaseFolderId').value,executionFolderName:$('executionFolderName').value.trim(),campaignName:$('campaignName').value.trim(),iterationName:$('iterationName').value.trim(),testSuiteName:$('testSuiteName').value.trim(),appUrl:appUrl.value.trim()})});projectSetupCollapsed=true;renderProjectSetup();render();startPoll()}catch(e){alert(e.message)}}
function startPoll(){if(poll)clearInterval(poll);poll=setInterval(refresh,1000)}async function refresh(){if(!session)return;try{session=await api('/api/session/'+session.id);render()}catch(e){console.error(e)}}
function cleanCaseTitle(id,title){
  const caseId=String(id||'').trim().toUpperCase();
  const raw=String(title||'').trim();
  if(!raw) return '';
  const escaped=caseId.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  return raw.replace(new RegExp('^'+escaped+'(?:\\s*[-:|]\\s*|\\s+)?','i'),'').trim() || raw;
}
function testCases(){
  const catalog=session?.stages?.execution?.output?.catalog || [];
  return catalog.map(x=>{const id=String(x.id).toUpperCase();return {key:String(x.key),issueId:String(x.issueId),id,title:cleanCaseTitle(id,x.title||x.id),spec:x.spec}});
}
function strategyCases(){
  return session?.stages?.strategy?.output?.proposal?.strategies || session?.stages?.strategy?.output?.strategies || [];
}
function updateStrategySelectionCount(){
  const rows=strategyCases();
  const count=document.querySelectorAll('input[name="strategyCase"]:checked').length;
  const el=document.getElementById('strategySelectionCount');
  if(el) el.textContent=`${count} of ${rows.length} test cases selected for approval`;
  document.querySelectorAll('.strategy-case').forEach(label=>{
    const input=label.querySelector('input[name="strategyCase"]');
    label.classList.toggle('selected',!!input?.checked);
    label.classList.toggle('offload',!input?.checked);
  });
}

function renderBusinessReview(s){
  const review=s?.output?.review;
  if(!review) return s.status==='waiting_for_approval'
    ? '<div class="strategy-review empty-review"><strong>Reviewer output is not available yet.</strong><span>Review details will appear when the agent finishes.</span></div>'
    : '';
  const score=Number(review.completenessScore||0);
  const decision=String(review.decision||'NEEDS_REVISION');
  const passed=review.passedChecks||[];
  const gaps=review.criticalGaps||[];
  const fixes=review.recommendedFixes||[];
  const feedback=String(s.output?.feedback||'');
  const decisionLabel=decision==='READY_FOR_SCENARIOS'?'Ready for scenarios':decision==='REJECTED'?'Rejected':'Needs revision';
  const overridePending=s.status==='waiting_for_approval' && decision!=='READY_FOR_SCENARIOS';
  const formatReviewItems=(items)=>items.flatMap(item=>{
    const raw=String(item||'').replace(/\r/g,'').trim();
    if(!raw) return [];
    // Normalize agent output into one UI item per finding. Handle Markdown
    // bullets/numbers, inline numbered items, and plain prose paragraphs.
    const lines=raw.split('\n').map(x=>x.trim()).filter(Boolean);
    const expanded=[];
    for(const line of lines){
      const parts=line.split(/(?=(?:^|\s)\d+[.)]\s+)/).map(x=>x.trim()).filter(Boolean);
      expanded.push(...(parts.length?parts: [line]));
    }
    const cleaned=expanded
      .map(x=>x.replace(/^[-*+]\s+/, '').replace(/^\d+[.)]\s+/, '').trim())
      .filter(Boolean);
    if(cleaned.length>1) return cleaned;
    const single=cleaned[0]||'';
    // If the model returned a single paragraph instead of a list, split
    // sentence-level findings so Passed Checks and Recommended Fixes are still
    // presented as separate, scannable pointers.
    const sentences=single
      .split(/(?<=[.!?])\s+(?=[A-Z0-9])/u)
      .map(x=>x.trim())
      .filter(Boolean);
    return sentences.length>1 ? sentences : (single?[single]:[]);
  });
  const lists=(items,empty,ordered=false)=>{
    const normalized=formatReviewItems(items);
    const tag=ordered?'ol':'ul';
    return normalized.length?`<${tag}>${normalized.map(x=>`<li>${esc(x)}</li>`).join('')}</${tag}>`:`<div class="hint">${empty}</div>`;
  };
  return `<div class="business-review">
    <div class="review-head">
      <div><strong>Agent decision</strong><span class="review-decision ${decision.toLowerCase()}">${esc(decisionLabel)}</span></div>
      <span class="review-badge">Completeness ${score}%</span>
    </div>
    <div class="business-score"><div class="business-score-fill" style="width:${Math.max(0,Math.min(100,score))}%"></div></div>
    <div class="business-review-grid">
      <section><h4>Passed Checks</h4>${lists(passed,'No checks were passed.')}</section>
      <section><h4>Critical Gaps & Ambiguities</h4>${lists(gaps,'No critical gaps identified.',true)}</section>
      <section><h4>Recommended Fixes</h4>${lists(fixes,'No fixes recommended.')}</section>
    </div>
    ${s.status==='waiting_for_approval'?`<div class="business-feedback">
      <label for="businessReviewFeedback"><strong>Business feedback</strong><span>Tell the reviewer what you want clarified or reconsidered. This does <strong>not</strong> modify the GitLab issue; it asks the reviewer to run a fresh review against the full requirement.</span></label>
      ${feedback?`<div class="last-feedback"><strong>Last feedback submitted:</strong> ${esc(feedback)}</div>`:''}
      <textarea id="businessReviewFeedback" rows="4" placeholder="Example: Clarify payment failure behavior, maximum retries, and whether the cart is preserved after a failed payment."></textarea>
      <div class="feedback-actions"><button class="secondary small" onclick="submitBusinessFeedback()">Request Changes & Re-review</button></div>
    </div>`:''}
    ${overridePending?'<div class="review-override-note"><strong>Reviewer recommendation:</strong> This review still needs revision. If you approve it, your approval will explicitly override the reviewer decision; the completeness score will remain unchanged.</div>':''}
    ${s.status==='completed'?`<div class="review-note">Approved by you. Test Scenarios is now unlocked.${s.output?.reviewerRecommendationOverridden?` <strong>Reviewer override recorded:</strong> the score remains ${Number(s.output?.completenessScore||score)}% and was not changed.`:''}</div>`:''}
  </div>`;
}
async function submitBusinessFeedback(){
  const value=document.getElementById('businessReviewFeedback')?.value.trim();
  if(!value){alert('Enter specific feedback before requesting a revision.');return}
  if(approvalBusy)return;
  approvalBusy=true;
  try{
    session=await api(`/api/session/${session.id}/stage/businessReview/revise`,{method:'POST',body:JSON.stringify({feedback:value})});
    expandedStages.add('businessReview');
    render();
  }catch(e){alert(e.message);await refresh()}
  finally{approvalBusy=false}
}
function renderStrategyReview(s){
  if(s.status!=='waiting_for_approval') return '';
  const rows=strategyCases();
  if(!rows.length) return '<div class="strategy-review empty-review"><strong>No test cases available.</strong><span>The Test Scenarios artifact did not contain any TC-* scenarios to review.</span></div>';
  const selected=rows.filter(x=>/^AUTOMATE/i.test(x.decision||''));
  return `<div class="strategy-review">
    <div class="review-head">
      <div><strong>Automation scope</strong><span id="strategySelectionCount">${selected.length} of ${rows.length} test cases selected for approval</span></div>
      <span class="review-badge">Review selection</span>
    </div>
    <div class="strategy-checks">
      ${rows.map(x=>{
        const isSelected=/^AUTOMATE/i.test(x.decision||'');
        return `<label class="strategy-case${isSelected?' selected':' offload'}">
          <input type="checkbox" name="strategyCase" value="${esc(x.id)}"${isSelected?' checked':''} onchange="updateStrategySelectionCount()">
          <span class="case-id">${esc(x.id)}</span>
          <span class="case-title">${esc(x.description)}</span>
          <span class="case-decision">${esc(x.decision)}</span>
          <span class="case-tier">${esc(x.tier)}</span>
        </label>`;
      }).join('')}
    </div>
    <div class="review-note">All test scenarios are shown. Only the Test Strategy Agent's recommended <strong>AUTOMATE (E2E)</strong> cases are checked initially. Change any checkbox to define exactly which cases you approve; only checked cases will be written to the final strategy.md.</div>
  </div>`;
}

async function startStage(n,options={}){try{if(n==='scenarios'||n==='strategy'){completionPromptEligible[n]=true;scenarioCompletionPrompted=n==='scenarios'?false:scenarioCompletionPrompted;strategyCompletionPrompted=n==='strategy'?false:strategyCompletionPrompted;} if(n==='healer'){healerFailurePrompted=false;closeHealerFailurePrompt();} if(n==='execution'){executionOutcomePrompted=false;closeExecutionOutcomePrompt();} if(n==='squashExecution'){squashCompletionPrompted=false;squashCompletionPromptEligible=true;closeSquashCompletionPrompt();}let body={};if(n==='scriptGeneration')body.appUrl=$('appUrl').value.trim();if(n==='execution'){let checks=[...document.querySelectorAll('input[name=\"testcase\"]:checked')].map(x=>x.value);if(options.all){const approved=new Set((session?.stages?.strategy?.output?.includedTestCases||[]).map(x=>String(x).trim().toUpperCase()));checks=testCases().filter(x=>approved.size?approved.has(String(x.id).toUpperCase()):true).map(x=>x.key);}if(!checks.length){throw new Error(options.all?'No approved test cases are available for automatic execution. Approve at least one test case in Test Strategy.':'Select at least one test case before starting execution.')}const workers=Number(options.workers||document.getElementById('executionWorkers')?.value||8);if(!Number.isInteger(workers)||workers<1){throw new Error('Workers must be a whole number greater than 0.')}const headless=options.all?true:!!document.getElementById('executionHeadless')?.checked;body.testCases=[...new Set(checks.map(x=>String(x).trim().toUpperCase()).filter(Boolean))];body.workers=workers;body.headless=headless;}session=await api(`/api/session/${session.id}/stage/${n}/start`,{method:'POST',body:JSON.stringify(body)});render();return session}catch(e){if(options.all && (n==='execution'||n==='healer')){await refresh();return session;}if(options.silent)throw e;alert(e.message);await refresh();return null}}
function setRunAllStatus(text,kind='idle'){const el=$('workflowRunStatus');if(!el)return;el.textContent=text;el.className=`workflow-run-status ${kind}`;}
function setRunAllActive(active){runAllState.active=active;const b=$('runAllStages');if(b){b.disabled=active||!session;b.textContent=active?'Running All Stages':'Run All Stages';}if(!active&&runAllState.waitingStage===null)setRunAllStatus('Idle');}
function runAllPause(stageName,message){runAllState.active=false;runAllState.waitingStage=stageName;setRunAllActive(false);setRunAllStatus(`Paused: ${labels[stageName]||stageName} approval required`,'paused');alert(message);}
function nextRunAllStageName(stageName){const idx=RUN_ALL_SEQUENCE.indexOf(stageName);return idx>=0&&idx<RUN_ALL_SEQUENCE.length-1?RUN_ALL_SEQUENCE[idx+1]:null;}
function showRunAllCompletionPrompt(stageName,status='completed'){
  if(stageName==='squashExecution' && status==='completed'){squashCompletionPromptEligible=true;showSquashCompletionPrompt();return;}
  if(!session||runAllState.sessionId!==session.id)return;
  const next=nextRunAllStageName(stageName);
  if(!next){runAllState.active=false;runAllState.waitingStage=null;setRunAllStatus('All stages completed','completed');return;}
  runAllState.active=false;
  runAllState.waitingStage=stageName;
  setRunAllActive(false);
  setRunAllStatus(`Paused: ${labels[stageName]} completed — waiting for your action`,'paused');
  const id='runAllCompletionPrompt';
  document.getElementById(id)?.remove();
  const failed=status==='failed';
  const overlay=document.createElement('div');
  overlay.id=id;
  overlay.className='editor-overlay strategy-completion-overlay';
  overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true">
    <div class="strategy-completion-icon">${failed?'!':'✓'}</div>
    <h3>${esc(labels[stageName])} ${failed?'finished with failures':'completed'}</h3>
    <p>${failed?'The stage has finished with failures.':'The stage is complete.'} Choose an action before the next workflow stage starts.</p>
    <div class="strategy-completion-actions">
      <button class="ghost" type="button" onclick="stopRunAllFromPrompt()">Stop Run All</button>
      <button class="primary" type="button" onclick="proceedRunAllFromPrompt()">Continue to ${esc(labels[next])}</button>
    </div>
    <button class="strategy-completion-close" type="button" onclick="closeRunAllCompletionPrompt()" aria-label="Close">×</button>
  </div>`;
  document.body.appendChild(overlay);
}
function closeRunAllCompletionPrompt(){document.getElementById('runAllCompletionPrompt')?.remove();}
function stopRunAllFromPrompt(){closeRunAllCompletionPrompt();runAllState.active=false;runAllState.waitingStage=null;setRunAllStatus('Run All Stages stopped by user','failed');}
async function proceedRunAllFromPrompt(){
  const waiting=runAllState.waitingStage;
  closeRunAllCompletionPrompt();
  if(!waiting||runAllState.sessionId!==session?.id)return;
  runAllState.waitingStage=null;
  runAllState.active=true;
  setRunAllStatus(`Continuing after ${labels[waiting]}…`,'running');
  try{await runAllFromIndex(runAllState.index+1);}catch(e){runAllState.active=false;setRunAllStatus(`Stopped: ${e.message}`,'failed');alert(e.message);await refresh();}
}
async function continueRunAll(){
  const waiting=runAllState.waitingStage;
  if(!session||runAllState.sessionId!==session.id||waiting===null)return;
  if(document.getElementById('runAllCompletionPrompt')){await proceedRunAllFromPrompt();return;}
  runAllState.waitingStage=null;
  runAllState.active=true;
  setRunAllStatus(`Continuing after ${labels[waiting]||waiting} approval…`,'running');
  try{await runAllFromIndex(runAllState.index+1);}catch(e){runAllState.active=false;setRunAllStatus(`Stopped: ${e.message}`,'failed');alert(e.message);await refresh();}
}
async function runAllFromIndex(startIndex){
  for(let i=startIndex;i<RUN_ALL_SEQUENCE.length;i++){
    runAllState.index=i;
    const n=RUN_ALL_SEQUENCE[i];
    await refresh();
    const current=session?.stages?.[n];
    if(!current)throw new Error(`Unknown workflow stage: ${n}`);
    setRunAllStatus(`Running ${i+1}/${RUN_ALL_SEQUENCE.length}: ${labels[n]}`,'running');

    if((n==='scenarios'||n==='strategy')&&current.status==='completed'){
      completionPromptEligible[n]=true;
      const alreadyPrompted=n==='scenarios'?scenarioCompletionPrompted:strategyCompletionPrompted;
      if(!alreadyPrompted){
        runAllState.active=false;
        runAllState.waitingStage=n;
        setRunAllStatus(`Paused: ${labels[n]} review required`,'paused');
        if(n==='scenarios')showScenarioCompletionPrompt();else showStrategyCompletionPrompt();
        return;
      }
      continue;
    }
    if(current.status==='waiting_for_approval'){
      runAllPause(n,`${labels[n]} is waiting for approval. Review it and click Approve to continue Run All Stages.`);
      return;
    }
    if((n==='healer'||n==='defect')&&current.status==='not_required'){
      setRunAllStatus(`Skipped ${i+1}/${RUN_ALL_SEQUENCE.length}: ${labels[n]} is not required for this successful execution path.`,'paused');
      continue;
    }
    if(n==='defect'&&current.status==='locked'){
      setRunAllStatus(`Skipped ${i+1}/${RUN_ALL_SEQUENCE.length}: GitLab Defect Reporting is only required after a Test Execution or Test Healer failure.`,'paused');
      continue;
    }
    if(n==='defect'&&current.status==='completed'){
      setRunAllStatus(`Skipped ${i+1}/${RUN_ALL_SEQUENCE.length}: GitLab Defect Reporting was already completed.`,'paused');
      continue;
    }
    if(current.status==='locked')throw new Error(`${labels[n]} is locked. Complete the previous stage first.`);

    await startStage(n,{all:true,silent:true});
    await refresh();
    let after=session.stages[n];

    if(after.status==='waiting_for_approval'){
      runAllPause(n,`${labels[n]} is waiting for approval. Review it and click Approve to continue Run All Stages.`);
      return;
    }
    if(after.status==='failed'&&n==='healer'){
      runAllState.active=false;
      runAllState.waitingStage='healer';
      setRunAllStatus('Paused: Test Healer failed. Choose Retry Test Healing or Raise Defect in GitLab.','paused');
      showHealerFailurePrompt();
      return;
    }
    if(after.status==='failed'&&n==='execution'){
      runAllState.active=false; runAllState.waitingStage='execution';
      setRunAllStatus('Paused: Test Execution failed. Choose Test Healer or Raise Defect.','paused');
      showExecutionFailureRunAllPrompt();
      return;
    }
    if(after.status==='failed')throw new Error(`${labels[n]} failed: ${after.error||after.message||'Unknown error'}`);

    if(after.status==='running'){
      let terminal=false;
      for(let t=0;t<2400;t++){
        await new Promise(r=>setTimeout(r,1000));
        await refresh();
        const latest=session.stages[n];
        if(['completed','failed','waiting_for_approval','ready'].includes(latest.status)){
          after=latest;
          terminal=true;
          if(latest.status==='waiting_for_approval'){
            runAllPause(n,`${labels[n]} is waiting for approval. Review it and click Approve to continue Run All Stages.`);
            return;
          }
          if(latest.status==='failed'&&n==='healer'){
            runAllState.active=false;
            runAllState.waitingStage='healer';
            setRunAllStatus('Paused: Test Healer failed. Choose Retry Test Healing or Raise Defect in GitLab.','paused');
            showHealerFailurePrompt();
            return;
          }
          if(latest.status==='failed'&&n==='execution'){
            runAllState.active=false; runAllState.waitingStage='execution';
            setRunAllStatus('Paused: Test Execution failed. Choose Test Healer or Raise Defect.','paused');
            showExecutionFailureRunAllPrompt();
            return;
          }
          if(latest.status==='failed')throw new Error(`${labels[n]} failed: ${latest.error||latest.message||'Unknown error'}`);
          break;
        }
      }
      if(!terminal)throw new Error(`${labels[n]} timed out while running.`);
    }

    // Critical workflow gate: a completed stage never advances Run All by itself.
    // The next stage starts only after the user clicks Continue in the completion dialog.
    await refresh();
    after=session.stages[n];
    if(after.status==='completed'){
      if(n==='scenarios'){
        completionPromptEligible.scenarios=true;
        scenarioCompletionPrompted=false;
        runAllState.active=false;
        runAllState.waitingStage=n;
        setRunAllStatus(`Paused: ${labels[n]} review required`,'paused');
        showScenarioCompletionPrompt();
      }else if(n==='strategy'){
        completionPromptEligible.strategy=true;
        strategyCompletionPrompted=false;
        runAllState.active=false;
        runAllState.waitingStage=n;
        setRunAllStatus(`Paused: ${labels[n]} review required`,'paused');
        showStrategyCompletionPrompt();
      }else{
        showRunAllCompletionPrompt(n,'completed');
      }
      return;
    }
    if(after.status==='ready')throw new Error(`${labels[n]} returned to Ready without completing.`);
  }
  runAllState.active=false;
  runAllState.waitingStage=null;
  setRunAllStatus('All stages completed','completed');
  render();
}
async function runAllStages(){if(!session){alert('Create a workspace first.');return}if(runAllState.active)return;runAllState={active:true,sessionId:session.id,index:0,waitingStage:null};setRunAllStatus('Starting workflow…','running');try{await runAllFromIndex(0);}catch(e){runAllState.active=false;setRunAllStatus(`Stopped: ${e.message}`,'failed');alert(e.message);await refresh();}}
async function stopStage(n){try{session=await api(`/api/session/${session.id}/stage/${n}/stop`,{method:'POST',body:'{}'});render()}catch(e){alert(e.message);refresh()}}
let approvalBusy=false;
const expandedStages=new Set();
function toggleStage(n){const card=document.querySelector(`.stage-card[data-stage="${n}"]`);if(!card)return;const open=card.classList.toggle('expanded');if(open)expandedStages.add(n);else expandedStages.delete(n);const body=card.querySelector('.stage-body');if(body)body.hidden=!open;const toggle=card.querySelector('.stage-toggle');if(toggle){toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'−':'+';toggle.setAttribute('aria-label',`${open?'Collapse':'Expand'} ${labels[n]}`);}}
async function approval(n,a){
  if(approvalBusy)return;
  let body={};
  if(n==='strategy'){
    body.includedTestCases=[...document.querySelectorAll('input[name="strategyCase"]:checked')].map(x=>x.value);
    if(a==='approve'&&!body.includedTestCases.length){alert('Select at least one test case before approving the strategy.');return}
  }
  const buttons=[...document.querySelectorAll('.approve-btn,.reject-btn')];
  approvalBusy=true;
  buttons.forEach(b=>{b.disabled=true;b.classList.add('busy');});
  if(a==='approve'&&n==='businessReview'){
    const review=session?.stages?.businessReview?.output?.review||{};
    const decision=String(review.decision||'NEEDS_REVISION');
    const score=Number(review.completenessScore||0);
    if(decision!=='READY_FOR_SCENARIOS'){
      const ok=window.confirm(`The Business Requirements Reviewer still recommends revision (${decision}, completeness ${score}%).\n\nApproving will NOT change the ${score}% score or modify the requirement. It will record your explicit override and unlock Test Scenarios.\n\nContinue?`);
      if(!ok){approvalBusy=false;buttons.forEach(b=>{b.disabled=false;b.classList.remove('busy');});return;}
    }
  }
  if(a==='approve'&&n==='strategy'){const b=document.querySelector('.approve-btn');if(b)b.innerHTML='<span class="spinner"></span> Approving...'}
  try{
    session=await api(`/api/session/${session.id}/stage/${n}/${a}`,{method:'POST',body:JSON.stringify(body)});
    if(a==='approve' && (n==='strategy'||n==='scenarios')){
      // A freshly approved strategy/scenario is a deliberate workflow completion,
      // including the case where the artifact was edited after an earlier approval.
      // Re-arm the completion gate here rather than treating the restored status
      // as a passive session hydration event.
      completionPromptEligible[n]=true;
      if(n==='strategy') strategyCompletionPrompted=false;
      if(n==='scenarios') scenarioCompletionPrompted=false;
    }
    render();
    if(a==='approve' && n==='healer' && session?.stages?.healer?.status==='completed' && !(runAllState.sessionId===session.id && runAllState.waitingStage===n)){ setTimeout(showHealerCompletionPrompt,0); }
    if(a==='approve' && runAllState.sessionId===session.id && runAllState.waitingStage===n){
      await continueRunAll();
    } else if(a==='reject' && runAllState.sessionId===session.id && runAllState.waitingStage===n){
      runAllState.active=false;runAllState.waitingStage=null;setRunAllStatus(`Stopped: ${labels[n]||n} was rejected`,'failed');
    }
  }catch(e){
    alert(e.message);
    await refresh();
  }finally{
    approvalBusy=false;
    // Do not re-enable a successfully approved action. If the API failed and the
    // stage is still waiting for approval, restore the controls for another try.
    if(session?.stages?.[n]?.status==='waiting_for_approval'){
      document.querySelectorAll('.approve-btn,.reject-btn').forEach(b=>{b.disabled=false;b.classList.remove('busy');});
      const b=document.querySelector('.approve-btn');if(b)b.innerHTML='<span>✓</span> Approve Strategy';
    }
  }
}
function reportLink(n,s){
  if(n==='defect' && s.status==='completed' && s.output?.defectUrl){return `<a class="preview" onclick="event.stopPropagation()" href="${esc(s.output.defectUrl)}" target="_blank" rel="noopener noreferrer">Open Preview ↗</a>`;}
  // Test Scenarios and Test Strategy always preview their Markdown artifacts.
  // Never replace those links with the Playwright execution report: the user is
  // reviewing/editing the generated scenario/strategy documents at this point.
  const artifactReady=(n==='scenarios'||n==='strategy') && !!(s.output?.artifact?.relativePath || s.output?.proposalArtifact?.relativePath);
  // During a rerun the old artifact must not remain editable/reviewable. It becomes
  // available again only after the fresh run reaches its reviewable state.
  const rerunLocked=!!s.output?.rerunRequired || s.status==='running';
  const reviewableStrategy=s.status==='completed' || s.status==='waiting_for_approval';
  const enabled=!rerunLocked && ((n==='scenarios' && s.status==='completed') || (n==='strategy' && reviewableStrategy) || (n==='businessReview' && s.status==='waiting_for_approval' && !!s.output?.review?.artifact?.relativePath));
  if(enabled && (n==='scenarios' || n==='strategy')){
    return `<div class="stage-doc-actions" onclick="event.stopPropagation()"><a class="preview" href="/api/session/${session.id}/report/${n}" target="_blank" rel="noopener">Open Preview ↗</a><button class="preview edit-doc" type="button" onclick="editMarkdown('${n}')">Edit ${n==='scenarios'?'Scenario':'Strategy'}</button></div>`;
  }
  // The Playwright report remains the preview for executable test work only.
  const execution=session?.stages?.execution;
  const hasExecutionReport=!!(execution && ['completed','failed'].includes(execution.status) && execution.output?.reportUrl);
  const wantsPlaywrightReport=['squash','scriptGeneration','execution'].includes(n);
  if(wantsPlaywrightReport && hasExecutionReport){
    return `<a class="preview" onclick="event.stopPropagation()" href="/api/session/${session.id}/report/execution" target="_blank" rel="noopener">Open Preview ↗</a>`;
  }
  return enabled?`<a class="preview" onclick="event.stopPropagation()" href="/api/session/${session.id}/report/${n}" target="_blank" rel="noopener">Open Preview ↗</a>`:`<button class="preview disabled" disabled>Open Preview ↗</button>`;
}
function updateExecutionSelection(){
  const boxes=[...document.querySelectorAll('input[name="testcase"]')];
  const selected=boxes.filter(x=>x.checked).length;
  const all=boxes.length>0 && selected===boxes.length;
  const selectAll=document.getElementById('executionSelectAll');
  const start=document.getElementById('executionStart');
  const count=document.getElementById('executionSelectionCount');
  if(selectAll){selectAll.checked=all;selectAll.indeterminate=selected>0 && !all;}
  if(start) start.disabled=selected===0;
  if(count) count.textContent=`${selected} of ${boxes.length} selected`;
  document.querySelectorAll('.execution-case').forEach(label=>{
    const input=label.querySelector('input[name="testcase"]');
    label.classList.toggle('selected',!!input?.checked);
  });
}
function toggleAllExecutionCases(checked){
  document.querySelectorAll('input[name="testcase"]').forEach(input=>{input.checked=checked;});
  updateExecutionSelection();
}
function healerReview(s){
  if(!s || !['ready','waiting_for_approval','completed'].includes(s.status)) return '';
  const cases=s.output?.failedTestCases || [];
  if(!cases.length) return `<div class="healer-empty"><span class="hint">No failed or impacted test cases are currently queued. Run Test Execution and select a failing case to populate Test Healer.</span></div>`;
  const healerApproved=s.output?.approvalStatus==='approved' || s.output?.proposalStatus==='approved' || s.status==='completed';
  const proposal=s.output?.proposalHtml || (s.output?.proposalMarkdown ? `<pre class="healer-proposal-raw">${esc(s.output.proposalMarkdown)}</pre>` : '');
  const proposalBlock=proposal
    ? `<section class="healer-proposal"><div class="healer-proposal-head"><div><div class="mini-title">Healing Proposal</div><span class="hint">${healerApproved?'Approved by user. The healing proposal has been approved and the changes were applied.':'Review this diagnostic and proposed code change before approving.'}</span></div><span class="proposal-status ${healerApproved?'approved':''}">${healerApproved?'Approved':'Waiting for approval'}</span></div><div class="healer-proposal-body markdown-document">${proposal}</div></section>`
    : `<section class="healer-proposal missing"><div class="mini-title">Healing Proposal</div><span class="hint">The healer did not return a reviewable proposal yet. Approval is disabled until a proposal is available.</span></section>`;
  return `<div class="healer-review">
    <div class="mini-title">Failed / impacted test cases <span class="case-count">${cases.length}</span></div>
    <div class="healer-cases">${cases.map(x=>`<div class="healer-case"><div class="case-id-title"><span class="exec-case-id">${esc(x.id)}</span><span class="exec-case-title">${esc(cleanCaseTitle(x.id,x.title))}</span></div><div class="healer-case-meta">${esc(x.spec||'')}</div></div>`).join('')}</div>
    ${proposalBlock}
    <span class="hint">These cases were derived from the latest Playwright execution. The proposal above is the exact review artifact returned by Test Healer.</span>
  </div>`;
}

function executionResults(s){
  const results=Array.isArray(s.output?.executionCaseResults)?s.output.executionCaseResults:[];
  if(!results.length) return '';
  return `<section class="execution-results"><div class="mini-title">Latest execution results</div><div class="execution-result-list">${results.map(x=>{
    const failed=x.status==='failed';
    const detail=x.errorDetails?.length ? x.errorDetails.map((e,i)=>{
      const location=e.location?.file?`\nLocation: ${e.location.file}:${e.location.line||''}:${e.location.column||''}`:'';
      const message=e.message||'';
      const stack=e.stack&&e.stack!==message?`\n\n${e.stack}`:'';
      return `Error ${i+1}: ${message}${location}${stack}`;
    }).join('\n\n') : (x.error||'');
    const logId=`execution-log-${String(x.id||'').replace(/[^a-zA-Z0-9_-]/g,'-')}-${Math.random().toString(36).slice(2,7)}`;
    const logContent=detail?`<pre id="${logId}" class="execution-error-detail" hidden>${esc(detail)}</pre>`:'<div class="execution-result-ok">No error reported for this test case.</div>';
    const toggle=detail?`<button type="button" class="log-toggle" aria-expanded="false" onclick="toggleExecutionLog('${logId}',this)">Show log</button>`:'';
    return `<article class="execution-result ${failed?'failed':'passed'}"><div class="execution-result-head"><div class="case-id-title"><span class="exec-case-id">${esc(x.id)}</span><span class="exec-case-title">${esc(cleanCaseTitle(x.id,x.title))}</span></div><div class="execution-result-actions">${toggle}<span class="execution-result-status">${failed?'Failed':'Passed'}</span></div></div>${logContent}</article>`;
  }).join('')}</div></section>`;
}

function executionCaseStatusLabel(status){
  return ({running:'Running',completed:'Completed',failed:'Failed',not_started:'Not Started',not_run:'Not Run'}[status]||'Not Started');
}
function executionSelector(s){
  // Keep the full catalog visible during and after execution so each test case has
  // an explicit lifecycle state. Inputs are locked while a run is active.
  if(!['running','ready','failed','completed'].includes(s.status)) return '';
  const cases=testCases();
  if(!cases.length) return '<div class="execution-select disabled"><div class="mini-title">Project test cases</div><span class="hint">No executable Playwright test cases were found in the project tests folder.</span></div>';
  const groups={};
  cases.forEach(x=>{(groups[x.issueId] ||= []).push(x)});
  const primary=String(session?.issueId||''); const issueIds=Object.keys(groups).sort((a,b)=>{const ap=a===primary?0:1;const bp=b===primary?0:1;return ap-bp||Number(a)-Number(b);});
  const total=cases.length;
  const statusByKey=new Map((s.output?.executionCaseStatuses||[]).map(x=>[x.key,x.status]));
  const running=s.status==='running';
  const selectedKeys=s.output?.selectedTestCases||[];
  return `<div class="execution-select">
    <div class="execution-select-head"><div><div class="mini-title">Project test cases <span class="case-count">${total}</span></div><span id="executionSelectionCount" class="selection-count">0 of ${total} selected</span></div><div class="execution-options"><label class="execution-option">Workers<input id="executionWorkers" type="number" min="1" step="1" value="${esc(s.output?.workers||8)}" ${running?'disabled':''}></label><label class="execution-option checkbox-option"><input id="executionHeadless" type="checkbox" ${s.output?.headless!==false?'checked':''} ${running?'disabled':''}><span>Headless</span></label><label class="select-all"><input id="executionSelectAll" type="checkbox" onchange="toggleAllExecutionCases(this.checked)" ${running?'disabled':''}><span>Select All</span></label></div></div>
    <div class="execution-checks issue-groups">${issueIds.map(issueId=>`<section class="execution-issue-group"><div class="execution-issue-title">Issue #${esc(issueId)} <span>${groups[issueId].length} test case${groups[issueId].length===1?'':'s'}</span></div>${groups[issueId].map(x=>{const st=statusByKey.get(x.key)||((selectedKeys.includes(x.key))?'running':(s.output?.executionCaseStatuses?'not_run':'not_started'));return `<label class="execution-case case-status-${esc(st)}" title="${esc(x.title)}"><input type="checkbox" name="testcase" value="${esc(x.key)}" ${selectedKeys.includes(x.key)?'checked':''} ${running?'disabled':''} onchange="updateExecutionSelection()"><span class="exec-case-id">${esc(x.id)}</span><span class="exec-case-title">${esc(x.title)}</span><span class="execution-case-status">${executionCaseStatusLabel(st)}</span></label>`}).join('')}</section>`).join('')}</div>
    <span class="hint">Selected cases show Running while Playwright is executing, then Completed or Failed. Cases not selected are shown as Not Started before any run and Not Run after an execution.</span>
  </div>`;
}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function squashExecutionDetails(s){
  const out=s?.output||{}; const r=out.result;
  if(!r) return '';
  const cases=Array.isArray(r.testCases)?r.testCases:[];
  const execs=Array.isArray(r.executions)?r.executions:[];
  return `<div class="squash-execution-review"><div class="review-head"><div><strong>Squash execution setup</strong><span>Execution folder → campaign → iteration${r.suite?' → test suite':''}</span></div><span class="review-badge">${execs.length} execution${execs.length===1?'':'s'}</span></div><div class="squash-execution-meta"><div><strong>Test Case Folder</strong><span>${esc(r.testCaseFolderId)}</span></div><div><strong>Project</strong><span>${esc(r.projectId||'—')}</span></div><div><strong>Campaign</strong><span>${esc(r.campaign?.name||'—')} (#${esc(r.campaign?.id||'—')})</span></div><div><strong>Iteration</strong><span>${esc(r.iteration?.name||'—')} (#${esc(r.iteration?.id||'—')})</span></div>${r.suite?`<div><strong>Test Suite</strong><span>${esc(r.suite.name||'—')} (#${esc(r.suite.id||'—')})</span></div>`:''}</div><div class="squash-case-list">${cases.map((tc,i)=>{const ex=execs[i]?.execution;return `<div class="squash-case"><span class="exec-case-id">${esc(tc.reference||tc.id)}</span><span class="exec-case-title">${esc(tc.name||tc.id)}</span><span class="execution-case-status">Execution #${esc(ex?.id||'—')}</span></div>`}).join('')}</div></div>`;
}
let markdownEditorState=null;
let strategyCompletionPrompted=false;
let scenarioCompletionPrompted=false;
// Completion prompts are workflow gates, not session-restore notifications.
// Creating a workspace can hydrate old completed artifacts; that must never pop a
// "Proceed" dialog. A prompt becomes eligible only after the user starts the stage,
// or when Run All explicitly reaches an already-completed stage.
const completionPromptEligible={scenarios:false,strategy:false};
function showScenarioCompletionPrompt(){
  if(!session||session.stages?.scenarios?.status!=='completed'||scenarioCompletionPrompted||!completionPromptEligible.scenarios)return;
  scenarioCompletionPrompted=true;
  const existing=document.getElementById('scenarioCompletionPrompt'); if(existing)existing.remove();
  const overlay=document.createElement('div'); overlay.id='scenarioCompletionPrompt'; overlay.className='editor-overlay strategy-completion-overlay';
  overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">✓</div><h3>Test Scenarios completed</h3><p>The scenarios are ready. What would you like to do next?</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="editScenarioFromPrompt()">Review & Edit Scenario</button><button class="primary" type="button" onclick="proceedAfterScenarios()">Proceed to Test Strategy</button></div><button class="strategy-completion-close" type="button" onclick="closeScenarioCompletionPrompt()" aria-label="Close">×</button></div>`;
  document.body.appendChild(overlay);
}
function closeScenarioCompletionPrompt(){document.getElementById('scenarioCompletionPrompt')?.remove()}
function editScenarioFromPrompt(){closeScenarioCompletionPrompt();editMarkdown('scenarios')}
async function proceedAfterScenarios(){closeScenarioCompletionPrompt();try{if(runAllState.sessionId===session?.id&&runAllState.waitingStage==='scenarios'){await continueRunAll();return}await startStage('strategy')}catch(e){alert(e.message);await refresh()}}
let healerFailurePrompted=false;
let executionOutcomePrompted=false;
let squashCompletionPrompted=false;
let squashCompletionPromptEligible=false;
function showExecutionOutcomePrompt(){
  if(!session||!['completed','failed'].includes(session.stages?.execution?.status)||executionOutcomePrompted)return;
  if(runAllState.active||runAllState.waitingStage)return;
  executionOutcomePrompted=true;
  const failed=session.stages.execution.status==='failed';
  const existing=document.getElementById('executionOutcomePrompt'); if(existing)existing.remove();
  const overlay=document.createElement('div'); overlay.id='executionOutcomePrompt'; overlay.className='editor-overlay strategy-completion-overlay';
  if(failed){
    overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">!</div><h3>Test Execution completed with failures</h3><p>One or more test cases failed. What would you like to do next?</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="healFromExecutionPrompt()">Heal Failed Test Case(s)</button><button class="primary" type="button" onclick="raiseDefectFromExecutionPrompt()">Raise Defect in GitLab</button></div><p class="hint">The defect reporter will use the failed test cases and the Playwright execution error details captured from this run.</p><button class="strategy-completion-close" type="button" onclick="closeExecutionOutcomePrompt()" aria-label="Close">×</button></div>`;
  } else {
    overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">✓</div><h3>Test Execution completed successfully</h3><p>All selected test cases passed. Test Healer and Defect Reporting are not required for this run.</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="closeExecutionOutcomePrompt()">Stop</button><button class="primary" type="button" onclick="proceedAfterExecutionSuccess()">Proceed to Squash Test Case Execution</button></div><button class="strategy-completion-close" type="button" onclick="closeExecutionOutcomePrompt()" aria-label="Close">×</button></div>`;
  }
  document.body.appendChild(overlay);
}
function closeExecutionOutcomePrompt(){document.getElementById('executionOutcomePrompt')?.remove()}
async function healFromExecutionPrompt(){
  closeExecutionOutcomePrompt();
  try{
    session=await startStage('healer');
    if(session?.stages?.healer?.status==='failed'){showHealerFailurePrompt();return;}
    if(session?.stages?.healer?.status==='waiting_for_approval'){render();return;}
    if(session?.stages?.healer?.status==='completed'){render();showHealerCompletionPrompt();}
  }catch(e){alert(e.message);await refresh();if(session?.stages?.healer?.status==='failed')showHealerFailurePrompt()}
}
async function raiseDefectFromExecutionPrompt(){
  closeExecutionOutcomePrompt();
  try{
    session=await api(`/api/session/${session.id}/stage/defect/start`,{method:'POST',body:'{}'});
    render();
    if(session?.stages?.defect?.status==='failed'){alert(session.stages.defect.error||session.stages.defect.message||'Defect creation failed.');return;}
    showDefectCompletionPrompt();
  }catch(e){alert(e.message);await refresh()}
}
async function proceedAfterExecutionSuccess(){
  closeExecutionOutcomePrompt();
  try{session=await startStage('squashExecution');if(session)render();}catch(e){alert(e.message);await refresh()}
}
function showSquashCompletionPrompt(){
  if(!session||session.stages?.squashExecution?.status!=='completed'||squashCompletionPrompted||!squashCompletionPromptEligible)return;
  squashCompletionPrompted=true;
  const existing=document.getElementById('squashCompletionPrompt'); if(existing)existing.remove();
  const overlay=document.createElement('div'); overlay.id='squashCompletionPrompt'; overlay.className='editor-overlay strategy-completion-overlay';
  overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">✓</div><h3>Squash Test Case Execution completed</h3><p>The SQA/Squash test execution has completed successfully. Do you want to commit the project changes to GitLab?</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="stopAfterSquashCompletion()">No, don't commit</button><button class="primary" type="button" onclick="commitAfterSquashCompletion()">Yes, commit to GitLab</button></div><button class="strategy-completion-close" type="button" onclick="stopAfterSquashCompletion()" aria-label="Close">×</button></div>`;
  document.body.appendChild(overlay);
}
function closeSquashCompletionPrompt(){document.getElementById('squashCompletionPrompt')?.remove()}
function stopAfterSquashCompletion(){closeSquashCompletionPrompt();if(runAllState.sessionId===session?.id){runAllState.active=false;runAllState.waitingStage=null;setRunAllStatus('Run All Stages stopped. GitLab commit was not requested.','paused');}}
async function commitAfterSquashCompletion(){
  closeSquashCompletionPrompt();
  try{
    const started=await startStage('gitlabCommit',{silent:true});
    if(!started) return;
    if(started.stages?.gitlabCommit?.status!=='waiting_for_approval') throw new Error(started.stages?.gitlabCommit?.error||started.stages?.gitlabCommit?.message||'GitLab Commit is not ready for approval.');
    session=await api(`/api/session/${session.id}/stage/gitlabCommit/approve`,{method:'POST',body:'{}'});
    render();
    if(session?.stages?.gitlabCommit?.status==='completed'){
      if(runAllState.sessionId===session.id){runAllState.active=false;runAllState.waitingStage=null;setRunAllStatus('GitLab commit completed. Workflow finished.','completed');}
    } else if(session?.stages?.gitlabCommit?.status==='failed') alert(session.stages.gitlabCommit.error||'GitLab commit failed.');
  }catch(e){alert(e.message);await refresh()}
}
function showHealerFailurePrompt(){
  if(!session||session.stages?.healer?.status!=='failed'||healerFailurePrompted)return;
  healerFailurePrompted=true;
  const existing=document.getElementById('healerFailurePrompt'); if(existing)existing.remove();
  const overlay=document.createElement('div'); overlay.id='healerFailurePrompt'; overlay.className='editor-overlay strategy-completion-overlay';
  overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">!</div><h3>Test Healing failed</h3><p>The Test Healer could not complete the repair. What would you like to do?</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="retryHealerFromPrompt()">Retry Test Healing</button><button class="primary" type="button" onclick="raiseDefectFromPrompt()">Raise Defect in GitLab</button></div><p class="hint">The defect will be created as a <strong>Task child item</strong> under the current GitLab requirement, with a <strong>[Defect]</strong> title prefix.</p><button class="strategy-completion-close" type="button" onclick="closeHealerFailurePrompt()" aria-label="Close">×</button></div>`;
  document.body.appendChild(overlay);
}
function closeHealerFailurePrompt(){document.getElementById('healerFailurePrompt')?.remove()}
async function retryHealerFromPrompt(){
  const resumeRunAll=runAllState.sessionId===session?.id&&['healer','execution'].includes(runAllState.waitingStage);
  closeHealerFailurePrompt(); healerFailurePrompted=false;
  try{
    if(resumeRunAll){runAllState.waitingStage=null;runAllState.active=true;setRunAllStatus('Retrying Test Healer…','running');}
    await startStage('healer',{all:true,silent:true});
    await refresh();
    if(session?.stages?.healer?.status==='failed'){showHealerFailurePrompt();return;}
    if(resumeRunAll){showRunAllCompletionPrompt('healer','completed');}
  }catch(e){alert(e.message);await refresh();if(session?.stages?.healer?.status==='failed')showHealerFailurePrompt()}
}
function showDefectCompletionPrompt(){
  if(!session||session.stages?.defect?.status!=='completed')return;
  const existing=document.getElementById('defectCompletionPrompt'); if(existing)existing.remove();
  const overlay=document.createElement('div'); overlay.id='defectCompletionPrompt'; overlay.className='editor-overlay strategy-completion-overlay';
  overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">✓</div><h3>GitLab Defect Reporting completed</h3><p>The defect Task has been created successfully under the current requirement. Do you want to proceed with <strong>Squash Test Case Execution</strong>?</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="closeDefectCompletionPrompt()">Stop</button><button class="primary" type="button" onclick="proceedAfterDefect()">Proceed to Squash Test Case Execution</button></div><button class="strategy-completion-close" type="button" onclick="closeDefectCompletionPrompt()" aria-label="Close">×</button></div>`;
  document.body.appendChild(overlay);
}
function closeDefectCompletionPrompt(){document.getElementById('defectCompletionPrompt')?.remove()}
async function proceedAfterDefect(){
  closeDefectCompletionPrompt();
  try{
    if(runAllState.sessionId===session?.id&&runAllState.waitingStage==='defect'){await proceedRunAllFromPrompt();return;}
    session=await startStage('squashExecution');
    if(session)render();
  }catch(e){alert(e.message);await refresh()}
}
async function raiseDefectFromPrompt(){
  const resumeRunAll=runAllState.sessionId===session?.id&&['healer','execution'].includes(runAllState.waitingStage);
  closeHealerFailurePrompt();
  try{
    if(resumeRunAll){runAllState.waitingStage=null;runAllState.active=false;setRunAllStatus('Creating GitLab defect…','paused');}
    session=await api(`/api/session/${session.id}/stage/defect/start`,{method:'POST',body:'{}'});
    render();
    if(session?.stages?.defect?.status==='failed'){alert(session.stages.defect.error||session.stages.defect.message||'Defect creation failed.');return;}
    if(resumeRunAll){runAllState.index=RUN_ALL_SEQUENCE.indexOf('defect');await refresh();showDefectCompletionPrompt();}
    else {showDefectCompletionPrompt();}
  }catch(e){alert(e.message);await refresh()}
}


function showHealerCompletionPrompt(){
  if(!session||session.stages?.healer?.status!=='completed')return;
  const existing=document.getElementById('healerCompletionPrompt'); if(existing)existing.remove();
  const overlay=document.createElement('div'); overlay.id='healerCompletionPrompt'; overlay.className='editor-overlay strategy-completion-overlay';
  overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">✓</div><h3>Test Healer completed</h3><p>The healing step is complete. Do you want to proceed with <strong>Squash Test Case Execution</strong>?</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="closeHealerCompletionPrompt()">Stop</button><button class="primary" type="button" onclick="proceedAfterHealerCompletion()">Proceed to Squash Test Case Execution</button></div><button class="strategy-completion-close" type="button" onclick="closeHealerCompletionPrompt()" aria-label="Close">×</button></div>`;
  document.body.appendChild(overlay);
}
function closeHealerCompletionPrompt(){document.getElementById('healerCompletionPrompt')?.remove()}
async function proceedAfterHealerCompletion(){closeHealerCompletionPrompt();try{session=await startStage('squashExecution');if(session)render();}catch(e){alert(e.message);await refresh()}}

function showStrategyCompletionPrompt(){
  if(!session||session.stages?.strategy?.status!=='completed'||strategyCompletionPrompted||!completionPromptEligible.strategy)return;
  strategyCompletionPrompted=true;
  const existing=document.getElementById('strategyCompletionPrompt'); if(existing)existing.remove();
  const overlay=document.createElement('div'); overlay.id='strategyCompletionPrompt'; overlay.className='editor-overlay strategy-completion-overlay';
  overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">✓</div><h3>Test Strategy completed</h3><p>Your test strategy is approved. What would you like to do next?</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="editStrategyFromPrompt()">Edit Test Strategy</button><button class="primary" type="button" onclick="proceedAfterStrategy()">Proceed to Squash Upload</button></div><button class="strategy-completion-close" type="button" onclick="closeStrategyCompletionPrompt()" aria-label="Close">×</button></div>`;
  document.body.appendChild(overlay);
}
function closeStrategyCompletionPrompt(){document.getElementById('strategyCompletionPrompt')?.remove()}
function editStrategyFromPrompt(){closeStrategyCompletionPrompt();editMarkdown('strategy')}
async function proceedAfterStrategy(){closeStrategyCompletionPrompt();try{if(runAllState.sessionId===session?.id&&runAllState.waitingStage==='strategy'){await continueRunAll();return}await startStage('squash')}catch(e){alert(e.message);await refresh()}}

function splitMdCells(line){return line.trim().replace(/^\|/,'').replace(/\|$/,'').split(/(?<!\\)\|/).map(x=>x.replace(/\\\|/g,'|').trim())}
function mdCell(v){return String(v??'').replace(/\|/g,'\\|').replace(/\r?\n/g,'<br>')}
function parseScenarioForEditor(content){
  const lines=content.replace(/\r/g,'').split('\n');
  const rows=[];
  for(let i=0;i<lines.length;i++){
    const m=lines[i].match(/^###\s+(TC-\d+)\s*:\s*(.*)$/i); if(!m) continue;
    const id=m[1].toUpperCase(), title=m[2].trim();
    let category='',priority='',pre='',expected='',steps=[];
    const end=lines.findIndex((x,j)=>j>i && (/^###\s+TC-\d+/i.test(x)||/^##\s+\d+\./.test(x)));
    const block=lines.slice(i,end<0?lines.length:end);
    for(const line of block){
      let x=line.match(/^[-*]\s+\*\*Category\*\*\s*:\s*(.*)$/i); if(x){category=x[1].trim();continue;}
      x=line.match(/^[-*]\s+\*\*Priority\*\*\s*:\s*(.*)$/i); if(x){priority=x[1].trim();continue;}
      x=line.match(/^[-*]\s+\*\*Preconditions\*\*\s*:\s*(.*)$/i); if(x){pre=x[1].trim();continue;}
    }
    const si=block.findIndex(x=>/^[-*]\s+\*\*Steps\*\*\s*:/i.test(x));
    const ei=block.findIndex(x=>/^[-*]\s+\*\*Expected Results\*\*\s*:/i.test(x));
    if(ei>=0){
      const first=block[ei].replace(/^[-*]\s+\*\*Expected Results\*\*\s*:\s*/i,'').trim();
      const tail=block.slice(ei+1).map(x=>x.replace(/^\s*[-*]\s*/,'').trim()).filter(Boolean);
      expected=[first,...tail].filter(Boolean).join('\n');
    }
    if(si>=0){for(const line of block.slice(si+1,ei>=0?ei:block.length)){const x=line.match(/^\s*\d+[.)]\s+(.*)$/);if(x)steps.push(x[1].trim())}}
    if(!steps.length){
      const inline=block.find(x=>/^[-*]\s+\*\*Steps\*\*\s*:/i.test(x));
      if(inline){const tail=inline.replace(/^[-*]\s+\*\*Steps\*\*\s*:\s*/i,'');steps=[...tail.matchAll(/(?:^|\s)(\d+)[.)]\s+(.*?)(?=\s+\d+[.)]\s+|\s+\*\*Expected Results\*\*|$)/g)].map(x=>x[2].trim())}
    }
    rows.push({id,title,category,priority,pre,steps,expected});
  }
  return {header:lines.slice(0,lines.findIndex(x=>/^##\s+1\.\s+Scenario Summary Matrix/i)),rows};
}
function parseStrategyForEditor(content){
  const lines=content.replace(/\r/g,'').split('\n');
  const start=lines.findIndex(x=>/^##\s+1\.\s+Scope\s*&\s*Automation\s+Decision\s+Matrix/i.test(x));
  const end=lines.findIndex((x,i)=>i>start && /^##\s+2\./.test(x));
  const rows=[];
  const parseRow=(line)=>{const c=splitMdCells(line);if(c.length<2)return;const id=String(c[0]||'').replace(/\*/g,'').trim().toUpperCase();if(!/^TC-\d+$/.test(id))return;const decision=String(c[2]||'').replace(/\*/g,'').trim();if(decision && !/^(AUTOMATE|OFFLOAD)\b/i.test(decision))return;rows.push({id,description:c[1]||'',decision:decision||'OFFLOAD (Unit/API/Omit)',tier:c[3]||'Regression',justification:c[4]||''});};
  if(start>=0){for(const line of lines.slice(start,end<0?lines.length:end))parseRow(line);}
  // If the proposal is missing its decision-matrix heading/table, keep Edit Strategy
  // usable by falling back to the already-generated Test Scenarios catalog.
  if(!rows.length && Array.isArray(session?.stages?.scenarios?.output?.scenarios)){
    for(const scenario of session.stages.scenarios.output.scenarios){
      if(!scenario?.id)continue;
      rows.push({id:String(scenario.id).toUpperCase(),description:String(scenario.summary||scenario.title||scenario.id),decision:'OFFLOAD (Unit/API/Omit)',tier:String(scenario.suggestedLayer||'Regression'),justification:'Available from Test Scenarios; choose whether to automate.'});
    }
  }
  const unique=[]; const seen=new Set();
  for(const row of rows){if(!seen.has(row.id)){seen.add(row.id);unique.push(row);}}
  const candidateMap=new Map();
  const candidateIdx=[];
  lines.forEach((line,i)=>{const m=line.match(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/i);if(m)candidateIdx.push({i,id:m[1].toUpperCase()});});
  for(let i=0;i<candidateIdx.length;i++){
    const cur=candidateIdx[i], nextCandidate=candidateIdx[i+1]?.i ?? lines.length;
    const section3=lines.findIndex((line,j)=>j>cur.i && /^##\s+3\./.test(line));
    const endBlock=section3>=0?Math.min(nextCandidate,section3):nextCandidate;
    candidateMap.set(cur.id,lines.slice(cur.i,endBlock).join('\n').trim());
  }
  return {lines,rows:unique,candidateMap,start,end};
}
function scenarioEditorHtml(state){
  return `<div class="structured-editor"><div class="structured-toolbar"><span class="hint">Edit each test case as a row. Steps are one action per line; expected results are kept separately.</span><button class="ghost small" type="button" onclick="addScenarioEditorRow()">+ Add test case</button></div><div class="structured-table-wrap"><table class="structured-table"><thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Priority</th><th>Preconditions</th><th>Steps</th><th>Expected Results</th><th></th></tr></thead><tbody id="structuredEditorBody">${state.rows.map((r,i)=>`<tr data-row="${i}"><td><input data-f="id" value="${esc(r.id)}"></td><td><input data-f="title" value="${esc(r.title)}"></td><td><input data-f="category" value="${esc(r.category)}"></td><td><select data-f="priority"><option ${r.priority==='P0'?'selected':''}>P0</option><option ${r.priority==='P1'?'selected':''}>P1</option><option ${r.priority==='P2'?'selected':''}>P2</option></select></td><td><textarea data-f="pre">${esc(r.pre)}</textarea></td><td><textarea data-f="steps">${esc(r.steps.join('\n'))}</textarea></td><td><textarea data-f="expected">${esc(r.expected)}</textarea></td><td><button class="icon-button danger" type="button" onclick="removeStructuredRow(this)" title="Remove">×</button></td></tr>`).join('')}</tbody></table></div></div>`;
}
function strategyEditorHtml(state){
  return `<div class="structured-editor"><div class="structured-toolbar"><div><strong>Test cases</strong><span class="hint">Edit Test Strategy using the same row-based test-case view as Test Scenarios. You can add or remove cases. Added cases must already exist in Test Scenarios.</span></div><button class="ghost small" type="button" onclick="addStrategyEditorRow()">+ Add test case</button></div><div class="structured-table-wrap"><table class="structured-table strategy-structured"><thead><tr><th>ID</th><th>Test Case</th><th>Decision</th><th>Tier / Frequency</th><th>Justification</th><th></th></tr></thead><tbody id="structuredEditorBody">${state.rows.map((r,i)=>`<tr data-row="${i}"><td><input data-f="id" value="${esc(r.id)}"></td><td><input data-f="description" value="${esc(r.description)}"></td><td><select data-f="decision"><option ${/^AUTOMATE/i.test(r.decision)?'selected':''}>AUTOMATE (E2E)</option><option ${/^OFFLOAD/i.test(r.decision)?'selected':''}>OFFLOAD (Unit/API/Omit)</option></select></td><td><input data-f="tier" value="${esc(r.tier)}"></td><td><textarea data-f="justification">${esc(r.justification)}</textarea></td><td><button class="icon-button danger" type="button" onclick="removeStructuredRow(this)" title="Remove">×</button></td></tr>`).join('')}</tbody></table></div></div>`;
}
function addStrategyEditorRow(){
  const body=document.getElementById('structuredEditorBody'); if(!body||markdownEditorState?.name!=='strategy')return;
  const current=new Set([...body.querySelectorAll('tr')].map(tr=>String(tr.querySelector('[data-f="id"]')?.value||'').trim().toUpperCase()));
  const source=session?.stages?.scenarios?.output?.scenarios||[];
  const candidate=source.find(x=>x?.id&&!current.has(String(x.id).toUpperCase()));
  if(!candidate){alert('All Test Scenarios are already present in Test Strategy. To create a brand-new test case, add it in Edit Scenario first.');return;}
  const tr=document.createElement('tr');
  tr.dataset.row=String(body.children.length);
  tr.innerHTML=`<td><input data-f="id" value="${esc(candidate.id)}"></td><td><input data-f="description" value="${esc(candidate.summary||candidate.title||candidate.id)}"></td><td><select data-f="decision"><option selected>AUTOMATE (E2E)</option><option>OFFLOAD (Unit/API/Omit)</option></select></td><td><input data-f="tier" value="${esc(candidate.suggestedLayer||'Regression')}"></td><td><textarea data-f="justification">User added this test case from the Test Scenario list.</textarea></td><td><button class="icon-button danger" type="button" onclick="removeStructuredRow(this)" title="Remove">×</button></td>`;
  body.appendChild(tr);
}
function collectStructuredRows(){return [...document.querySelectorAll('#structuredEditorBody tr')].map(tr=>{const o={};tr.querySelectorAll('[data-f]').forEach(el=>o[el.dataset.f]=el.value);if(o.steps!==undefined)o.steps=o.steps.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);return o;}).filter(x=>x.id)}
function addScenarioEditorRow(){const body=document.getElementById('structuredEditorBody');if(!body)return;const i=body.children.length;const tr=document.createElement('tr');tr.dataset.row=String(i);tr.innerHTML=`<td><input data-f="id" value="TC-${String(i+1).padStart(3,'0')}"></td><td><input data-f="title" value=""></td><td><input data-f="category" value="Happy Path"></td><td><select data-f="priority"><option selected>P0</option><option>P1</option><option>P2</option></select></td><td><textarea data-f="pre"></textarea></td><td><textarea data-f="steps"></textarea></td><td><textarea data-f="expected"></textarea></td><td><button class="icon-button danger" type="button" onclick="removeStructuredRow(this)">×</button></td>`;body.appendChild(tr)}
function removeStructuredRow(btn){btn.closest('tr')?.remove()}
function serializeScenarioRows(state,rows){
  const header=state.header.length?state.header:['# E2E Test Scenarios'];
  const summary=['','## 1. Scenario Summary Matrix','', '| Scenario ID | Category | Summary Description | Priority | Suggested Layer |','| :--- | :--- | :--- | :--- | :--- |',...rows.map(r=>`| **${mdCell(r.id)}** | ${mdCell(r.category)} | ${mdCell(r.title)} | ${mdCell(r.priority)} | E2E |`)];
  const details=['','## 2. Detailed Test Scenarios','',...rows.flatMap(r=>[`### ${r.id}: ${r.title}`,`- **Category**: ${r.category}`,`- **Priority**: ${r.priority}`,`- **Preconditions**: ${r.pre}`,`- **Steps**:`,...(r.steps||[]).map((x,i)=>`  ${i+1}. ${x}`),`- **Expected Results**: ${r.expected||'The scenario behaves as specified in the source scenario document.'}`,''])];
  return [...header,...summary,...details].join('\n');
}
function serializeStrategyRows(state,rows){
  const lines=state.lines; const start=state.start; const end=state.end<0?lines.length:state.end;
  const prefix=lines.slice(0,start); const suffix=lines.slice(end);
  const matrix=['## 1. Scope & Automation Decision Matrix','', '| Scenario ID | Scenario Description | Automation Decision | Tier / Frequency | Justification |','| :--- | :--- | :--- | :--- | :--- |',...rows.map(r=>`| **${mdCell(r.id)}** | ${mdCell(r.description)} | **${mdCell(r.decision)}** | ${mdCell(r.tier)} | ${mdCell(r.justification)} |`)];
  const section2=lines.slice(start,end).join('\n').match(/##\s+2\.[\s\S]*/)?.[0]||'';
  let candidateText='';
  const candidates=rows.filter(r=>/^AUTOMATE/i.test(r.decision));
  if(candidates.length){candidateText='\n## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)\n\n### Initially Recommended Test Cases\n\n| Scenario ID | Test Case | Priority | Decision | Tier / Frequency |\n| :--- | :--- | :--- | :--- | :--- |\n'+candidates.map(r=>`| **${r.id}** | ${mdCell(r.description)} | P0 | **AUTOMATE (E2E)** | ${mdCell(r.tier)} |`).join('\n')+'\n\n'+candidates.map(r=>state.candidateMap.get(r.id)||`### Candidate ${r.id}: ${r.description}\n`).join('\n\n');}
  return [...prefix,...matrix,candidateText,...suffix].join('\n');
}
async function editMarkdown(n){
  if(!session)return;
  try{
    const d=await api(`/api/session/${session.id}/artifact/${n}`); const existing=document.getElementById('markdownEditorOverlay'); if(existing)existing.remove();
    markdownEditorState={name:n,path:d.path,content:d.content||'',data:n==='scenarios'?parseScenarioForEditor(d.content||''):parseStrategyForEditor(d.content||'')};
    const label=n==='scenarios'?'Test Scenarios':'Test Strategy';
    const body=n==='scenarios'?scenarioEditorHtml(markdownEditorState.data):strategyEditorHtml(markdownEditorState.data);
    const overlay=document.createElement('div'); overlay.id='markdownEditorOverlay'; overlay.className='editor-overlay';
    overlay.innerHTML=`<div class="markdown-editor structured-editor-modal"><div class="editor-head"><div><strong>Edit ${label}</strong><span>${esc(d.path)}</span></div><div><button class="ghost small" type="button" onclick="closeMarkdownEditor()">Close</button></div></div><div id="structuredEditorHost">${body}</div><textarea id="markdownEditorText" class="raw-editor" spellcheck="false" hidden></textarea><div class="editor-actions"><span id="editorStatus" class="editor-status">Changes will be written back as structured Markdown.</span><div><button class="ghost" type="button" onclick="closeMarkdownEditor()">Cancel</button><button class="primary" type="button" onclick="saveMarkdownEdit('${n}')">Save changes</button></div></div></div>`;
    document.body.appendChild(overlay);
  }catch(e){alert(e.message)}
}
function toggleStructuredRaw(){const host=$('structuredEditorHost'),raw=$('markdownEditorText');if(!host||!raw)return;const showing=!raw.hidden;if(!showing){const rows=collectStructuredRows();raw.value=markdownEditorState.name==='scenarios'?serializeScenarioRows(markdownEditorState.data,rows):serializeStrategyRows(markdownEditorState.data,rows);}host.hidden=showing;raw.hidden=!showing}
function closeMarkdownEditor(){document.getElementById('markdownEditorOverlay')?.remove()}
async function saveMarkdownEdit(n){
  const status=$('editorStatus'); if(!status)return;
  try{
    status.textContent='Saving…';
    const raw=$('markdownEditorText');
    const content=raw && !raw.hidden ? raw.value : (n==='scenarios'?serializeScenarioRows(markdownEditorState.data,collectStructuredRows()):serializeStrategyRows(markdownEditorState.data,collectStructuredRows()));
    const d=await api(`/api/session/${session.id}/artifact/${n}`,{method:'PUT',body:JSON.stringify({content})});
    status.textContent=`Saved ${d.path}`; session=await api('/api/session/'+session.id); stageSignature=''; if(n==='strategy'){strategyCompletionPrompted=false;completionPromptEligible.strategy=false;} if(n==='scenarios'){scenarioCompletionPrompted=false;completionPromptEligible.scenarios=false;} render(); setTimeout(()=>{closeMarkdownEditor();},450);
  }catch(e){status.textContent=`Save failed: ${e.message}`;status.classList.add('error')}
}

function render(){
  if(!session)return;
  $('sessionBadge').textContent=`Issue #${session.issueId}`;
  const runAllButton=$('runAllStages');
  if(runAllButton){runAllButton.disabled=runAllState.active||!session;runAllButton.textContent=runAllState.active?'Running All Stages':'Run All Stages';}
  if(runAllState.active && runAllState.waitingStage===null && runAllState.index<RUN_ALL_SEQUENCE.length){const currentName=RUN_ALL_SEQUENCE[runAllState.index];const currentStatus=session.stages?.[currentName]?.status;if(currentStatus) setRunAllStatus(`Running ${runAllState.index+1}/${RUN_ALL_SEQUENCE.length}: ${labels[currentName]}`,'running');}
  $('sessionBadge').textContent=`Issue #${session.issueId}`;
  $('sessionInfo').innerHTML=`<span class="requirement-context"><strong>Working requirement</strong> #${esc(session.issueId)}${session.issueTitle?` — ${esc(session.issueTitle)}`:''}</span><span>Session ${esc(session.id)}</span><span>Test Case Folder ${esc(session.testCaseFolderId||session.folderId)}</span>`;
  const sig=JSON.stringify(Object.entries(session.stages).map(([n,s])=>[n,s.status,s.message,s.error,!!s.output,n==='businessReview'?JSON.stringify({review:s.output?.review||{},feedback:s.output?.feedback||'',approvalStatus:s.output?.approvalStatus||''}):n==='strategy'?strategyCases().length:0,n==='scriptGeneration'?JSON.stringify(s.output?.executionCases||s.output?.testCases||[]):'',n==='execution'?JSON.stringify({catalog:s.output?.catalog||[],selected:s.output?.selectedTestCases||[],results:s.output?.executionCaseResults||[],caseStatuses:s.output?.executionCaseStatuses||[]}):n==='healer'?JSON.stringify({cases:s.output?.failedTestCases||[],proposal:s.output?.proposalMarkdown||s.output?.proposal||'',status:s.status}):n==='defect'?JSON.stringify({status:s.status,url:s.output?.defectUrl||'',raw:s.output?.raw||''}):n==='squashExecution'?JSON.stringify({result:s.output?.result||{},status:s.status}):'']));
  if(sig!==stageSignature){
    stageSignature=sig;
    const box=$('stages'); box.innerHTML='';
    Object.entries(session.stages).forEach(([n,s],i)=>{
      let controls='';
      if(s.status==='running') {
        controls+=`<button class="primary small stop-btn" onclick="event.stopPropagation();stopStage('${n}')">Stop stage</button>`;
      } else if(['ready','failed','completed'].includes(s.status)) controls+=n==='execution'
        ?`<button id="executionStart" class="primary small" disabled onclick="event.stopPropagation();startStage('execution')">${s.status==='completed'?'Re-run selected tests':'Run selected tests'}</button>`
        :`<button class="primary small" onclick="event.stopPropagation();startStage('${n}')">${s.status==='failed'?'Retry stage':s.status==='completed'?'Re-run Stage':'Run Stage'}</button>`;
      if(s.status==='waiting_for_approval'){
        const label=n==='businessReview'?'Approve':n==='strategy'?'Approve Strategy':'Approve repair';
        const healerReady=n==='healer' ? !!(s.output?.proposalMarkdown || s.output?.proposal || s.output?.proposalHtml) : true;
        controls+=`<div class="approval-actions" onclick="event.stopPropagation()"><button class="approve-btn" ${healerReady?'':'disabled title="A reviewable healing proposal is required before approval"'} onclick="approval('${n}','approve')"><span>✓</span>${label}</button><button class="reject-btn" onclick="approval('${n}','reject')">Reject</button></div>`;
      } else if(n==='strategy' && s.status==='completed'){
        const count=s.output?.includedTestCases?.length ?? s.output?.proposal?.strategies?.length ?? 0;
        controls+=`<div class="approval-actions" onclick="event.stopPropagation()"><button class="approve-btn" disabled title="Strategy already approved"><span>✓</span> Strategy Approved (${count})</button></div>`;
      }
      const isExpanded=expandedStages.has(n);
      const headerControls=`<div class="stage-header-actions"><span class="status ${s.status}">${stageStatusLabel(s.status)}</span>${reportLink(n,s)}${controls}<button class="stage-toggle" type="button" aria-label="${isExpanded?'Collapse':'Expand'} ${esc(labels[n])}" aria-expanded="${isExpanded}" onclick="event.stopPropagation();toggleStage('${n}')">${isExpanded?'−':'+'}</button></div>`;
      box.insertAdjacentHTML('beforeend',`
        <article class="stage-card${isExpanded?' expanded':''}" data-stage="${n}">
          <div class="stage-header" onclick="toggleStage('${n}')">
            <div class="stage-index">${String(i+1).padStart(2,'0')}</div>
            <div class="stage-summary">
              <div class="stage-top"><div><h3>${labels[n]}</h3><p>${descriptions[n]}</p></div></div>
            </div>
            ${headerControls}
          </div>
          <div class="stage-body"${isExpanded?'':' hidden'}>
            <div class="stage-bottom"><span>${esc(stageMessage(s,n))}</span></div>
            ${n==='businessReview'?renderBusinessReview(s):''}${n==='strategy'?renderStrategyReview(s):''}${n==='execution'?executionSelector(s)+executionResults(s):''}${n==='healer'?healerReview(s):''}${n==='defect'&&s.status==='completed'?`<div class="healer-proposal"><div class="mini-title">Defect created</div><span class="hint">${esc(s.output?.defectUrl||'GitLab child Task created under the requirement.')}</span></div>`:''}${n==='squashExecution'?squashExecutionDetails(s):''}${n==='healer'&&s.status==='failed'?`<details class="technical-details"><summary>View technical diagnostic</summary><pre class="healer-proposal-raw">${esc(s.error||s.message||'No diagnostic details available.')}</pre></details>`:''}
          </div>
        </article>`);
    });
    if(document.querySelector('input[name="testcase"]')) updateExecutionSelection();
  }
  renderEvents();
  if(session?.stages?.scenarios?.status==='completed') setTimeout(showScenarioCompletionPrompt,0);
  if(session?.stages?.strategy?.status==='completed') setTimeout(showStrategyCompletionPrompt,0);
  if(['completed','failed'].includes(session?.stages?.execution?.status) && !runAllState.active && !runAllState.waitingStage) setTimeout(showExecutionOutcomePrompt,0);
  if(session?.stages?.squashExecution?.status==='completed' && !runAllState.active && !runAllState.waitingStage) setTimeout(showSquashCompletionPrompt,0);
  if(session?.stages?.healer?.status==='failed') setTimeout(showHealerFailurePrompt,0);
}

function showExecutionFailureRunAllPrompt(){
  if(!session||session.stages?.execution?.status!=='failed')return;
  const existing=document.getElementById('executionOutcomePrompt'); if(existing)existing.remove();
  const overlay=document.createElement('div'); overlay.id='executionOutcomePrompt'; overlay.className='editor-overlay strategy-completion-overlay';
  overlay.innerHTML=`<div class="strategy-completion-dialog" role="dialog" aria-modal="true"><div class="strategy-completion-icon">!</div><h3>Test Execution completed with failures</h3><p>One or more test cases failed. What would you like to do next?</p><div class="strategy-completion-actions"><button class="ghost" type="button" onclick="healFromExecutionRunAllPrompt()">Heal Failed Test Case(s)</button><button class="primary" type="button" onclick="raiseDefectFromExecutionRunAllPrompt()">Raise Defect in GitLab</button></div><p class="hint">The defect reporter will use the failed test cases and the Playwright execution error details captured from this run.</p><button class="strategy-completion-close" type="button" onclick="stopExecutionRunAllPrompt()" aria-label="Close">×</button></div>`;
  document.body.appendChild(overlay);
}
function stopExecutionRunAllPrompt(){closeExecutionOutcomePrompt();runAllState.active=false;runAllState.waitingStage=null;setRunAllStatus('Run All Stages stopped by user','failed')}
async function healFromExecutionRunAllPrompt(){
  closeExecutionOutcomePrompt();
  try{runAllState.waitingStage=null;runAllState.active=true;setRunAllStatus('Starting Test Healer…','running');await startStage('healer',{all:true,silent:true});await refresh();if(session?.stages?.healer?.status==='failed'){runAllState.active=false;runAllState.waitingStage='healer';showHealerFailurePrompt();return;}if(session?.stages?.healer?.status==='waiting_for_approval'){runAllState.active=false;runAllState.waitingStage='healer';render();return;}if(session?.stages?.healer?.status==='completed'){runAllState.active=false;runAllState.waitingStage='healer';showRunAllCompletionPrompt('healer','completed');}}catch(e){runAllState.active=false;alert(e.message);await refresh()}}
async function raiseDefectFromExecutionRunAllPrompt(){
  closeExecutionOutcomePrompt();
  try{runAllState.waitingStage=null;runAllState.active=false;setRunAllStatus('Creating GitLab defect…','paused');session=await api(`/api/session/${session.id}/stage/defect/start`,{method:'POST',body:'{}'});render();if(session?.stages?.defect?.status==='failed'){alert(session.stages.defect.error||session.stages.defect.message||'Defect creation failed.');return;}runAllState.index=RUN_ALL_SEQUENCE.indexOf('defect');runAllState.waitingStage='defect';showDefectCompletionPrompt();}catch(e){alert(e.message);await refresh()}}

function renderEvents(){
  const el=$('events'); if(!el)return;
  const wasNearBottom=el.scrollHeight-el.scrollTop-el.clientHeight<28;
  const events=session?.events||[];
  el.innerHTML=events.map((e,i)=>{
    const time=new Date(e.at).toLocaleTimeString();
    const stream=e.type?.startsWith('backend.')?` ${e.type.replace('backend.','').toUpperCase()}:`:'';
    const line=`${time}${e.stage?` [${e.stage}]`:''}${stream} ${e.message}`;
    return `<div class="event-line"><span class="event-text">${esc(line)}</span><button type="button" class="event-copy" title="Copy this log entry" onclick="event.preventDefault();event.stopPropagation();copyLogEntry(${i})">Copy</button></div>`;
  }).join('');
  if(wasNearBottom)el.scrollTop=el.scrollHeight;
}
function toggleExecutionLog(id,button){const el=$(id);if(!el)return;const opening=el.hidden;el.hidden=!opening;button.textContent=opening?'Hide log':'Show log';button.setAttribute('aria-expanded',String(opening));}
async function clearLogsView(){
  if(!session?.id){$('events').innerHTML='';return;}
  try{
    session=await api('/api/session/'+session.id+'/events/clear',{method:'POST',body:'{}'});
    renderEvents();
  }catch(e){alert(e.message)}
}
function logText(){
  return [...document.querySelectorAll('#events .event-text')].map(x=>x.textContent||'').join('\n');
}
function selectLogs(){
  const container=$('events'); if(!container)return;
  const r=document.createRange(); r.selectNodeContents(container);
  const s=window.getSelection(); s.removeAllRanges(); s.addRange(r);
}
async function copyText(text){
  try{await navigator.clipboard.writeText(text||'');}
  catch{
    const ta=document.createElement('textarea'); ta.value=text||''; document.body.appendChild(ta);
    ta.select(); document.execCommand('copy'); ta.remove();
  }
}
async function copyLogEntry(index){
  const events=session?.events||[]; const e=events[index]; if(!e)return;
  const time=new Date(e.at).toLocaleTimeString();
  const stream=e.type?.startsWith('backend.')?` ${e.type.replace('backend.','').toUpperCase()}:`:'';
  await copyText(`${time}${e.stage?` [${e.stage}]`:''}${stream} ${e.message}`);
}
async function copyLogs(){
  const selection=window.getSelection();
  const selectedText=selection && selection.rangeCount ? String(selection.toString()||'').trim() : '';
  const container=$('events');
  if(selectedText && container && container.contains(selection.anchorNode) && container.contains(selection.focusNode)){
    await copyText(selectedText);
    return;
  }
  await copyText(logText());
}
renderProjectSetup();
['issueUrl','appUrl','testCaseFolderId','executionFolderName','campaignName','iterationName','testSuiteName'].forEach(id=>$(id)?.addEventListener('input',renderProjectSetup));
refreshMcp();refreshSecrets();setInterval(refreshMcp,1500);setInterval(refreshSecrets,1500);
