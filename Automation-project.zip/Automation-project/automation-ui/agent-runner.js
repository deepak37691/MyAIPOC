const { spawn } = require('node:child_process');
const path = require('node:path');

// Standalone runs: read the single root .env. When started by the Control Center these values
// are already in process.env (dotenv never overrides existing variables).
try { require('dotenv').config({ path: path.resolve(__dirname, '..', '.env'), quiet: true }); } catch { /* dotenv optional */ }

const envValue = (...names) => { for (const n of names) { const v = process.env[n]; if (v && v.trim()) return v.trim(); } return ''; };
const envFlag = name => /^(1|true|yes|on)$/i.test(envValue(name));
const splitArgs = text => text.match(/(?:[^\s"]+|"[^"]*")+/g) || [];
// Proxy / CA variables that every spawned MCP server must also see (the Control Center normalises them).
const proxyEnv = {};
for (const key of ['HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy', 'ALL_PROXY', 'NO_PROXY', 'no_proxy',
                   'npm_config_proxy', 'npm_config_https_proxy', 'npm_config_noproxy',
                   'NODE_EXTRA_CA_CERTS', 'NODE_TLS_REJECT_UNAUTHORIZED']) {
  if (process.env[key]) proxyEnv[key] = process.env[key];
}
// Playwright MCP proxy flags (PLAYWRIGHT_PROXY_SERVER wins, otherwise the general proxy is reused).
function playwrightMcpProxyArgs() {
  const server = envValue('PLAYWRIGHT_PROXY_SERVER', 'HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy');
  const out = [];
  if (server) {
    out.push('--proxy-server', server);
    const bypass = envValue('PLAYWRIGHT_PROXY_BYPASS', 'NO_PROXY', 'no_proxy') || 'localhost,127.0.0.1,::1';
    out.push('--proxy-bypass', bypass.split(',').map(x => x.trim()).filter(Boolean).join(','));
  }
  if (envFlag('PLAYWRIGHT_IGNORE_HTTPS_ERRORS')) out.push('--ignore-https-errors');
  return out;
}
// Copilot CLI model: COPILOT_MODEL_<STAGE> overrides COPILOT_MODEL. Empty/"auto" => no --model flag (Copilot decides).
function copilotModelArgs(stageName) {
  const stageKey = `COPILOT_MODEL_${String(stageName || '').replace(/[A-Z]/g, m => `_${m}`).toUpperCase()}`;
  const model = envValue(stageKey) || envValue('COPILOT_MODEL');
  return !model || model.toLowerCase() === 'auto' ? [] : ['--model', model];
}

const agents = {
  businessReview: 'business-requirements-reviewer',
  scenarios: 'create-scenarios',
  strategy: 'test-strategy',
  squash: 'squash-user',
  scriptGeneration: 'script-generator',
  healer: 'test-healer',
  defect: 'defect-reporter',
  gitlabCommit: 'gitlab-committer'
};
const instructionFiles = {
  businessReview: '.github/agents/business-requirements-reviewer.agent.md',
  scenarios: '.github/agents/test-scenarios-agent.md',
  strategy: '.github/agents/test-strategy-agent.md',
  squash: '.github/agents/squash-user.agent.md',
  scriptGeneration: '.github/agents/script-generator-agent.md',
  healer: '.github/agents/test-healer-agent.md',
  defect: '.github/agents/defect-reporter.agent.md',
  gitlabCommit: '.github/agents/gitlab-commiter-agent.md'
};

const projectRoot = process.env.PROJECT_ROOT
  ? path.resolve(process.env.PROJECT_ROOT)
  : path.resolve(__dirname, '..');
const stage = process.env.STAGE;
const agent = agents[stage];
if (!agent) {
  process.stderr.write(`Unsupported agent stage: ${stage || '(missing)'}\n`);
  process.exit(2);
}

if (stage === 'strategy' && process.env.APPROVAL === 'approved') {
  process.stdout.write('Strategy approval is handled by the UI/backend; strategy agent is not rerun.\n');
  process.exit(0);
}

const issue = process.env.ISSUE_URL || process.env.ISSUE_ID;
const proposal = process.env.HEALING_PROPOSAL || '';
const approval = process.env.APPROVAL === 'approved'
  ? ` Approval has been granted. Apply ONLY the exact approved healing proposal supplied below; do not perform a second diagnosis or invent additional changes. Do NOT run Playwright verification yourself; the Automation Control Center runner will execute exactly one targeted verification after you finish applying the change. Stop after applying the approved repair.\nAPPROVED HEALING PROPOSAL:\n${proposal || '(proposal text unavailable)'}`
  : '';
const selectedCases = process.env.INCLUDED_TEST_CASES || '';
const failedTestCases = process.env.FAILED_TEST_CASES || '';
const issueContext = (stage === 'scenarios' || stage === 'businessReview') && process.env.ISSUE_TITLE
  ? ` The backend already fetched the authoritative GitLab issue context. Do NOT call GitLab MCP just to retrieve the issue again. Use the supplied title and description as the source of truth.\nISSUE TITLE: ${process.env.ISSUE_TITLE}\nISSUE DESCRIPTION:\n${process.env.ISSUE_DESCRIPTION || '(empty)'}`
  : (stage === 'businessReview'
    ? ` The backend could not supply authoritative issue content. Use the GitLab MCP tools available to this stage to retrieve issue ${process.env.ISSUE_ID || '(unknown)'} from ${process.env.ISSUE_URL || '(the supplied issue URL)'} before reviewing it. Do not invent requirement details.`
    : '');
const healerInstruction = stage === 'healer'
  ? ` The backend has already identified the failed or impacted test cases below. Treat this list as authoritative. Do NOT spend time searching for test-results/[ISSUE_ID].json if it is absent, do NOT search unrelated issue IDs, and do NOT broad-scan the repository. Start with the referenced spec/page object and the supplied stack trace. Use Playwright MCP only when live DOM evidence is needed. Keep the diagnosis to one focused pass and return a concise reviewable proposal.\nFAILED TEST CASE CONTEXT:\n${failedTestCases || '(none)'}`
  : '';
const defectInstruction = stage === 'defect'
  ? ` The current GitLab requirement/story is the parent for this defect. Use GitLab MCP work-item tools to create exactly ONE child work item of type Task under that parent. The title MUST begin with [Defect]. Use the failure context below as authoritative. Do not create a standalone issue, do not create a second issue, and do not modify the parent requirement.\nHEALER FAILURE REASON:\n${process.env.HEALER_FAILURE_REASON || '(not provided)'}\nFAILED TEST CASE CONTEXT:\n${failedTestCases || '(none)'}\nHEALER PROPOSAL/DIAGNOSTIC:\n${process.env.HEALER_PROPOSAL || '(none)'}`
  : '';
const businessReviewFeedback = stage === 'businessReview' && process.env.BUSINESS_REVIEW_FEEDBACK
  ? ` The user has requested a revision. Treat the feedback below as authoritative review guidance. Re-evaluate the requirement and address the requested changes without inventing business rules.\nUSER FEEDBACK:\n${process.env.BUSINESS_REVIEW_FEEDBACK}`
  : '';
const selectionInstruction = stage === 'strategy' && process.env.APPROVAL === 'approved'
  ? ` The user has explicitly approved this final E2E selection: ${selectedCases || '(none)'}. Treat this list as authoritative: only these IDs may be AUTOMATE (E2E) in the final strategy; every other evaluated scenario must remain OFFLOAD/not selected. The final approved document must contain only the user-selected test cases; do not restore or re-add unchecked test cases.`
  : '';
const generationGuard = stage === 'scriptGeneration'
  ? ' This is the Script Generation stage only: generate and validate test-data, POMs, and the Playwright spec. DO NOT run any Playwright test command, do not use --headed, and do not open a visible browser. Test Execution will run the generated spec later. Keep progress concise so the control-center logs remain useful.'
  : '';
const instructionPath = path.join(projectRoot, instructionFiles[stage]).replace(/\\/g, '/');
const prompt = `Follow the instructions in @${instructionPath} (repository-relative path: ${instructionFiles[stage]}) and perform the ${agent} stage for GitLab issue ${issue}. The issue ID is ${process.env.ISSUE_ID}. The application URL is ${process.env.APP_URL || '(not provided)'}. The Squash folder ID is ${process.env.FOLDER_ID || '1'}.${issueContext}${businessReviewFeedback}${approval}${selectionInstruction}${healerInstruction}${defectInstruction}${generationGuard} Complete the stage and create the artifacts required by those instructions.`;

// Only start the MCP servers the current stage actually needs. Starting an
// unrelated stdio MCP server can delay agent startup and make a healthy agent
// look hung while npm is downloading/initialising the server.
const mcpServers = {};
if (stage === 'businessReview' || stage === 'scenarios' || stage === 'gitlabCommit' || stage === 'defect') {
  mcpServers['GitLab-MCP'] = {
    type: 'stdio',
    command: envValue('GITLAB_MCP_COMMAND') || (process.platform === 'win32' ? 'npx.cmd' : 'npx'),
    args: splitArgs(envValue('GITLAB_MCP_ARGS') || '-y @zereight/mcp-gitlab'),
    env: {
      ...proxyEnv,
      GITLAB_PERSONAL_ACCESS_TOKEN: '${GITLAB_PERSONAL_ACCESS_TOKEN}',
      GITLAB_API_URL: (envValue('GITLAB_API_URL') || 'https://gitlab.com/api/v4').replace(/\/+$/, ''),
      GITLAB_READ_ONLY_MODE: envValue('GITLAB_READ_ONLY_MODE') || 'false',
      GITLAB_PERMISSION_MODE: envValue('GITLAB_PERMISSION_MODE') || 'modify',
      USE_GITLAB_WIKI: envValue('USE_GITLAB_WIKI') || 'true',
      GITLAB_TOOLSETS: stage === 'defect' ? 'workitems' : 'issues',
      ...(stage === 'defect' ? { GITLAB_TOOLS: 'get_work_item,create_work_item' } : {})
    }
  };
}
if (stage === 'scriptGeneration' || stage === 'healer') {
  const playwrightArgs = splitArgs(envValue('PLAYWRIGHT_MCP_ARGS') || '-y @playwright/mcp@latest --headless');
  for (const a of playwrightMcpProxyArgs()) if (!playwrightArgs.includes(a)) playwrightArgs.push(a);
  mcpServers['Playwright-MCP'] = {
    type: 'stdio',
    command: envValue('PLAYWRIGHT_MCP_COMMAND') || (process.platform === 'win32' ? 'npx.cmd' : 'npx'),
    args: playwrightArgs,
    env: { ...proxyEnv }
  };
}
const mcpConfig = JSON.stringify({ mcpServers });

const command = process.env.COPILOT_COMMAND || (process.platform === 'win32' ? 'copilot.cmd' : 'copilot');
// Do not pass the generated prompt as a command-line argument. On Windows the
// combined command line can exceed the OS command-line limit, especially for the
// Defect Reporter because it includes failure traces and healer diagnostics.
// Copilot CLI explicitly supports reading a programmatic prompt from stdin, so
// keep the prompt off argv and stream it through stdin instead.
const args = [
  '--allow-all',
  '--no-ask-user',
  '--no-auto-update',
  '--log-level=info',
  '--stream=on',
  ...copilotModelArgs(stage),
  ...splitArgs(envValue('COPILOT_EXTRA_ARGS')),
  '--additional-mcp-config', mcpConfig
];
const spawnCommand = process.platform === 'win32' ? (process.env.ComSpec || 'cmd.exe') : command;
const spawnArgs = process.platform === 'win32' ? ['/d', '/s', '/c', command, ...args] : args;
const childEnv = {
  ...process.env,
  COPILOT_AUTO_UPDATE: 'false',
  ...(stage === 'scriptGeneration' ? { GENERATE_ONLY: '1', HEADLESS: '1' } : {})
};
process.stdout.write(`[agent-runner] projectRoot=${projectRoot}\n`);
process.stdout.write(`[agent-runner] instruction=${instructionPath}\n`);
process.stdout.write(`[agent-runner] stage=${stage}; agent=${agent}; MCP=${Object.keys(mcpServers).join(',') || 'none'}; model=${copilotModelArgs(stage)[1] || 'auto (Copilot default)'}; proxy=${envValue('HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy') ? 'on' : 'off'}\n`);
process.stdout.write(`[agent-runner] launching Copilot CLI; prompt is sent via stdin (${Buffer.byteLength(prompt, 'utf8')} bytes) and live stdout/stderr will be forwarded to the Activity Log.\n`);
const child = spawn(spawnCommand, spawnArgs, { cwd: projectRoot, env: { ...childEnv, PROJECT_ROOT: projectRoot }, stdio: ['pipe', 'pipe', 'pipe'] });
child.stdin.write(prompt);
child.stdin.end();
child.stdout.on('data', data => process.stdout.write(data));
child.stderr.on('data', data => process.stderr.write(data));
child.on('error', error => { process.stderr.write(`Failed to start Copilot CLI: ${error.message}\n`); process.exit(1); });
child.on('close', code => process.exit(code ?? 1));
