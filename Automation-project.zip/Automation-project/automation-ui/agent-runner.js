const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const agents = {
  businessReview: 'business-requirements-reviewer',
  scenarios: 'create-scenarios',
  strategy: 'test-strategy',
  squash: 'squash-user',
  scriptGeneration: 'script-generator',
  healer: 'test-healer',
  defect: 'defect-reporter',
  gitlabCommit: 'gitlab-committer'
};
const instructionFiles = {
  businessReview: '.github/agents/business-requirements-reviewer.agent.md',
  scenarios: '.github/agents/test-scenarios-agent.md',
  strategy: '.github/agents/test-strategy-agent.md',
  squash: '.github/agents/squash-user.agent.md',
  scriptGeneration: '.github/agents/script-generator-agent.md',
  healer: '.github/agents/test-healer-agent.md',
  defect: '.github/agents/defect-reporter.agent.md',
  gitlabCommit: '.github/agents/gitlab-commiter-agent.md'
};

const stage = process.env.STAGE;
const agent = agents[stage];
if (!agent) {
  process.stderr.write(`Unsupported agent stage: ${stage || '(missing)'}\n`);
  process.exit(2);
}

if (stage === 'strategy' && process.env.APPROVAL === 'approved') {
  process.stdout.write('Strategy approval is handled by the UI/backend; strategy agent is not rerun.\n');
  process.exit(0);
}

const issue = process.env.ISSUE_URL || process.env.ISSUE_ID;
const proposal = process.env.HEALING_PROPOSAL || '';
const approval = process.env.APPROVAL === 'approved'
  ? ` Approval has been granted. Apply ONLY the exact approved healing proposal supplied below; do not perform a second diagnosis or invent additional changes. Verify the repair once and then stop.\nAPPROVED HEALING PROPOSAL:\n${proposal || '(proposal text unavailable)'}`
  : '';
const selectedCases = process.env.INCLUDED_TEST_CASES || '';
const failedTestCases = process.env.FAILED_TEST_CASES || '';
const issueContext = (stage === 'scenarios' || stage === 'businessReview' || stage === 'defect') && process.env.ISSUE_TITLE
  ? ` The backend already fetched the authoritative GitLab issue context. Do NOT call GitLab MCP just to retrieve the issue again. Use the supplied title and description as the source of truth.\nISSUE TITLE: ${process.env.ISSUE_TITLE}\nISSUE DESCRIPTION:\n${process.env.ISSUE_DESCRIPTION || '(empty)'}`
  : '';
const healerInstruction = stage === 'healer'
  ? ` The backend has already identified the failed or impacted test cases below. Treat this list as authoritative. Do NOT spend time searching for test-results/[ISSUE_ID].json if it is absent, do NOT search unrelated issue IDs, and do NOT broad-scan the repository. Start with the referenced spec/page object and the supplied stack trace. Use Playwright MCP only when live DOM evidence is needed. Keep the diagnosis to one focused pass and return a concise reviewable proposal.\nFAILED TEST CASE CONTEXT:\n${failedTestCases || '(none)'}`
  : '';
const defectInstruction = stage === 'defect'
  ? ` Create exactly ONE child Task under the supplied GitLab requirement using the GitLab MCP work-item tools. Do not create a standalone issue or modify the parent. Title MUST be exactly the supplied defect title hint (including [Defect]). Use the supplied failure context as authoritative.\nDEFECT TITLE HINT:\n${process.env.DEFECT_TITLE_HINT || '[Defect] Test execution failure'}\nFAILURE CONTEXT:\n${failedTestCases || '(none)'}\nHEALER DIAGNOSTIC:\n${process.env.HEALER_PROPOSAL || '(none)'}`
  : '';
const businessReviewFeedback = stage === 'businessReview' && process.env.BUSINESS_REVIEW_FEEDBACK
  ? ` The user has requested a revision. Treat the feedback below as authoritative review guidance. Re-evaluate the requirement and address the requested changes without inventing business rules.\nUSER FEEDBACK:\n${process.env.BUSINESS_REVIEW_FEEDBACK}`
  : '';
const selectionInstruction = stage === 'strategy' && process.env.APPROVAL === 'approved'
  ? ` The user has explicitly approved this final E2E selection: ${selectedCases || '(none)'}. Treat this list as authoritative: only these IDs may be AUTOMATE (E2E) in the final strategy; every other evaluated scenario must remain OFFLOAD/not selected. The final approved document must contain only the user-selected test cases; do not restore or re-add unchecked test cases.`
  : '';
const generationGuard = stage === 'scriptGeneration'
  ? ' This is the Script Generation stage only: generate and validate test-data, POMs, and the Playwright spec. DO NOT run any Playwright test command, do not use --headed, and do not open a visible browser. Test Execution will run the generated spec later. Keep progress concise so the control-center logs remain useful.'
  : '';
const prompt = `Follow @${instructionFiles[stage]} and perform ${agent} for GitLab issue ${issue}. Issue ID: ${process.env.ISSUE_ID}. App URL: ${process.env.APP_URL || '(not provided)'}. Squash folder: ${process.env.FOLDER_ID || '1'}.${issueContext}${businessReviewFeedback}${approval}${selectionInstruction}${healerInstruction}${defectInstruction}${generationGuard} Complete the stage and create only the required artifacts.`;

// Only start the MCP servers the current stage actually needs. Starting an
// unrelated stdio MCP server can delay agent startup and make a healthy agent
// look hung while npm is downloading/initialising the server.
const mcpServers = {};
if (stage === 'scenarios' || stage === 'gitlabCommit' || stage === 'defect') {
  mcpServers['GitLab-MCP'] = {
    type: 'local',
    command: process.env.GITLAB_MCP_COMMAND || (process.platform === 'win32' ? 'npx.cmd' : 'npx'),
    args: (process.env.GITLAB_MCP_ARGS || '--no-install @zereight/mcp-gitlab').match(/(?:[^\s"]+|"[^"]*")+/g) || ['@zereight/mcp-gitlab'],
    env: {
      // The runner process already receives the runtime GitLab token; do not
      // write that secret into the temporary Copilot MCP configuration file.
      GITLAB_API_URL: process.env.GITLAB_API_URL || 'https://gitlab.com/api/v4',
      GITLAB_READ_ONLY_MODE: 'false',
      GITLAB_PERMISSION_MODE: 'modify',
      USE_GITLAB_WIKI: 'true',
      GITLAB_TOOLSETS: stage === 'defect' ? 'workitems' : 'issues',
      ...(stage === 'defect' ? { GITLAB_TOOLS: 'get_work_item,create_work_item' } : {})
    },
    tools: stage === 'defect' ? ['get_work_item', 'create_work_item'] : ['*']
  };
}
if (stage === 'scriptGeneration' || stage === 'healer') {
  mcpServers['Playwright-MCP'] = {
    type: 'local',
    command: process.env.PLAYWRIGHT_MCP_COMMAND || (process.platform === 'win32' ? 'npx.cmd' : 'npx'),
    args: (process.env.PLAYWRIGHT_MCP_ARGS || '--no-install @playwright/mcp --headless').match(/(?:[^\s"]+|"[^"]*")+/g) || ['@playwright/mcp','--headless'],
    tools: ['*']
  };
}
// Copilot CLI accepts --additional-mcp-config as JSON or as @<file>.
// Passing JSON inline through Windows cmd.exe is unsafe because cmd/argv quoting
// can strip the JSON quotes and Copilot then reports "configuration must be an object".
// Write a short-lived config file instead. It contains no runtime secrets.
let mcpConfigFile = null;
if (Object.keys(mcpServers).length) {
  mcpConfigFile = path.join(os.tmpdir(), `automation-control-center-mcp-${process.pid}-${Date.now()}.json`);
  fs.writeFileSync(mcpConfigFile, JSON.stringify({ mcpServers }, null, 2), { encoding: 'utf8', mode: 0o600 });
}

const command = process.env.COPILOT_COMMAND || (process.platform === 'win32' ? 'copilot.cmd' : 'copilot');
// Do not pass the generated prompt as a command-line argument. On Windows the
// combined command line can exceed the OS command-line limit, especially for the
// Defect Reporter because it includes failure traces and healer diagnostics.
// Copilot CLI explicitly supports reading a programmatic prompt from stdin, so
// keep the prompt off argv and stream it through stdin instead.
const args = [
  '--allow-all',
  '--no-ask-user',
  '--no-auto-update',
  '--log-level=info',
  '--stream=on'
];
if (mcpConfigFile) args.push('--additional-mcp-config', `@${mcpConfigFile}`);
const spawnCommand = process.platform === 'win32' ? (process.env.ComSpec || 'cmd.exe') : command;
const quoteWinArg = value => /[\s"&|<>^]/.test(value) ? `\"${String(value).replace(/\"/g, '\\\"')}\"` : String(value);
const spawnArgs = process.platform === 'win32' ? ['/d', '/s', '/c', [command, ...args].map(quoteWinArg).join(' ')] : args;
const childEnv = {
  ...process.env,
  COPILOT_AUTO_UPDATE: 'false',
  ...(stage === 'scriptGeneration' ? { GENERATE_ONLY: '1', HEADLESS: '1' } : {})
};
process.stdout.write(`[agent-runner] stage=${stage}; agent=${agent}; MCP=${Object.keys(mcpServers).join(',') || 'none'}\n`);
process.stdout.write(`[agent-runner] launching Copilot CLI; prompt is sent via stdin (${Buffer.byteLength(prompt, 'utf8')} bytes) and live stdout/stderr will be forwarded to the Activity Log.\n`);
const child = spawn(spawnCommand, spawnArgs, { cwd: process.cwd(), env: childEnv, stdio: ['pipe', 'pipe', 'pipe'] });
child.stdin.write(prompt);
child.stdin.end();
child.stdout.on('data', data => process.stdout.write(data));
child.stderr.on('data', data => process.stderr.write(data));
child.on('error', error => {
  if (mcpConfigFile) { try { fs.unlinkSync(mcpConfigFile); } catch {} }
  process.stderr.write(`Failed to start Copilot CLI: ${error.message}\n`);
  process.exit(1);
});
child.on('close', code => {
  if (mcpConfigFile) { try { fs.unlinkSync(mcpConfigFile); } catch {} }
  process.exit(code ?? 1);
});
