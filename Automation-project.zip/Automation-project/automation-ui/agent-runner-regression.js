const fs = require('node:fs');
const path = require('node:path');
const runner = fs.readFileSync(path.join(__dirname, 'agent-runner.js'), 'utf8');
const checks = [
  ['Prompt is sent through stdin, not command-line arguments', /child\.stdin\.write\(prompt\)/.test(runner) && !/'--prompt'/.test(runner)],
  ['Copilot auto-update is disabled for automation runs', /--no-auto-update/.test(runner) && /COPILOT_AUTO_UPDATE: 'false'/.test(runner)],
  ['Copilot info logging is enabled', /--log-level=info/.test(runner)],
  ['Script generation explicitly forbids Playwright execution', /DO NOT run any Playwright test command/.test(runner)],
  ['Script generation does not append a headed CLI flag', !/stage === 'scriptGeneration'.*args\.push\('--headed'\)/s.test(runner)],
  ['Scenario/defect stages can use backend-fetched issue context', /ISSUE_TITLE/.test(runner) && /ISSUE_DESCRIPTION/.test(runner) && /stage === 'defect'/.test(runner)],
  ['Scenario stage avoids an unnecessary Playwright MCP server', /if \(stage === 'scriptGeneration' \|\| stage === 'healer'\)/.test(runner)],
];
const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  console.error(failed.map(([name]) => `FAIL: ${name}`).join('\n'));
  process.exit(1);
}
console.log('Agent runner regression checks passed.');
