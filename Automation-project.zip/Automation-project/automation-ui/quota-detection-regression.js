// Regression: successful Copilot runs print "AI Credits 0.89 (...)" and must not be treated as quota failures.
const fs = require('node:fs');
const path = require('node:path');
const src = fs.readFileSync(path.join(__dirname, 'src', 'server.ts'), 'utf8');
const m = src.match(/const QUOTA_FAILURE_PATTERN=(\/.*\/i);/);
if (!m) throw new Error('QUOTA_FAILURE_PATTERN not found in server.ts');
const re = eval(m[1]);
const assert = require('node:assert');
assert.ok(!re.test('AI Credits 0.89 (1m 24s)'), 'non-zero credits must not match');
assert.ok(!re.test('AI Credits 10 (2m)'), 'credits 10 must not match');
assert.ok(re.test('AI Credits 0 (3s)'), 'zero balance must match');
assert.ok(re.test('AI Credits 0.00 (3s)'), 'zero balance (decimal) must match');
assert.ok(re.test('You have exceeded your monthly quota'), 'quota text must match');
assert.ok(/processFailed && QUOTA_FAILURE_PATTERN/.test(src), 'detector must require a failed process');
console.log('quota-detection-regression: OK');
