export interface SquashPathConfig {
  testCaseFolderPath: string;
  testExecutionPath: string;
}

export interface ResolvedSquashTestCaseFolder {
  id: number;
  name: string;
  path: string;
  projectId?: number;
  projectName?: string;
}

function apiRoot(baseUrl: string): string {
  return baseUrl.replace(/\/+$/, '').replace(/\/test-cases\/?$/i, '');
}

async function readJson(response: any): Promise<any> {
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

function normalizeSegments(value: string): string[] {
  return String(value || '')
    .trim()
    .replace(/[\\>→]+/g, '/')
    .split('/')
    .map(x => x.trim())
    .filter(Boolean);
}

function contentOf(value: any): any[] {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?._embedded?.content)) return value._embedded.content;
  if (Array.isArray(value?.content)) return value.content;
  return [];
}

function idOf(value: any): number {
  return Number(value?.id || value?.identifier || 0);
}

async function getAll(fetchJson: (url: string) => Promise<any>, root: string, resource: string): Promise<any[]> {
  const all: any[] = [];
  let url: string | null = `${root}/${resource}?page=0&size=2000`;
  for (let guard = 0; url && guard < 100; guard++) {
    const body = await fetchJson(url);
    all.push(...contentOf(body));
    const next = body?._links?.next?.href;
    if (!next) { url = null; continue; }
    const parsed = new URL(next);
    url = `${root}${parsed.pathname.split('/api/rest/latest').pop() || ''}${parsed.search}`;
    if (!url.startsWith(root)) url = null;
  }
  return all;
}

function entityPath(folder: any, byId: Map<number, any>): string[] {
  const names: string[] = [];
  const seen = new Set<number>();
  let current = folder;
  while (current && names.length < 50) {
    const id = idOf(current);
    if (id && seen.has(id)) break;
    if (id) seen.add(id);
    if (current.name) names.unshift(String(current.name).trim());

    const parentId = Number(current?.parent?.id || 0);
    const parent = parentId ? byId.get(parentId) : undefined;
    if (parent) { current = parent; continue; }

    const projectName = String(current?.project?.name || current?.parent?.name || '').trim();
    if (projectName && names[0]?.toLowerCase() !== projectName.toLowerCase()) names.unshift(projectName);
    break;
  }
  return names.filter(Boolean);
}

function pathMatches(actual: string[], wanted: string[]): boolean {
  const a = actual.map(x => x.toLowerCase());
  const w = wanted.map(x => x.toLowerCase());
  if (a.length === w.length && a.every((x, i) => x === w[i])) return true;
  if (a.length >= w.length && w.every((x, i) => a[a.length - w.length + i] === x)) return true;
  return false;
}

export async function resolveSquashTestCaseFolder(options: {
  baseUrl: string;
  token: string;
  path: string;
}): Promise<ResolvedSquashTestCaseFolder> {
  const rawPath = String(options.path || '').trim();
  if (!rawPath) throw new Error('Squash Test Case Folder Path is required.');

  // Be forgiving when a user pastes the Squash UI URL instead of the
  // hierarchy path. The UI shows a folder URL such as:
  // http://localhost:8080/squash/test-case-workspace/test-case-folder/1/content?anchor=dashboard
  // Resolve the embedded folder id through the API and keep the rest of the
  // application on the existing numeric folder-id contract.
  const folderUrlMatch = rawPath.match(/\/test-case-folder\/(\d+)(?:[\/?#]|$)/i);
  const wanted = normalizeSegments(rawPath);
  const root = apiRoot(options.baseUrl);
  const headers = { Accept: 'application/json', Authorization: `Bearer ${options.token}` };
  const fetchJson = async (url: string): Promise<any> => {
    const response = await fetch(url, { headers });
    const body = await readJson(response);
    if (!response.ok) throw new Error(`Squash GET ${url} failed with HTTP ${response.status}: ${JSON.stringify(body)}`);
    return body;
  };

  const explicitFolderId = folderUrlMatch ? Number(folderUrlMatch[1]) : (wanted.length === 1 && /^\d+$/.test(wanted[0]) ? Number(wanted[0]) : 0);
  if (explicitFolderId > 0) {
    const id = explicitFolderId;
    const body = await fetchJson(`${root}/test-case-folders/${id}`);
    return {
      id,
      name: String(body.name || id),
      path: entityPath(body, new Map([[id, body]])).join(' / '),
      projectId: Number(body.project?.id || body.parent?.id || 0) || undefined,
      projectName: body.project?.name || body.parent?.name
    };
  }

  const folders = await getAll(fetchJson, root, 'test-case-folders');
  const byId = new Map<number, any>();
  for (const folder of folders) if (idOf(folder)) byId.set(idOf(folder), folder);

  const match = folders.find(folder => pathMatches(entityPath(folder, byId), wanted));
  if (!match) {
    const examples = folders.slice(0, 12).map(folder => entityPath(folder, byId).join(' / ')).filter(Boolean);
    throw new Error(`Squash Test Case Folder Path "${options.path}" was not found. Use the Squash hierarchy path (for example "Project / Test Cases / Regression").${examples.length ? ` Available examples: ${examples.join('; ')}` : ''}`);
  }
  const id = idOf(match);
  return {
    id,
    name: String(match.name || id),
    path: entityPath(match, byId).join(' / '),
    projectId: Number(match.project?.id || match.parent?.id || 0) || undefined,
    projectName: match.project?.name || match.parent?.name
  };
}

export function parseSquashExecutionPath(value: string, projectName?: string): {
  executionFolderName: string;
  campaignName: string;
  iterationName: string;
  testSuiteName?: string;
} {
  const parts = normalizeSegments(value);
  if (!parts.length) throw new Error('Squash Test Execution Path is required.');

  if (projectName && parts[0].toLowerCase() === projectName.trim().toLowerCase()) parts.shift();
  if (parts.length < 3) {
    throw new Error('Squash Test Execution Path must contain at least Execution Folder / Campaign / Iteration.');
  }
  return {
    executionFolderName: parts[0],
    campaignName: parts[1],
    iterationName: parts[2],
    testSuiteName: parts[3] || undefined
  };
}


export interface ResolvedSquashExecutionTarget {
  executionFolderId?: number;
  campaignId?: number;
  iterationId?: number;
  testSuiteId?: number;
  executionFolderName?: string;
  campaignName?: string;
  iterationName?: string;
  testSuiteName?: string;
  source: 'url' | 'path';
}

/**
 * Resolve the exact Squash execution object represented by a user-supplied
 * execution path/URL. A URL may point directly at a Test Suite, Iteration,
 * Campaign, or Campaign Folder. When an object ID is present, the hierarchy
 * is read from Squash instead of recreating objects by name.
 */
export async function resolveSquashExecutionTarget(options: {
  baseUrl: string;
  token: string;
  value: string;
}): Promise<ResolvedSquashExecutionTarget> {
  const raw = String(options.value || '').trim();
  if (!raw) throw new Error('Squash Test Execution Path is required.');

  const api = apiRoot(options.baseUrl);
  const headers = { Accept: 'application/json', Authorization: `Bearer ${options.token}` };
  const isUrl = /^https?:\/\//i.test(raw);
  if (!isUrl) return { source: 'path' };

  const pickId = (pattern: RegExp): number | undefined => {
    const m = raw.match(pattern);
    const id = m ? Number(m[1]) : 0;
    return id > 0 ? id : undefined;
  };
  const suiteId = pickId(/\/(?:test-suite|test-suites)\/(\d+)(?:[/?#]|$)/i);
  const iterationId = pickId(/\/iterations?\/(\d+)(?:[/?#]|$)/i);
  const campaignId = pickId(/\/campaigns?\/(\d+)(?:[/?#]|$)/i);
  const executionFolderId = pickId(/\/campaign-folders?\/(\d+)(?:[/?#]|$)/i);
  if (!suiteId && !iterationId && !campaignId && !executionFolderId) {
    throw new Error(`Squash Test Execution URL does not contain a supported Campaign Folder, Campaign, Iteration, or Test Suite ID: ${raw}`);
  }

  const get = async (resource: string): Promise<any> => {
    const response = await fetch(`${api}/${resource}`, { headers });
    const body = await readJson(response);
    if (!response.ok) throw new Error(`Squash GET ${api}/${resource} failed with HTTP ${response.status}: ${JSON.stringify(body)}`);
    return body;
  };

  let suite: any = suiteId ? await get(`test-suites/${suiteId}`) : undefined;
  let iteration: any = iterationId ? await get(`iterations/${iterationId}`) : undefined;
  let campaign: any = campaignId ? await get(`campaigns/${campaignId}`) : undefined;
  let executionFolder: any = executionFolderId ? await get(`campaign-folders/${executionFolderId}`) : undefined;

  const parentId = (entity: any): number | undefined => Number(entity?.parent?.id || entity?.iteration?.id || entity?.campaign?.id || 0) || undefined;
  if (suite && !iteration) {
    const id = parentId(suite);
    if (id) iteration = await get(`iterations/${id}`);
  }
  if (iteration && !campaign) {
    const id = parentId(iteration);
    if (id) campaign = await get(`campaigns/${id}`);
  }
  if (campaign && !executionFolder) {
    const id = parentId(campaign);
    if (id) executionFolder = await get(`campaign-folders/${id}`);
  }

  const resolvedSuiteId = Number(suite?.id || suiteId || 0) || undefined;
  const resolvedIterationId = Number(iteration?.id || iterationId || 0) || undefined;
  const resolvedCampaignId = Number(campaign?.id || campaignId || 0) || undefined;
  const resolvedExecutionFolderId = Number(executionFolder?.id || executionFolderId || 0) || undefined;

  return {
    executionFolderId: resolvedExecutionFolderId,
    campaignId: resolvedCampaignId,
    iterationId: resolvedIterationId,
    testSuiteId: resolvedSuiteId,
    executionFolderName: executionFolder?.name,
    campaignName: campaign?.name,
    iterationName: iteration?.name,
    testSuiteName: suite?.name,
    source: 'url'
  };
}
