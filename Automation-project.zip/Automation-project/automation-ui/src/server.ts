import 'dotenv/config';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, ChildProcess, ChildProcessWithoutNullStreams } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { URL } from 'node:url';
import { execFileSync, execFile } from 'node:child_process';

const ROOT = path.resolve(__dirname, '..', '..');
const UI_ROOT = path.resolve(__dirname, '..', 'public');
const STATE_DIR = path.join(ROOT, '.automation-ui');
const STATE_FILE = path.join(STATE_DIR, 'session.json');
const PORT = Number(process.env.UI_PORT || 4173);

type Status = 'locked'|'ready'|'running'|'waiting_for_approval'|'completed'|'failed'|'not_required';
type StageName = 'businessReview'|'scenarios'|'strategy'|'squash'|'scriptGeneration'|'execution'|'healer'|'defect'|'squashExecution'|'gitlabCommit';
interface Stage { status: Status; startedAt?: string; completedAt?: string; message?: string; output?: unknown; error?: string; }
interface Session { id: string; issueUrl: string; issueId: string; issueTitle?: string; folderId: number; testCaseFolderId: number; executionFolderName: string; campaignName: string; iterationName: string; testSuiteName?: string; appUrl?: string; createdAt: string; updatedAt: string; mcp: { gitlab: boolean; playwright: boolean }; stages: Record<StageName, Stage>; events: { at:string; type:string; stage?:string; message:string }[]; }

const sessions = new Map<string, Session>();
const mcp: Record<'gitlab'|'playwright', ChildProcessWithoutNullStreams | undefined> = { gitlab: undefined, playwright: undefined };
const approvalLocks = new Set<string>();
const activeRuns = new Map<string, { child: ChildProcess; stopRequested: boolean }>();
// Secrets are intentionally kept only in process memory. They are never returned by an API
// endpoint and are never written to the session/state file or .env by this UI.
const runtimeSecrets: { gitlabToken?: string; squashToken?: string } = {};

function secretStatus() { return { gitlabConfigured: !!runtimeSecrets.gitlabToken, squashConfigured: !!runtimeSecrets.squashToken }; }
function sanitizedEnv() { const env={...process.env}; delete env.GITLAB_PERSONAL_ACCESS_TOKEN; delete env.SQUASH_BEARER_TOKEN; return env; }
function gitExecutable() { return process.platform === 'win32' ? 'git.exe' : 'git'; }

function redactRuntimeSecrets(value: unknown): string {
  let text = String(value ?? '');
  for (const secret of [runtimeSecrets.gitlabToken, runtimeSecrets.squashToken]) {
    if (secret) text = text.split(secret).join('[REDACTED]');
  }
  return text
    .replace(/Bearer\s+[A-Za-z0-9._~+\/-]+=*/gi, 'Bearer [REDACTED]')
    .replace(/((?:GITLAB_PERSONAL_ACCESS_TOKEN|SQUASH_BEARER_TOKEN)\s*[=:]\s*)[^\s,;]+/gi, '$1[REDACTED]')
    .replace(/([?&](?:token|access_token|api[_-]?key|password|secret)=)[^&\s]+/gi, '$1[REDACTED]')
    .replace(/\b(?:ghp|glpat)-[A-Za-z0-9_-]+\b/g, '[REDACTED]');
}
function ensureState() { fs.mkdirSync(STATE_DIR, { recursive: true }); }
function save(s: Session) {
  ensureState();
  s.updatedAt = new Date().toISOString();
  // Defense in depth: even if a child process accidentally prints a credential,
  // the persisted session file must never contain the runtime secret value.
  fs.writeFileSync(STATE_FILE, redactRuntimeSecrets(JSON.stringify(s, null, 2)));
}
function addEvent(s: Session, type: string, message: string, stage?: string) {
  s.events.push({ at:new Date().toISOString(), type, stage, message:redactRuntimeSecrets(message) });
  s.events = s.events.slice(-200);
  save(s);
}
function stage(s: Session, name: StageName, patch: Partial<Stage>) { s.stages[name] = { ...s.stages[name], ...patch }; save(s); }
function initStages(): Record<StageName, Stage> { return {
  businessReview:{status:'ready'}, scenarios:{status:'locked',message:'Complete Business Requirements Review before generating test scenarios.'}, strategy:{status:'ready'}, squash:{status:'ready'}, scriptGeneration:{status:'ready'}, execution:{status:'ready'}, healer:{status:'ready'}, defect:{status:'locked',message:'Available after a Test Execution or Test Healer failure.'}, squashExecution:{status:'locked',message:'Complete Test Execution before creating Squash executions.'}, gitlabCommit:{status:'ready'}
}; }
function unlockAfter(s:Session, name:StageName) {
  if(name==='businessReview' && s.stages.scenarios.status==='locked') {
    s.stages.scenarios={status:'ready',message:'Business requirements review approved. Ready to generate test scenarios.'};
    addEvent(s,'stage.unlocked','Test Scenarios unlocked after Business Requirements Review approval.','scenarios');
  }
  if(name==='execution' && s.stages.squashExecution.status==='locked') {
    const out:any=s.stages.execution.output||{};
    const results=Array.isArray(out.executionCaseResults)?out.executionCaseResults:[];
    const failed=results.some((x:any)=>String(x.status||'').toLowerCase()==='failed');
    const resultSummary=results.length ? (failed ? 'Test Execution completed with failures. Review Test Healer if needed.' : 'Test Execution completed successfully.') : 'Test Execution completed.';
    s.stages.squashExecution={status:'ready',message:`${resultSummary} Squash Test Case Execution is ready.`};
    addEvent(s,'stage.unlocked',`Squash Test Case Execution unlocked after Test Execution (${failed?'failed and passed results are available':'results are available'}).`,'squashExecution');
  }
  // Squash execution depends only on Test Execution results, never on Test Healer.
  // Keep this branch for sessions created by older builds where execution may not
  // have unlocked it yet after a healer cycle.
  if(name==='healer' && s.stages.healer.status==='completed' && s.stages.squashExecution.status==='locked' && s.stages.execution.status!=='locked') {
    s.stages.squashExecution={status:'ready',message:'Test Execution has completed. Squash Test Case Execution is ready.'};
    addEvent(s,'stage.unlocked','Squash Test Case Execution unlocked because Test Execution is complete; Test Healer is not a dependency.','squashExecution');
  }
}

function defectReportingAvailable(s:Session): boolean {
  return s.stages.execution.status==='failed' || s.stages.healer.status==='failed';
}
function redactFailureText(value:string):string {
  return redactRuntimeSecrets(String(value||'')).replace(/\x1b\[[0-9;]*m/g,'').replace(/\s+/g,' ').trim();
}
function defectTitleFromFailure(s:Session, failedTestCases:any[], executionReportErrors:string, failureReason:string):string {
  const candidates:string[]=[];
  for(const x of failedTestCases||[]) { if(x?.error) candidates.push(String(x.error)); for(const e of (Array.isArray(x?.errorDetails)?x.errorDetails:[])) if(e?.message) candidates.push(String(e.message)); }
  if(executionReportErrors) candidates.push(executionReportErrors.split(/\n+/)[0]);
  if(failureReason) candidates.push(failureReason);
  let summary=redactFailureText(candidates.find(x=>x&&x.length>8)||'Test execution failed');
  summary=summary.replace(/^(?:Error|Error:|TimeoutError|AssertionError|Test timeout):?\s*/i,'').replace(/^[-–—]\s*/,'').trim() || 'Test execution failed';
  const tc=failedTestCases?.[0]?.id ? ` — ${String(failedTestCases[0].id)}` : '';
  const max=150, room=Math.max(20,max-tc.length);
  if(summary.length>room) summary=summary.slice(0,room-1).replace(/[\s,;:.-]+$/,'')+'…';
  return `[Defect] ${summary}${tc}`;
}
function compactFailureContext(failedTestCases:any[]):string {
  return (failedTestCases||[]).slice(0,10).map((x:any)=>{ const details=(Array.isArray(x?.errorDetails)?x.errorDetails:[]).slice(0,3).map((e:any)=>[e?.message,e?.location?.file?`Location: ${e.location.file}:${e.location.line||''}:${e.location.column||''}`:'',e?.stack?String(e.stack).slice(0,1800):''].filter(Boolean).join('\n')).join('\n'); return `${x?.id||'TC'} | ${x?.title||''} | ${x?.spec||''}${x?.error?`\nError: ${String(x.error).slice(0,1800)}`:''}${details?`\nExecution details:\n${details}`:''}`; }).join('\n\n').slice(0,12000);
}

function issueIdFromUrl(input: string): string {
  const m = input.match(/(?:\/(?:issues|work_items)\/)(\d+)(?:[/?#]|$)/i); if (m) return m[1];
  if (/^\d+$/.test(input.trim())) return input.trim();
  throw new Error('GitLab issue URL must contain /issues/<number> or /work_items/<number>, or provide a numeric issue ID.');
}
function json(res:http.ServerResponse, code:number, body:unknown) { const data=JSON.stringify(body); res.writeHead(code, {'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)}); res.end(data); }
function escapeHtml(value:string) { return value.replace(/[&<>"']/g, character=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character] || character)); }
function markdownToHtml(markdown:string) {
  const esc = escapeHtml;
  const lines = markdown.replace(/\r/g,'').split('\n');
  const out:string[]=[];
  let inUl=false;
  let inOl=false;
  let inCode=false;
  let code:string[]=[];
  let table:string[][]|null=null;

  const closeLists=()=>{
    if(inUl){out.push('</ul>');inUl=false;}
    if(inOl){out.push('</ol>');inOl=false;}
  };

  // The strategy markdown intentionally contains a small amount of inline HTML
  // (mainly <p> wrappers inside candidate descriptions/steps). Escape arbitrary
  // HTML first, then restore only the harmless presentation tags we support.
  const inlineMarkdown=(value:string)=>{
    let html=esc(value)
      .replace(/`([^`]+)`/g,'<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>')
      .replace(/__([^_]+)__/g,'<strong>$1</strong>')
      .replace(/\*([^*]+)\*/g,'<em>$1</em>')
      .replace(/_([^_]+)_/g,'<em>$1</em>')
      .replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    html=html
      .replace(/&lt;(\/?(?:p|br|strong|em|code))\s*&gt;/gi,'<$1>')
      .replace(/&lt;(br)\s*\/&gt;/gi,'<$1>');
    return html;
  };

  const parseTableRow=(line:string)=>line.trim().replace(/^\|/,'').replace(/\|$/,'').split(/(?<!\\)\|/).map(c=>c.replace(/\\\|/g,'|').trim());
  const isTableSeparator=(line:string)=>/^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(line);

  const flushTable=()=>{
    if(!table)return;
    const rows=table;
    table=null;
    if(!rows.length)return;
    const header=rows[0];
    const body=rows.slice(1);
    out.push(
      '<div class="md-table-wrap"><table class="md-table"><thead><tr>'+
      header.map(c=>`<th>${inlineMarkdown(c)}</th>`).join('')+
      '</tr></thead><tbody>'+
      (body.length ? body.map(r=>{
        const cells=header.map((_,i)=>`<td>${inlineMarkdown(r[i]||'')}</td>`);
        return `<tr>${cells.join('')}</tr>`;
      }).join('') : `<tr><td colspan="${header.length}" class="empty">No records</td></tr>`) +
      '</tbody></table></div>'
    );
  };

  for(let i=0;i<lines.length;i++){
    const line=lines[i];
    if(line.trim().startsWith('```')){
      flushTable();
      closeLists();
      if(inCode){
        out.push('<pre><code>'+esc(code.join('\n'))+'</code></pre>');
        code=[];
        inCode=false;
      } else {
        inCode=true;
      }
      continue;
    }
    if(inCode){code.push(line);continue;}

    if(/^\s*\|.*(?:\|.*)?$/.test(line) && i+1<lines.length && isTableSeparator(lines[i+1])){
      flushTable();
      table=[parseTableRow(line)];
      i++;
      continue;
    }
    if(table && /^\s*\|/.test(line)){
      table.push(parseTableRow(line));
      continue;
    }

    if(!line.trim()){
      flushTable();
      closeLists();
      continue;
    }

    const h=line.match(/^\s*(#{1,6})\s+(.+)$/);
    if(h){
      flushTable();
      closeLists();
      const level=h[1].length;
      out.push(`<h${level}>${inlineMarkdown(h[2])}</h${level}>`);
      continue;
    }

    const ul=line.match(/^\s*[-*+]\s+(.+)$/);
    if(ul){
      flushTable();
      if(inOl){out.push('</ol>');inOl=false;}
      if(!inUl){out.push('<ul>');inUl=true;}
      out.push(`<li>${inlineMarkdown(ul[1])}</li>`);
      continue;
    }

    const ol=line.match(/^\s*\d+[.)]\s+(.+)$/);
    if(ol){
      flushTable();
      if(inUl){out.push('</ul>');inUl=false;}
      if(!inOl){out.push('<ol>');inOl=true;}
      out.push(`<li>${inlineMarkdown(ol[1])}</li>`);
      continue;
    }

    flushTable();
    closeLists();
    out.push(`<p>${inlineMarkdown(line)}</p>`);
  }

  flushTable();
  closeLists();
  if(inCode)out.push('<pre><code>'+esc(code.join('\n'))+'</code></pre>');
  return out.join('');
}

function artifactPreview(res:http.ServerResponse, requested:string) {
  const relative=path.normalize(requested).replace(/^([.][.][\\/])+/, '');
  const full=path.resolve(ROOT,relative);
  if((full !== ROOT && !full.startsWith(`${ROOT}${path.sep}`)) || !fs.existsSync(full) || !fs.statSync(full).isFile()) return json(res,404,{error:'Artifact not found'});
  const content=fs.readFileSync(full,'utf8');
  const title=path.basename(full);
  const ext=path.extname(full).toLowerCase();
  if(ext==='.md' || ext==='.markdown') return reportHtml(res,title,`Complete document • ${relative}`,[],`<article class="markdown-document">${markdownToHtml(content)}</article>`);
  if(ext==='.json'){ try { const data=JSON.parse(content); return reportHtml(res,title,`Complete JSON artifact • ${relative}`,[{title:'Artifact',columns:['Path','Value'],rows:flattenObject(data).map(([k,v])=>[k,v])}]); } catch {} }
  const rows=content.split(/\r?\n/).map((line,i)=>[i+1,line]); return reportHtml(res,title,`Complete file • ${relative}`,[{title:'File contents',columns:['Line','Content'],rows}]);
}
function flattenObject(value:any,prefix=''):Array<[string,string]> { if(value===null||value===undefined)return [[prefix,'']]; if(typeof value!=='object')return [[prefix,String(value)]]; if(Array.isArray(value)){return value.flatMap((v,i)=>flattenObject(v,prefix?`${prefix}[${i}]`:`[${i}]`));} return Object.entries(value).flatMap(([k,v])=>flattenObject(v,prefix?`${prefix}.${k}`:k)); }
function reportContentType(file:string) {
  const ext=path.extname(file).toLowerCase();
  return ({'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.woff':'font/woff','.woff2':'font/woff2'} as Record<string,string>)[ext] || 'application/octet-stream';
}
function serveReportFile(res:http.ServerResponse,baseDir:string,relative:string) {
  const base=path.resolve(baseDir); const target=path.resolve(base,relative);
  if(target!==base && !target.startsWith(`${base}${path.sep}`)) return json(res,403,{error:'Invalid report path'});
  if(!fs.existsSync(target) || !fs.statSync(target).isFile()) return json(res,404,{error:'Report asset not found'});
  const data=fs.readFileSync(target);
  res.writeHead(200,{'Content-Type':reportContentType(target),'Content-Length':data.length,'Cache-Control':'no-cache'});
  res.end(data);
}
function executionReportDir(s:Session) { return path.join(ROOT,'playwright-report',`execution-${s.id}`); }
function hasExecutionReport(s:Session) { return fs.existsSync(path.join(executionReportDir(s),'index.html')); }

function reportHtml(res:http.ServerResponse,title:string,subtitle:string,tables:{title:string,columns:string[],rows:(string|number)[][]}[],contentHtml='') {
  const esc=(v:unknown)=>escapeHtml(String(v ?? ''));
  const body=(contentHtml ? contentHtml : tables.map(t=>`<section class="report-section"><h2>${esc(t.title)}</h2><div class="table-wrap"><table><thead><tr>${t.columns.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${t.rows.length?t.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${t.columns.length}" class="empty">No records</td></tr>`}</tbody></table></div></section>`).join(''));
  const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>body{margin:0;background:#f4f6f8;color:#172033;font:14px/1.6 Segoe UI,Arial,sans-serif}.top{background:#172033;color:#fff;padding:26px 5vw;box-shadow:0 2px 10px rgba(0,0,0,.08)}.top strong{display:block;font-size:22px;letter-spacing:-.01em}.top small{display:block;margin-top:4px;opacity:.72}.wrap{max-width:1280px;margin:24px auto;padding:0 20px}.report-section,.markdown-document{background:#fff;border:1px solid #dfe4ea;border-radius:12px;margin:0 0 18px;overflow:hidden;box-shadow:0 1px 2px rgba(15,23,42,.03)}.report-section h2{font-size:15px;margin:0;padding:15px 18px;border-bottom:1px solid #e4e8ed;background:#fbfcfd}.table-wrap,.md-table-wrap{width:100%;overflow-x:auto}.table-wrap table,.md-table{width:100%;border-collapse:separate;border-spacing:0}.table-wrap th,.table-wrap td,.md-table th,.md-table td{text-align:left;padding:11px 14px;border-bottom:1px solid #edf0f4;vertical-align:top}.table-wrap th,.md-table th{background:#f7f9fb;color:#4b5563;font-size:11px;text-transform:uppercase;letter-spacing:.055em;white-space:nowrap}.table-wrap tr:last-child td,.md-table tr:last-child td{border-bottom:0}.markdown-document{padding:30px}.markdown-document h1,.markdown-document h2,.markdown-document h3,.markdown-document h4{color:#172033;margin:24px 0 11px}.markdown-document h1{font-size:26px;margin-top:0}.markdown-document h2{font-size:20px;border-bottom:1px solid #e4e7ec;padding-bottom:8px}.markdown-document h3{font-size:17px;padding-top:8px}.markdown-document h4{font-size:15px}.markdown-document p{margin:9px 0}.markdown-document ul,.markdown-document ol{padding-left:28px}.markdown-document li{margin:5px 0}.markdown-document code{background:#eef1f5;padding:2px 5px;border-radius:4px;font-size:.92em}.markdown-document pre{background:#111827;color:#e5e7eb;padding:15px;border-radius:8px;overflow:auto}.md-table{margin:12px 0 22px;min-width:760px}.md-table th{background:#eef2f7}.md-table td:first-child{font-weight:500}.markdown-document .md-table-wrap{border:1px solid #e4e8ed;border-radius:8px}.markdown-document a{color:#2457c5}.markdown-document strong{font-weight:650}.empty{color:#7a8496;text-align:center;padding:24px}</style></head><body><header class="top"><strong>${esc(title)}</strong><small>${esc(subtitle)}</small></header><main class="wrap">${body}</main></body></html>`;
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Length':Buffer.byteLength(html)}); res.end(html);
}
function businessReviewPreview(res:http.ServerResponse,s:Session,requested?:string){
  const review=parseBusinessReview(s,requested);
  if(!review?.artifact?.relativePath) return requested ? artifactPreview(res,requested) : json(res,404,{error:'Business review artifact not found'});
  const rows=(items:string[])=>items.map((item,i)=>[i+1,item]);
  const decisionLabel=review.decision==='READY_FOR_SCENARIOS'?'Ready for scenarios':review.decision==='REJECTED'?'Rejected':'Needs revision';
  return reportHtml(res,'Business Requirements Review',`Issue #${s.issueId} • ${review.artifact.relativePath}`,[
    {title:'Review Summary',columns:['Field','Value'],rows:[
      ['Issue',`#${s.issueId}`],
      ['Decision',decisionLabel],
      ['Completeness Score',`${review.completenessScore}%`]
    ]},
    {title:'Passed Checks',columns:['#','Check'],rows:rows(review.passedChecks)},
    {title:'Critical Gaps & Ambiguities',columns:['#','Finding'],rows:rows(review.criticalGaps)},
    {title:'Recommended Fixes / Proposal',columns:['#','Recommendation'],rows:rows(review.recommendedFixes)}
  ]);
}
function stageReport(res:http.ServerResponse,s:Session,n:StageName){
  const st=s.stages[n];
  const out:any=st.output||{};
  if(n==='businessReview' && out.review?.artifact?.relativePath) return businessReviewPreview(res,s,out.review.artifact.relativePath);
  // Scenario and strategy previews are the Markdown artifacts themselves.
  // They can be previewed while strategy is waiting for approval; they do not
  // depend on a Playwright execution report existing.
  if(n==='scenarios' && out.artifact?.relativePath) return artifactPreview(res,out.artifact.relativePath);
  if(n==='strategy' && (out.artifact?.relativePath || out.proposalArtifact?.relativePath)) return artifactPreview(res,out.artifact?.relativePath || out.proposalArtifact.relativePath);
  // The Playwright HTML report is reserved for executable test work.
  if(['squash','scriptGeneration','execution'].includes(n) && hasExecutionReport(s)) {
    return serveReportFile(res,executionReportDir(s),'index.html');
  }
  if(st.status!=='completed') return json(res,409,{error:'Preview is available after the stage is completed and a report or artifact has been produced.'});
  const tables:{title:string,columns:string[],rows:(string|number)[][]}[]=[];
  if(n==='squash' && out.payload?.relativePath) return artifactPreview(res,out.payload.relativePath);
  if(n==='squashExecution' && out.artifact?.relativePath) return artifactPreview(res,out.artifact.relativePath);
  if(n==='scriptGeneration'){const arts=out.artifacts||{}; const refs=[['Test Data',arts.testData?.relativePath],['Spec',arts.spec?.relativePath],...(arts.pages||[]).map((p:any)=>['Page Object',p.relativePath])].filter((x:any)=>x[1]); const sections=refs.map(([label,rel]:any)=>{const full=path.resolve(ROOT,rel); if(!fs.existsSync(full)) return ''; const content=fs.readFileSync(full,'utf8'); const ext=path.extname(full).toLowerCase(); if(ext==='.md') return `<section class=\"report-section\"><h2>${escapeHtml(label)} • ${escapeHtml(rel)}</h2><div class=\"markdown-document\">${markdownToHtml(content)}</div></section>`; return `<section class=\"report-section\"><h2>${escapeHtml(label)} • ${escapeHtml(rel)}</h2><pre class=\"source-code\"><code>${escapeHtml(content)}</code></pre></section>`; }).join(''); return reportHtml(res,`script-generation report`,`Complete generated files • Issue #${s.issueId}`,[],sections||'<section class=\"report-section\"><h2>Generated artifacts</h2><p>No generated files found.</p></section>');}
  if(n==='execution'){const results=out.report?.suites?.flatMap((suite:any)=>suite.specs?.flatMap((sp:any)=>sp.tests?.map((t:any)=>[sp.title,t.projectName||'',t.status||t.results?.at(-1)?.status||'',t.results?.at(-1)?.duration||''])||[])||[])||[]; tables.push({title:'Execution Results',columns:['Test','Project','Status','Duration (ms)'],rows:results}); if(out.report) tables.push({title:'Complete Playwright Report Data',columns:['Field','Value'],rows:flattenObject(out.report).map(([k,v])=>[k,v])});}
  else if(n==='healer')tables.push({title:'Test Healer',columns:['Status','Message'],rows:[[st.status,st.message||'']]});
  else if(n==='gitlabCommit')tables.push({title:'GitLab Commit',columns:['Field','Value'],rows:[['Repository',out.repositoryPath||''],['Branch',out.branch||''],['Commit',out.commit||''],['Git status',out.gitStatus||'']]});
  if(!tables.length)tables.push({title:'Stage Details',columns:['Field','Value'],rows:flattenObject(out).map(([k,v])=>[k,v])});
  return reportHtml(res,`${n} report`,`Complete stage details • Issue #${s.issueId}`,tables);
}

function readBody(req:http.IncomingMessage):Promise<any> { return new Promise((resolve,reject)=>{let b=''; req.on('data',c=>b+=c); req.on('end',()=>{try{resolve(b?JSON.parse(b):{})}catch(e){reject(e)}});}); }
function killProcessTree(child:ChildProcess) {
  try {
    if (process.platform === 'win32' && child.pid) {
      execFile('taskkill',['/PID',String(child.pid),'/T','/F'],{windowsHide:true},()=>{});
    } else {
      child.kill('SIGTERM');
      setTimeout(()=>{ try { child.kill('SIGKILL'); } catch {} },1500).unref();
    }
  } catch {}
}

function shellCommand(template:string, vars:Record<string,string>, onOutput:(text:string, stream:'stdout'|'stderr')=>void, cb:(err:Error|null,out:string)=>void, runKey?:string) {
  let command=template; for(const [k,v] of Object.entries(vars)) command=command.replaceAll(`{{${k}}}`, JSON.stringify(v));
  const child=execFile(process.platform==='win32'?'cmd.exe':'/bin/sh', process.platform==='win32'?['/d','/s','/c',command]:['-lc',command], {cwd:ROOT, env:{...sanitizedEnv(),...vars}}, (err,stdout,stderr)=>{
    if(runKey) activeRuns.delete(runKey);
    cb(err, `${stdout || ''}${stderr ? `\n${stderr}`:''}`.trim());
  });
  if(runKey) activeRuns.set(runKey,{child,stopRequested:false});
  child.stdout?.on('data', data=>onOutput(String(data), 'stdout'));
  child.stderr?.on('data', data=>onOutput(String(data), 'stderr'));
}
function agentTimeoutMs(stageName:StageName, extra:Record<string,string>):number {
  if(stageName==='execution') return 0;
  if(stageName==='healer') {
    return extra.APPROVAL==='approved'
      ? Number(process.env.HEALER_REPAIR_TIMEOUT_MS || 600000)
      : Number(process.env.HEALER_DIAGNOSIS_TIMEOUT_MS || 600000);
  }
  const envKey=`${stageName.replace(/[A-Z]/g,m=>`_${m}`).toUpperCase()}_AGENT_TIMEOUT_MS`;
  return Number(process.env[envKey] || process.env.AGENT_TIMEOUT_MS || 600000);
}

function runConfiguredAgent(stageName:StageName, s:Session, extra:Record<string,string> = {}):Promise<string> {
  const key = `AGENT_COMMAND_${stageName.replace(/[A-Z]/g,m=>`_${m}`).toUpperCase()}`;
  const defaultRunner='node ./automation-ui/agent-runner.js';
  const command = process.env[key] || process.env.AGENT_RUNNER_COMMAND || defaultRunner;
  if (!fs.existsSync(path.join(ROOT,'automation-ui','agent-runner.js'))) return Promise.reject(new Error('Agent runner file is missing: automation-ui/agent-runner.js'));
  addEvent(s,'stage.progress',`Launching ${stageName} agent...`,stageName);
  const startedAt=Date.now();
  const timeoutMs=agentTimeoutMs(stageName,extra);
  return new Promise((resolve,reject)=>{
    let settled=false;
    let lastOutputAt=Date.now();
    let lastActivityAt=Date.now();
    const heartbeat=setInterval(()=>{
      if(settled) return;
      const active=activeRuns.get(`${s.id}:${stageName}`);
      if(active?.stopRequested) return;
      const silentFor=Math.round((Date.now()-lastOutputAt)/1000);
      // Do not flood the Activity Log with identical heartbeats. Only emit a
      // diagnostic heartbeat when the child process has been silent for a while.
      if(silentFor>=30) {
        const elapsed=Math.round((Date.now()-startedAt)/1000);
        addEvent(s,'stage.progress',`${stageName} agent is still running; no new agent output for ${silentFor}s (elapsed ${elapsed}s).`,stageName);
        lastActivityAt=Date.now();
      }
    },10000);
    const timeout=timeoutMs ? setTimeout(()=>{
      if(settled) return;
      const runKey=`${s.id}:${stageName}`;
      const active=activeRuns.get(runKey);
      if(active){ active.stopRequested=true; killProcessTree(active.child); }
      settled=true;
      clearInterval(heartbeat);
      activeRuns.delete(runKey);
      const elapsed=Math.round((Date.now()-startedAt)/1000);
      addEvent(s,'stage.progress',`${stageName} agent timed out after ${elapsed}s and was stopped.`,stageName);
      reject(new Error(`${stageName} agent timed out after ${Math.round(timeoutMs/1000)} seconds.`));
    },timeoutMs):undefined;
    const agentEnv: Record<string,string> = {ISSUE_ID:s.issueId,ISSUE_URL:s.issueUrl,FOLDER_ID:String(s.testCaseFolderId),APP_URL:s.appUrl||'',STAGE:stageName,...extra};
    // Only stages whose agent actually uses GitLab MCP receive the GitLab token.
    // Business Review, Strategy, Script Generation, Healer and Squash flows do not.
    if ((stageName==='scenarios' || stageName==='defect') && runtimeSecrets.gitlabToken) {
      agentEnv.GITLAB_PERSONAL_ACCESS_TOKEN=runtimeSecrets.gitlabToken;
    }
    shellCommand(command,agentEnv,(text,stream)=>{
      lastOutputAt=Date.now();
      lastActivityAt=lastOutputAt;
      text.split(/\r?\n/).map(line=>line.trim()).filter(Boolean).forEach(line=>addEvent(s,'stage.log',`${stream === 'stderr' ? '[stderr] ' : ''}${line}`,stageName));
    },(err,out)=>{
      if(settled) return;
      settled=true;
      if(timeout) clearTimeout(timeout);
      clearInterval(heartbeat);
      const runKey=`${s.id}:${stageName}`;
      const wasStopped=activeRuns.get(runKey)?.stopRequested;
      activeRuns.delete(runKey);
      if(wasStopped) { reject(new Error(`Stage ${stageName} stopped by user.`)); return; }
      const combined=String(out||'');
      const safeCombined=redactRuntimeSecrets(combined);
      const quotaFailure=/(?:exceeded|exceeding) (?:your|the) (?:monthly )?quota|monthly quota|rate.?limit|usage limit|AI Credits 0/i.test(combined);
      // Copilot CLI can return a non-zero exit code after a successful MCP write.
      // For Defect Reporting, the authoritative signal is the GitLab create_work_item
      // confirmation in stdout. Do not mark the stage failed when the child Task was
      // actually created successfully.
      const defectCreationConfirmed = stageName==='defect' && /(?:DEFECT_CREATED\s*[:\-]?|Created child Task[\s\S]*?\(IID\s*\*?\*?\d+\*?\*?\)[\s\S]*?under parent work item)/i.test(combined);
      if((err || quotaFailure) && !defectCreationConfirmed) {
        addEvent(s,'stage.progress',`${stageName} agent exited with an error after ${Math.round((Date.now()-startedAt)/1000)}s.`,stageName);
        reject(new Error(safeCombined || redactRuntimeSecrets(err?.message) || `${stageName} agent failed.`));
      } else {
        if(defectCreationConfirmed && err) addEvent(s,'stage.progress','GitLab child defect creation was confirmed even though Copilot CLI returned a non-zero exit code; continuing with the successful creation result.','defect');
        addEvent(s,'stage.progress',`${stageName} agent completed in ${Math.round((Date.now()-startedAt)/1000)}s; collecting artifacts...`,stageName);
        resolve(redactRuntimeSecrets(out));
      }
    },`${s.id}:${stageName}`);
  });
}
function validateScriptGenerationArtifacts(s:Session) {
  const required = [
    path.join(ROOT,'tests',`issue-${s.issueId}.spec.ts`)
  ];
  const generated = [
    ...required,
    ...[path.join(ROOT,'test-data'),path.join(ROOT,'pages')].flatMap(dir => {
      if(!fs.existsSync(dir)) return [];
      return fs.readdirSync(dir).filter(name => {
        const ext=path.extname(name).toLowerCase();
        return ext==='.json' || ext==='.ts';
      }).map(name=>path.join(dir,name));
    })
  ];
  const empty = generated.filter(file => fs.existsSync(file) && fs.statSync(file).isFile() && fs.statSync(file).size===0);
  if(empty.length) {
    throw new Error(`Script Generation produced empty artifact file(s): ${empty.map(x=>path.relative(ROOT,x)).join(', ')}. The stage is not marked completed until generated files contain code/data.`);
  }
  const missing = required.filter(file => !fs.existsSync(file) || !fs.statSync(file).isFile() || fs.statSync(file).size===0);
  if(missing.length) {
    throw new Error(`Script Generation did not produce a usable Playwright spec: ${missing.map(x=>path.relative(ROOT,x)).join(', ')}.`);
  }
  const spec = fs.readFileSync(required[0],'utf8').trim();
  if(!/\b(test|test\.describe|test\.step)\b/.test(spec) || !/from\s+['"]@playwright\/test['"]/.test(spec)) {
    throw new Error(`Generated Playwright spec ${path.relative(ROOT,required[0])} does not contain an executable @playwright/test suite.`);
  }
  return generated.filter(file=>fs.existsSync(file) && fs.statSync(file).isFile()).map(file=>({
    repositoryPath:path.relative(ROOT,file).replace(/\\/g,'/'),
    size:fs.statSync(file).size
  }));
}

function findArtifact(s:Session, candidates:string[]):string|undefined { for(const rel of candidates){const p=path.join(ROOT,rel); if(fs.existsSync(p)) return rel;} return undefined; }
function artifactDetails(rel:string|undefined) { return rel ? { repositoryPath:rel, relativePath:rel, localPath:path.resolve(ROOT,rel) } : undefined; }

function hydrateExistingArtifacts(s:Session): boolean {
  let changed = false;

  // If Test Scenarios are already completed, Business Requirements Review must
  // also be treated as approved. A completed Scenarios stage could only have
  // been reached after Business Requirements Review approval, so restoring the
  // old session with Business Review=ready would incorrectly block a Scenarios
  // rerun after a browser/server restart.
  if(s.stages.scenarios.status==='completed' && s.stages.businessReview.status!=='completed') {
    const review = parseBusinessReview(s);
    s.stages.businessReview = {
      ...s.stages.businessReview,
      status: 'completed',
      completedAt: s.stages.businessReview.completedAt || s.stages.scenarios.completedAt || new Date().toISOString(),
      output: {
        ...(s.stages.businessReview.output as any || {}),
        ...(review ? {review} : {}),
        approvalStatus: 'approved',
        approvedAt: s.stages.businessReview.output && (s.stages.businessReview.output as any).approvedAt || s.stages.scenarios.completedAt || new Date().toISOString()
      },
      message: 'Business Requirements Review was previously approved; Test Scenarios are already completed, so the review is restored as approved.'
    };
    addEvent(s,'stage.restored','Business Requirements Review restored as approved because Test Scenarios were already completed.','businessReview');
    changed = true;
  }

  // A session is scoped to an issue, but the generated Markdown artifacts live in
  // the repository. When the user creates a new UI session for an issue that was
  // already processed, the stage state must reflect those existing artifacts
  // instead of resetting the stages to their initial lifecycle state.
  const scenarios = parseScenarios(s);
  if (scenarios?.scenarios?.length && s.stages.scenarios.status !== 'running') {
    const artifact = artifactDetails(scenarios.artifact);
    const shouldComplete = (s.stages.scenarios.status === 'locked' || s.stages.scenarios.status === 'ready') && !(s.stages.scenarios.output as any)?.rerunRequired;
    if (shouldComplete || !s.stages.scenarios.output) {
      s.stages.scenarios = {
        ...s.stages.scenarios,
        status: 'completed',
        completedAt: s.stages.scenarios.completedAt || new Date().toISOString(),
        output: { ...(s.stages.scenarios.output as any || {}), ...scenarios, artifact },
        message: `Existing scenario artifact found at ${artifact!.localPath}.`
      };
      changed = true;
    }
  }

  // Restore a previously generated Script Generation stage when the executable
  // Playwright artifacts are already present and were generated from the current
  // approved strategy. The execution gate should reflect the real project state,
  // not only the persisted UI stage flag.
  //
  // We deliberately compare timestamps: if Strategy was approved/edited after the
  // Playwright spec was generated, the existing script may be stale and Script
  // Generation must remain READY so the user can regenerate it.
  const generatedSpecRel = findArtifact(s, [`tests/issue-${s.issueId}.spec.ts`]);
  const currentStrategyRel = findArtifact(s, [finalStrategyRel(s)]);
  if (generatedSpecRel && !['completed','running','waiting_for_approval'].includes(s.stages.scriptGeneration.status) && !(s.stages.scriptGeneration.output as any)?.rerunRequired) {
    try {
      const generatedArtifacts = validateScriptGenerationArtifacts(s);
      const specMtime = fs.statSync(path.join(ROOT, generatedSpecRel)).mtimeMs;
      const strategyMtime = currentStrategyRel ? fs.statSync(path.join(ROOT, currentStrategyRel)).mtimeMs : 0;
      if (specMtime >= strategyMtime && generatedArtifacts.length) {
        const executionList = executionCases(s);
        s.stages.scriptGeneration = {
          ...s.stages.scriptGeneration,
          status: 'completed',
          completedAt: s.stages.scriptGeneration.completedAt || new Date(specMtime).toISOString(),
          output: {
            ...(s.stages.scriptGeneration.output as any || {}),
            artifacts: {
              spec: artifactDetails(generatedSpecRel),
              testData: artifactDetails(findArtifact(s, [`test-data/issue-${s.issueId}.json`])),
              pages: fs.existsSync(path.join(ROOT, 'pages'))
                ? fs.readdirSync(path.join(ROOT, 'pages')).filter(x => x.endsWith('.page.ts')).map(x => artifactDetails(path.join('pages', x)))
                : []
            },
            generatedArtifacts,
            testCases: parseGeneratedTests(s),
            executionCases: executionList,
            restoredFromArtifacts: true
          },
          message: `Existing Playwright script artifacts are present and current (${generatedSpecRel}); Test Script Generation restored as completed.`
        };
        addEvent(s, 'stage.restored', `Test Script Generation restored as completed from existing validated artifacts: ${generatedSpecRel}.`, 'scriptGeneration');
        changed = true;
      }
    } catch (e:any) {
      // Leave the stage READY if the existing files are incomplete or invalid.
    }
  }

  const finalStrategy = findArtifact(s, [finalStrategyRel(s)]);
  if (finalStrategy && s.stages.strategy.status !== 'running') {
    const proposal = parseStrategy(s, finalStrategy);
    if (proposal?.strategies?.length) {
      const candidateIds = [...new Set(
        [...fs.readFileSync(path.join(ROOT, finalStrategy), 'utf8').replace(/\r/g, '')
          .matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)]
          .map(m => m[1].toUpperCase())
      )];
      const included = candidateIds.length
        ? candidateIds
        : proposal.strategies
            .filter((x:any) => /^AUTOMATE\b/i.test(String(x.decision || '')))
            .map((x:any) => String(x.id).toUpperCase());
      const artifact = artifactDetails(finalStrategy);
      const shouldComplete = s.stages.strategy.status === 'ready' && !(s.stages.strategy.output as any)?.rerunRequired;
      if (shouldComplete || !s.stages.strategy.output) {
        s.stages.strategy = {
          ...s.stages.strategy,
          status: 'completed',
          completedAt: s.stages.strategy.completedAt || new Date().toISOString(),
          output: {
            ...(s.stages.strategy.output as any || {}),
            proposal,
            artifact,
            proposalArtifact: artifact,
            includedTestCases: included
          },
          message: `Existing approved strategy found at ${artifact!.localPath}.`
        };
        changed = true;
      }
    }
  }

  if (changed) save(s);
  return changed;
}
function editableMarkdownArtifact(s:Session,n:StageName):string|undefined {
  if(n==='scenarios') return findArtifact(s,[`test-scenarios/scenarios/${s.issueId}.md`,`test-scenarios/scenarios/issue-${s.issueId}.md`,`test-scenarios/scenarios/issue-${s.issueId}-e2e-scenarios.md`]);
  if(n==='strategy') return findArtifact(s,[finalStrategyRel(s),`test-scenarios/strategy/${s.issueId}-strategy-proposal.md`,`test-scenarios/strategy/${s.issueId}-strategy.md`]);
  return undefined;
}

function stripMd(value:string) { return value.replace(/[*_`]/g,'').trim(); }
function extractHealerProposal(raw:string):string {
  const clean=String(raw||'').replace(/\x1b\[[0-?]*[ -\/]*[@-~]/g,'').replace(/\r/g,'').trim();
  if(!clean) return '';
  const headings=[
    '### Diagnostic & Self-Healing Observation Report',
    '## Diagnostic & Self-Healing Observation Report',
    '# Diagnostic & Self-Healing Observation Report',
    'Diagnostic & Self-Healing Observation Report'
  ];
  for(const heading of headings){
    const idx=clean.toLowerCase().indexOf(heading.toLowerCase());
    if(idx>=0) return clean.slice(idx).trim();
  }
  const proposalIdx=clean.toLowerCase().lastIndexOf('observation & proposal report');
  if(proposalIdx>=0) return clean.slice(Math.max(0, proposalIdx-20)).trim();
  // Some Copilot versions do not preserve the requested heading. In that case,
  // keep the complete agent response visible rather than hiding a useful proposal.
  return clean;
}
function parsePipeRow(line:string):string[]|undefined {
  if(!/^\s*\|/.test(line)) return undefined;
  return line.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(stripMd);
}
async function fetchGitLabIssueForScenarioFallback(s:Session):Promise<{title:string,description:string}|undefined> {
  const token=runtimeSecrets.gitlabToken || process.env.GITLAB_PERSONAL_ACCESS_TOKEN || '';
  const base=(process.env.GITLAB_API_URL || 'https://gitlab.com/api/v4').replace(/\/$/,'');
  try {
    if(!token) return undefined;
    const issueUrl=new URL(s.issueUrl);
    const marker=issueUrl.pathname.match(/^(.*?)(?:\/-)?\/(?:issues|work_items)\/(\d+)\/?$/i);
    if(!marker) return undefined;
    const projectPath=decodeURIComponent(marker[1].replace(/^\/+|\/+$/g,''));
    const apiUrl=`${base}/projects/${encodeURIComponent(projectPath)}/issues/${encodeURIComponent(s.issueId)}`;
    const headers:Record<string,string>={'Accept':'application/json'};
    if(token) headers['PRIVATE-TOKEN']=token;
    const response=await fetch(apiUrl,{headers});
    if(!response.ok) return undefined;
    const data:any=await response.json();
    return {title:String(data.title||`Issue #${s.issueId}`),description:String(data.description||'')};
  } catch { return undefined; }
}

function extractFallbackCriteria(description:string):string[] {
  const lines=description.replace(/\r/g,'').split('\n').map(x=>x.trim()).filter(Boolean);
  const criteria:string[]=[];
  let inAcceptance=false;
  for(const line of lines){
    if(/^#{1,6}\s*(acceptance criteria|acceptance|ac)\b/i.test(line)){inAcceptance=true;continue;}
    if(inAcceptance && /^#{1,6}\s+/.test(line)){inAcceptance=false;continue;}
    if(inAcceptance){
      const value=line.replace(/^[-*+]\s+/, '').replace(/^\[[ xX]\]\s+/, '').replace(/^\d+[.)]\s+/, '').trim();
      if(value && !/^[-_*]{3,}$/.test(value)) criteria.push(value);
    }
  }
  if(!criteria.length){
    for(const line of lines){
      const value=line.replace(/^[-*+]\s+/, '').replace(/^\[[ xX]\]\s+/, '').replace(/^\d+[.)]\s+/, '').trim();
      if(/^(given|when|then)\b/i.test(value) || /^the (user|system|application)\b/i.test(value)) criteria.push(value);
      if(criteria.length>=8) break;
    }
  }
  return [...new Set(criteria)].slice(0,8);
}


function parseBusinessReview(s:Session, preferred?:string) {
  const rel=preferred || findArtifact(s,[`test-scenarios/business-review/issue-${s.issueId}-business-review.md`]);
  if(!rel) return undefined;
  const file=path.join(ROOT,rel);
  if(!fs.existsSync(file)) return undefined;
  const text=fs.readFileSync(file,'utf8').replace(/\r/g,'').replace(/\\n/g,'\n').replace(/\\r/g,'\r');
  // Parse by Markdown headings instead of one large regex. This tolerates
  // #/##/### headings, optional bold/colon formatting, and blank lines while
  // still keeping each review section isolated from the next one.
  const normalizeHeading=(value:string)=>value
    .replace(/^\s*[-*+]\s*/,'')
    .replace(/^\s*\*\*(.*?)\*\*\s*$/,'$1')
    .replace(/\s*:\s*$/,'')
    .replace(/\s+/g,' ')
    .trim()
    .toLowerCase();
  const sectionAliases:{[key:string]:string[]}={
    passed:['passed checks'],
    gaps:['critical gaps & ambiguities','critical gaps and ambiguities','critical gaps'],
    fixes:['recommended fixes','recommended actions','fixes']
  };
  const sections:{[key:string]:string[]}={passed:[],gaps:[],fixes:[]};
  let current:string|undefined;
  for(const rawLine of text.split('\n')){
    const line=rawLine.trim();
    const headingMatch=line.match(/^#{1,6}\s*(.+?)\s*$/);
    if(headingMatch){
      const heading=normalizeHeading(headingMatch[1]);
      current=undefined;
      for(const key of Object.keys(sectionAliases)){
        if(sectionAliases[key].includes(heading)){ current=key; break; }
      }
      continue;
    }
    if(current) sections[current].push(rawLine);
  }
  const list=(lines:string[])=>{
    const out:string[]=[];
    for(const raw of lines){
      const line=raw.trim();
      if(!line) continue;
      // Ignore metadata/decision lines if a malformed artifact places them in
      // a review section; otherwise preserve the actual finding text.
      if(/^[-*+]\s*\*\*(?:decision|decision request)\*\*\s*:/i.test(line)) continue;
      if(/^\*\*(?:decision|decision request)\*\*\s*:/i.test(line)) continue;
      const cleaned=line
        .replace(/^[-*+]\s+/,'')
        .replace(/^\d+[.)]\s+/,'')
        .replace(/^\[[ xX]\]\s+/,'')
        .replace(/^\*\*(.*?)\*\*\s*$/,'$1')
        .trim();
      if(cleaned) out.push(cleaned);
    }
    return [...new Set(out)];
  };
  const scoreMatch=text.match(/Completeness Score\s*:\s*\**\s*(\d{1,3})\s*%?/i);
  const decisionMatch=text.match(/Decision\s*:\s*\**\s*(READY_FOR_SCENARIOS|NEEDS_REVISION|REJECTED)\b/i);
  const decision=decisionMatch?.[1] || (/NEEDS[_ -]?REVISION/i.test(text)?'NEEDS_REVISION':'READY_FOR_SCENARIOS');
  const passed=list(sections.passed), gaps=list(sections.gaps), fixes=list(sections.fixes);
  return {
    artifact:artifactDetails(rel),
    completenessScore:Math.max(0,Math.min(100,Number(scoreMatch?.[1]||0))),
    passedChecks:passed,
    criticalGaps:gaps,
    recommendedFixes:fixes,
    decision,
    markdown:text
  };
}
function buildFallbackBusinessReview(s:Session, issue?:{title:string;description:string}, reason=''):string {
  const dir=path.join(ROOT,'test-scenarios','business-review'); fs.mkdirSync(dir,{recursive:true});
  const rel=`test-scenarios/business-review/issue-${s.issueId}-business-review.md`;
  const file=path.join(ROOT,rel);
  const title=issue?.title || `Issue #${s.issueId}`;
  const description=issue?.description || '';
  const criteria=extractFallbackCriteria(description);
  const vague=(description.match(/\b(fast|quick|easy|simple|intuitive|user-friendly|seamless|robust|scalable|efficient|reliable|responsive)\b/gi)||[]);
  const gaps:string[]=[];
  if(!description.trim()) gaps.push('The business requirement description is empty or could not be retrieved.');
  if(!criteria.length) gaps.push('No explicit Acceptance Criteria were found; each requirement needs at least one observable, testable acceptance criterion.');
  if(vague.length) gaps.push(`Subjective terms require measurable definitions: ${[...new Set(vague.map(x=>x.toLowerCase()))].join(', ')}.`);
  if(!/\b(user|customer|admin|operator|system|application)\b/i.test(description)) gaps.push('The requirement does not clearly identify the actor or system responsibility.');
  if(!/\b(should|must|shall|can|allow|prevent|display|return|save|create|update|delete|validate)\b/i.test(description)) gaps.push('The expected behavior/action is not stated clearly enough to derive deterministic tests.');
  const score=Math.max(0,Math.min(100,100-gaps.length*15));
  const decision=gaps.length?'NEEDS_REVISION':'READY_FOR_SCENARIOS';
  const passed=[
    description.trim()?'Requirement text is present.':'',
    criteria.length?`${criteria.length} acceptance criterion/criteria detected.`:'',
    !vague.length?'No subjective quality adjectives were detected.':''
  ].filter(Boolean);
  const fixes=gaps.map(g=>`Clarify and add concrete, observable details for: ${g}`);
  const lines=[
    '# Business Requirements Review',
    '',
    `- **Issue Reference**: #${s.issueId}`,
    `- **Issue Title**: ${title}`,
    `- **Generated Date**: ${new Date().toISOString().slice(0,10)}`,
    reason?`- **Review Mode**: Deterministic fallback because the reviewer agent was unavailable. Reason: ${reason}`:'',
    '',
    `- **Completeness Score:** ${score}%`,
    '',
    '## Passed Checks',
    ...passed.map(x=>`- ${x}`),
    '',
    '## Critical Gaps & Ambiguities',
    ...(gaps.length?gaps.map((x,i)=>`${i+1}. ${x}`):['- None identified.']),
    '',
    '## Recommended Fixes',
    ...(fixes.length?fixes.map(x=>`- ${x}`):['- No changes required before scenario generation.']),
    '',
    '## Decision',
    `- **Decision:** ${decision}`,
    `- **Decision Request:** Review the findings. Approve to continue to Test Scenarios, or request changes with specific feedback.`,
    ''
  ].filter(Boolean);
  fs.writeFileSync(file,lines.join('\n'),'utf8');
  return rel;
}
function artifactFreshEnough(rel:string|undefined, startedAtMs:number):boolean {
  if(!rel) return false;
  const file=path.resolve(ROOT,rel);
  try {
    const st=fs.statSync(file);
    return st.isFile() && st.mtimeMs >= startedAtMs - 1500;
  } catch { return false; }
}

async function executeBusinessReview(s:Session, feedback='') {
  const startedAtMs=Date.now();
  const reviewRel=`test-scenarios/business-review/issue-${s.issueId}-business-review.md`;
  try { const old=path.join(ROOT,reviewRel); if(fs.existsSync(old)) fs.unlinkSync(old); } catch {}
  let issueContext: {title:string;description:string}|undefined;
  try { issueContext=await fetchGitLabIssueForScenarioFallback(s); } catch {}
  if(!issueContext) throw new Error(`GitLab requirement #${s.issueId} could not be retrieved. Enter a valid GitLab token and verify the issue URL, then retry Business Requirements Review.`);
  addEvent(s,'stage.progress',`Authoritative GitLab requirement loaded: ${issueContext.title}`, 'businessReview');
  let raw='';
  try {
    raw=await runConfiguredAgent('businessReview',s,{
      ISSUE_TITLE:issueContext?.title || '',
      ISSUE_DESCRIPTION:issueContext?.description || '',
      BUSINESS_REVIEW_FEEDBACK:feedback
    });
  } catch(e:any) {
    const reason=e?.message || 'The business review agent did not complete.';
    const fresh=artifactFreshEnough(reviewRel,startedAtMs);
    if(!fresh) {
      addEvent(s,'stage.failed',`Business requirements reviewer agent failed. No fallback review was generated. Reason: ${reason}`,'businessReview');
      throw new Error(`Business requirements reviewer agent failed: ${reason}`);
    }
    addEvent(s,'stage.progress',`Business requirements reviewer agent returned a non-zero exit code, but it created a fresh review artifact during this run. Validating the artifact instead of treating the completed agent work as a failure.`,'businessReview');
    raw = raw || reason;
  }
  let rel=findArtifact(s,[reviewRel]);
  if(!rel) throw new Error('Business requirements reviewer agent completed without creating its review artifact. No fallback review was generated.');
  let review=parseBusinessReview(s,rel);
  if(!review) throw new Error('Business requirements reviewer agent created an invalid or unparseable review artifact. No fallback review was generated.');
  if(!review) throw new Error('Business requirements review artifact could not be created.');
  const message=review.decision==='READY_FOR_SCENARIOS'
    ? `Business requirements review is ready for approval (${review.completenessScore}% complete).`
    : `Business requirements review requires changes before scenario generation (${review.completenessScore}% complete).`;
  stage(s,'businessReview',{status:'waiting_for_approval',completedAt:undefined,output:{review,raw,fallback:false,fallbackReason:undefined,feedback},message});
  addEvent(s,'artifact.created',`Business requirements review: ${review.artifact?.localPath || rel}`,'businessReview');
  addEvent(s,'stage.progress',`Reviewer decision: ${review.decision}; completeness ${review.completenessScore}%.`,'businessReview');
}

async function buildFallbackScenarioArtifact(s:Session, reason:string):Promise<string> {
  const dir=path.join(ROOT,'test-scenarios','scenarios'); fs.mkdirSync(dir,{recursive:true});
  const rel=`test-scenarios/scenarios/${s.issueId}.md`;
  const file=path.join(ROOT,rel);
  const issue=await fetchGitLabIssueForScenarioFallback(s);
  const title=issue?.title || `Functional E2E scenarios for issue #${s.issueId}`;
  const criteria=extractFallbackCriteria(issue?.description || '');
  const primary=criteria.length ? criteria : [`Validate the primary user workflow described by GitLab issue #${s.issueId}.`];
  const happy=primary.slice(0,Math.min(primary.length,6));
  const rows:any[]=[];
  happy.forEach((criterion,i)=>rows.push({id:`TC-${String(i+1).padStart(3,'0')}`,category:'Happy Path',summary:criterion,priority:i===0?'P0':'P1',suggestedLayer:'E2E'}));
  rows.push({id:'TC-100',category:'Negative',summary:'Verify the application handles invalid or rejected input for the affected workflow.',priority:'P1',suggestedLayer:'E2E'});
  rows.push({id:'TC-400',category:'Edge Case',summary:'Verify the affected workflow handles boundary, repeated, or unexpected user actions without an unhandled error.',priority:'P2',suggestedLayer:'E2E'});
  const detail=rows.map((r:any)=>[
    `### ${r.id}: ${r.summary}`,
    `- **Category**: ${r.category}`,
    `- **Priority**: ${r.priority}`,
    `- **Preconditions**: Application is available and the relevant issue workflow can be reached.`,
    `- **Steps**:`,
    `  1. Navigate to the affected workflow described by issue #${s.issueId}.`,
    `  2. ${r.category==='Negative'?'Provide an invalid, missing, or rejected input and submit the workflow.':r.category==='Edge Case'?'Perform the boundary, repeated, or unexpected action relevant to the workflow.':`Perform the user action required by the scenario: ${r.summary}`}`,
    `  3. Observe the resulting UI and application state.`,
    `- **Expected Results**: The application behaves according to the requirement, provides the appropriate UI feedback, and does not produce an unhandled error.`
  ].join('\n'));
  const content=[
    `# E2E Test Scenarios: ${title}`,'',
    `- **Issue Reference**: #${s.issueId}`,
    `- **Generated Date**: ${new Date().toISOString().slice(0,10)}`,
    `- **Generation Mode**: Deterministic fallback (AI agent unavailable)`,
    `- **Fallback Reason**: ${reason.replace(/\r?\n/g,' ')}`,'',
    '## 1. Scenario Summary Matrix','',
    '| Scenario ID | Category | Summary Description | Priority | Suggested Layer |',
    '| :--- | :--- | :--- | :--- | :--- |',
    ...rows.map((r:any)=>`| **${r.id}** | ${r.category} | ${r.summary.replace(/\|/g,'\\|')} | ${r.priority} | ${r.suggestedLayer} |`),
    '', '## 2. Detailed Test Scenarios','', ...detail.flatMap(x=>[x,''])
  ].join('\n');
  fs.writeFileSync(file,content,'utf8');
  return rel;
}

function parseScenarios(s:Session) {
  const rel=findArtifact(s,[`test-scenarios/scenarios/issue-${s.issueId}.md`,`test-scenarios/scenarios/issue-${s.issueId}-e2e-scenarios.md`,`test-scenarios/scenarios/${s.issueId}.md`]);
  if(!rel) return undefined;
  const text=fs.readFileSync(path.join(ROOT,rel),'utf8').replace(/\r/g,'');
  const rows:any[]=[];
  for(const line of text.split('\n')) {
    const cells=parsePipeRow(line);
    if(!cells || !/^TC-\d+$/i.test(cells[0]||'')) continue;
    if(/scenario id/i.test(cells[0])) continue;
    rows.push({id:cells[0].toUpperCase(),category:cells[1]||'',summary:cells[2]||'',priority:cells[3]||'',suggestedLayer:cells[4]||''});
  }
  const unique=rows.filter((row,index,self)=>self.findIndex(x=>x.id===row.id)===index);
  return {artifact:rel,count:unique.length,scenarios:unique};
}
function strategyProposalRel(s:Session):string|undefined {
  return findArtifact(s,[
    `test-scenarios/strategy/${s.issueId}-strategy-proposal.md`,
    `test-scenarios/strategy/${s.issueId}-strategy.md`
  ]);
}
function finalStrategyRel(s:Session):string { return `test-scenarios/strategy/${s.issueId}-strategy.md`; }
function parseStrategy(s:Session, preferred?:string) {
  const rel=preferred || strategyProposalRel(s);
  if(!rel)return undefined;
  const text=fs.readFileSync(path.join(ROOT,rel),'utf8').replace(/\r/g,'');
  const decisions=new Map<string,{description:string,decision:string,tier:string,justification?:string}>();
  for(const line of text.split('\n')) {
    const cells=parsePipeRow(line);
    if(!cells || !/^TC-\d+$/i.test(cells[0]||'')) continue;
    const decision=cells[2]||'';
    if(!/^(AUTOMATE|OFFLOAD)\b/i.test(decision)) continue;
    decisions.set(cells[0].toUpperCase(),{id:cells[0].toUpperCase(),description:cells[1]||'',decision,tier:cells[3]||'',justification:cells[4]||''} as any);
  }
  // The scenario artifact is the authoritative list for the UI. The strategy proposal
  // only supplies the agent recommendation. This guarantees that OFFLOAD rows are
  // still visible and selectable even when the agent emits a lean/partial matrix.
  const all=parseScenarios(s)?.scenarios||[];
  const candidateIds=[...text.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)].map(m=>m[1].toUpperCase());
  const sourceRows=all.length ? all : [...decisions.entries()].map(([id,row])=>({id,category:'',summary:row.description,priority:'',suggestedLayer:''}));
  const strategies=sourceRows.map((scenario:any)=>{
    const id=String(scenario.id).toUpperCase();
    const row=decisions.get(id);
    const recommended=!!row ? /^AUTOMATE\b/i.test(row.decision) : candidateIds.includes(id);
    return {
      id,
      description:row?.description || scenario.summary || id,
      decision:row?.decision || (recommended?'AUTOMATE (E2E)':'OFFLOAD (Unit/API/Omit)'),
      tier:row?.tier || scenario.suggestedLayer || (recommended?'Regression':'Unit / API'),
      justification:row?.justification || (recommended?'Recommended by Test Strategy Agent.':'Not initially recommended for E2E; available for user override.')
    };
  });
  return {artifact:rel,strategies};
}
function prepareStrategyProposal(s:Session) {
  const dir=path.join(ROOT,'test-scenarios','strategy'); fs.mkdirSync(dir,{recursive:true});
  // Keep the last approved strategy intact while a new proposal is being generated.
  // If the external strategy agent is unavailable (for example because its monthly
  // quota is exhausted), it can be used as the recommendation source for the local
  // deterministic fallback instead of leaving the UI with no test cases to review.
  try{fs.unlinkSync(path.join(dir,`${s.issueId}-strategy-proposal.md`));}catch{}
}
function captureStrategyProposal(s:Session):string {
  const dir=path.join(ROOT,'test-scenarios','strategy');
  const proposal=path.join(dir,`${s.issueId}-strategy-proposal.md`);
  if(fs.existsSync(proposal)) return `test-scenarios/strategy/${s.issueId}-strategy-proposal.md`;
  const legacy=path.join(dir,`${s.issueId}-strategy.md`);
  if(fs.existsSync(legacy)) { fs.copyFileSync(legacy,proposal); try{fs.unlinkSync(legacy);}catch{}; return `test-scenarios/strategy/${s.issueId}-strategy-proposal.md`; }
  throw new Error(`Strategy agent completed but no strategy proposal was created for issue #${s.issueId}.`);
}
function extractApplicationUrl(s:Session):string {
  const parsed=parseScenarios(s);
  if(!parsed?.artifact) return s.appUrl || '';
  const text=fs.readFileSync(path.join(ROOT,parsed.artifact),'utf8');
  const match=text.match(/^-\s*\*\*Application URL\*\*:\s*(.+)$/mi);
  return (match?.[1] || s.appUrl || '').trim().replace(/[`]/g,'');
}

function buildFallbackStrategyProposal(s:Session):string {
  const parsed=parseScenarios(s);
  if(!parsed?.scenarios?.length) throw new Error(`Cannot create strategy fallback because no scenarios were found for issue #${s.issueId}.`);
  const dir=path.join(ROOT,'test-scenarios','strategy');
  fs.mkdirSync(dir,{recursive:true});
  const proposalRel=`test-scenarios/strategy/${s.issueId}-strategy-proposal.md`;
  const proposalFile=path.join(ROOT,proposalRel);

  // Prefer the last approved strategy as the agent recommendation when available.
  // This preserves the user's previously reviewed risk-based selection during a
  // temporary agent/quota outage.
  const priorFile=path.join(ROOT,finalStrategyRel(s));
  const priorText=fs.existsSync(priorFile)?fs.readFileSync(priorFile,'utf8').replace(/\r/g,''):'';
  const priorRecommended=new Set<string>([...priorText.matchAll(/^\|\s*(?:\*\*)?(TC-\d+)\b.*?\|\s*\*\*AUTOMATE(?: \(E2E\))?\*\*/gmi)].map(m=>m[1].toUpperCase()));

  // If there is no prior recommendation, use a conservative local risk rule:
  // P0/P1 scenarios are initially checked; P2 scenarios remain visible but unchecked.
  const recommended=(scenario:any)=>priorRecommended.size?priorRecommended.has(scenario.id.toUpperCase()):/P[01]/i.test(scenario.priority||'');
  const rows=parsed.scenarios.map((scenario:any)=>{
    const automate=recommended(scenario);
    const tier=automate ? (/P0/i.test(scenario.priority)?'Smoke / PR-Blocking':'Nightly Regression') : 'Unit / API';
    const justification=automate
      ? (priorRecommended.size ? 'Carried forward from the previously approved strategy recommendation; review and change the checkbox as needed.' : 'Deterministic fallback recommendation for a high-priority scenario; review and change the checkbox as needed.')
      : 'Visible for review but not initially recommended for E2E automation; review and change the checkbox as needed.';
    return `| **${scenario.id}** | ${scenario.summary} | **${automate?'AUTOMATE (E2E)':'OFFLOAD (Unit/API/Omit)'}** | ${tier} | ${justification} |`;
  });
  const candidates=parsed.scenarios.filter(recommended).map((scenario:any,i:number)=>buildCandidateBlock(s,scenario.id,i+1)).join('\n\n');
  const generatedDate=new Date().toISOString().slice(0,10);
  const content=[
    `# E2E Test Strategy Proposal: Issue #${s.issueId}`,
    '',
    `- **Issue Reference**: #${s.issueId}`,
    `- **Target Folder ID**: ${s.folderId}`,
    `- **Generated Date**: ${generatedDate}`,
    `- **Application Base URL**: ${extractApplicationUrl(s)}`,
    `- **Total Scenarios Analyzed**: ${parsed.scenarios.length}`,
    `- **Agent Recommended for E2E Automation**: ${parsed.scenarios.filter(recommended).length}`,
    '',
    '## 1. Scope & Automation Decision Matrix',
    '',
    '| Scenario ID | Scenario Description | Automation Decision | Tier / Frequency | Justification |',
    '| :--- | :--- | :--- | :--- | :--- |',
    ...rows,
    '',
    '## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)',
    '',
    '### Initially Recommended Test Cases',
    '',
    buildApprovedCasesTable(s, parsed.scenarios.filter(recommended).map((scenario:any)=>scenario.id)),
    '',
    candidates || '_No scenarios were initially recommended. Select one or more checkboxes in the UI before approval._',
    '',
    '## 3. Environment & Mocking Strategy',
    `- **Base URL**: ${extractApplicationUrl(s)}`,
    '- **Mocked Services**: None specified by the scenario artifact.',
    '- **Cleanup Strategy**: Start each test in a fresh browser context and restore the application to a clean state after each scenario.'
  ].join('\n');
  fs.writeFileSync(proposalFile,content,'utf8');
  return proposalRel;
}

function scenarioDetail(s:Session, id:string) {
  const parsed=parseScenarios(s);
  if(!parsed?.artifact)return undefined;
  const text=fs.readFileSync(path.join(ROOT,parsed.artifact),'utf8').replace(/\r/g,'');
  const lines=text.split('\n');
  const idx=lines.findIndex(line=>new RegExp(`^###\\s+${id}\\b`, 'i').test(line));
  if(idx<0)return undefined;
  const end=lines.findIndex((line,i)=>i>idx && (/^###\s+TC-\d+/i.test(line)||/^##\s+\d+\./.test(line)));
  const block=lines.slice(idx,end<0?lines.length:end);
  const heading=block[0].match(/^###\s+(TC-\d+)\s*:\s*(.*)$/i);
  const title=heading?.[2]?.trim() || id;
  const preIdx=block.findIndex(line=>/^[-*]\s+\*\*Preconditions\*\*:/i.test(line));
  const stepsIdx=block.findIndex(line=>/^[-*]\s+\*\*Steps\*\*\s*:/i.test(line));
  const expectedIdx=block.findIndex(line=>/^[-*]\s+\*\*Expected Results\*\*\s*:/i.test(line));
  const pre=preIdx>=0 ? block.slice(preIdx+1, Math.max(stepsIdx>=0?stepsIdx:block.length,preIdx+1)).map(x=>x.replace(/^\s*[-*]\s*/,'').trim()).filter(Boolean).join(' ') : 'Environment and application are available for the scenario.';
  const priority=parsed.scenarios.find(x=>x.id.toUpperCase()===id.toUpperCase())?.priority || 'P2';
  const importance=/P0/i.test(priority)?'VERY_HIGH':/P1/i.test(priority)?'HIGH':'MEDIUM';
  const steps:any[]=[];
  if(stepsIdx>=0){
    const stepLines=block.slice(stepsIdx+1,expectedIdx>=0?expectedIdx:block.length);
    for(let i=0;i<stepLines.length;i++){
      const m=stepLines[i].match(/^\s*\d+[.)]\s+(.*)$/);
      if(!m)continue;
      let action=m[1].replace(/\*\*/g,'').trim();
      let expected='Verify the expected outcome for the action.';
      const next=stepLines.slice(i+1).find(x=>/^\s*[-*]\s+\*\*Expected Result\*\*:/i.test(x));
      if(next) expected=next.replace(/^\s*[-*]\s+\*\*Expected Result\*\*:\s*/i,'').replace(/\*\*/g,'').trim();
      steps.push({action,expected});
    }
  }
  if(!steps.length)steps.push({action:`Execute the scenario: ${title}.`,expected:'The scenario behaves as specified in the source scenario document.'});
  return {title,priority,importance,prerequisite:pre,steps};
}

function buildCandidateBlock(s:Session,id:string,index:number,existing?:string) {
  if(existing && /\|\s*#\s*\|\s*Action\s*\|\s*Expected Result\s*\|/i.test(existing)) return existing.replace(/^###\s+Candidate\s+\d+/i,`### Candidate ${index}`);
  const detail=scenarioDetail(s,id);
  if(!detail) throw new Error(`Selected test case ${id} was not found in the scenario artifact.`);
  const escCell=(value:string)=>String(value||'').replace(/\|/g,'\\|').replace(/\r?\n/g,'<br>');
  return [
    `### Candidate ${index}: ${id} - ${detail.title}`,
    '',
    '| Field | Details |',
    '| :--- | :--- |',
    `| **Reference** | ${escCell(id)} |`,
    `| **Squash Folder ID** | ${escCell(String(s.folderId))} |`,
    `| **Importance (Squash Enum)** | ${escCell(detail.importance)} |`,
    `| **Execution Tier** | Regression |`,
    `| **Prerequisite** | ${escCell(detail.prerequisite)} |`,
    `| **Description** | ${escCell(detail.title)} |`,
    '',
    '#### Test Steps',
    '',
    '| # | Action | Expected Result |',
    '| ---: | :--- | :--- |',
    ...detail.steps.map((step:any,i:number)=>`| ${i+1} | ${escCell(step.action)} | ${escCell(step.expected)} |`)
  ].join('\n');
}

function buildApprovedCasesTable(s:Session, ids:string[], proposalRows?:Map<string,string>) {
  const all=parseScenarios(s)?.scenarios||[];
  const rows=ids.map(id=>{
    const scenario=all.find(x=>x.id.toUpperCase()===id.toUpperCase());
    const original=proposalRows?.get(id);
    const parsed=original ? parsePipeRow(original) : undefined;
    const title=parsed?.[1] || scenario?.summary || id;
    const priority=scenario?.priority || 'P2';
    const tier=parsed?.[3] || (/P0/i.test(priority)?'Smoke / PR-Blocking':/P1/i.test(priority)?'Nightly Regression':'Regression');
    return `| **${id}** | ${title} | ${priority} | **AUTOMATE (E2E)** | ${tier} |`;
  });
  return [
    '| Scenario ID | Test Case | Priority | Decision | Tier / Frequency |',
    '| :--- | :--- | :--- | :--- | :--- |',
    ...rows
  ].join('\n');
}

function rewriteApprovedStrategy(s:Session, includedIds:string[], proposalRel:string) {
  if(!proposalRel) throw new Error(`Strategy proposal not found for issue #${s.issueId}.`);
  const selected=[...new Set(includedIds.map(x=>String(x).trim().toUpperCase()).filter(Boolean))];
  if(!selected.length) throw new Error('Select at least one test case before approving the strategy.');
  if(selected.some(id=>!/^TC-\d+$/i.test(id))) throw new Error('Invalid test case selection.');

  const sourceFile=path.join(ROOT,proposalRel);
  if(!fs.existsSync(sourceFile)) throw new Error(`Strategy proposal not found for issue #${s.issueId}.`);
  const source=fs.readFileSync(sourceFile,'utf8').replace(/\r/g,'');
  const outputRel=finalStrategyRel(s);
  const outputFile=path.join(ROOT,outputRel);
  const all=parseScenarios(s)?.scenarios||[];

  // The proposal is agent-generated content and is not guaranteed to preserve one
  // exact Markdown heading/table layout. Test Scenarios are the authoritative catalog;
  // the proposal only supplies optional recommendation details. Never make approval
  // depend on a particular decision-matrix heading being present.
  const proposalRows=new Map<string,string>();
  for(const line of source.split('\n')){
    const cells=parsePipeRow(line);
    if(cells && /^TC-\d+$/i.test(cells[0]||'')){
      const id=cells[0].toUpperCase();
      if(cells.length>=2 && !proposalRows.has(id)) proposalRows.set(id,line);
    }
  }

  const selectedScenarios=selected.map(id=>{
    const scenario=all.find(x=>String(x.id).toUpperCase()===id);
    const original=proposalRows.get(id);
    const cells=original?parsePipeRow(original):undefined;
    if(!scenario && !cells) throw new Error(`Selected test case ${id} is not present in the Test Scenarios artifact or strategy proposal.`);
    const description=String(scenario?.summary || cells?.[1] || id).trim();
    const priority=String(scenario?.priority || 'P2').trim();
    const tier=String(cells?.[3] || (/P0/i.test(priority)?'Smoke / PR-Blocking':/P1/i.test(priority)?'Nightly Regression':'Regression')).trim();
    return {id,description,priority,tier};
  });

  const escCell=(value:string)=>String(value||'').replace(/\|/g,'\\|').replace(/\r?\n/g,'<br>');
  const matrixRows=selectedScenarios.map(x=>
    `| **${escCell(x.id)}** | ${escCell(x.description)} | **AUTOMATE (E2E)** | ${escCell(x.tier)} | User selected this case for final E2E automation approval. |`
  );
  const approvedTable=buildApprovedCasesTable(s,selected,proposalRows);
  const candidateBlocks=selectedScenarios.map((x,i)=>buildCandidateBlock(s,x.id,i+1)).join('\n\n');
  const generatedDate=new Date().toISOString().slice(0,10);
  const header=[
    `# E2E Test Strategy: Issue #${s.issueId}`,
    '',
    `- **Issue Reference**: #${s.issueId}`,
    `- **Target Folder ID**: ${s.folderId}`,
    `- **Generated Date**: ${generatedDate}`,
    `- **Application Base URL**: ${extractApplicationUrl(s)}`,
    `- **Approved for E2E Automation**: ${selected.length}`,
    ''
  ];
  const result=[
    ...header,
    '## 1. Scope & Automation Decision Matrix',
    '',
    '| Scenario ID | Scenario Description | Automation Decision | Tier / Frequency | Justification |',
    '| :--- | :--- | :--- | :--- | :--- |',
    ...matrixRows,
    '',
    '## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)',
    '',
    '### Approved Test Cases',
    '',
    approvedTable,
    '',
    candidateBlocks,
    '',
    '## 3. Environment & Mocking Strategy',
    `- **Base URL**: ${extractApplicationUrl(s)}`,
    '- **Mocked Services**: None specified by the scenario artifact.',
    '- **Cleanup Strategy**: Start each test in a fresh browser context and restore the application to a clean state after each scenario.'
  ].join('\n').replace(/\n{4,}/g,'\n\n\n');

  fs.mkdirSync(path.dirname(outputFile),{recursive:true});
  const tempFile=`${outputFile}.approval-${process.pid}-${Date.now()}.tmp`;
  fs.writeFileSync(tempFile,result,'utf8');
  fs.renameSync(tempFile,outputFile);
  return {relativePath:outputRel,localPath:path.resolve(ROOT,outputRel),selectedCount:selected.length};
}
function validateApprovedStrategy(s:Session, rel:string, selectedIds:string[]) {
  const text=fs.readFileSync(path.join(ROOT,rel),'utf8');
  const selected=[...new Set(selectedIds.map(x=>x.toUpperCase()))].sort();
  const lines=text.replace(/\r/g,'').split('\n');
  // Validate the decision matrix only. The final strategy also contains an
  // Approved Test Cases table, which intentionally repeats the same TC IDs.
  // Scanning the entire document therefore falsely reports duplicates.
  const matrixStart=lines.findIndex(x=>/^##\s+1\.\s+Scope\s*&\s*Automation\s+Decision\s+Matrix/i.test(x));
  const section2Start=lines.findIndex((x,i)=>i>matrixStart && /^##\s+2\.\s+Selected\s+E2E\s+Scenarios/i.test(x));
  if(matrixStart<0 || section2Start<0) throw new Error('Approved strategy is missing the decision matrix section.');
  const matrixText=lines.slice(matrixStart,section2Start).join('\n');
  // IDs can legitimately occur more than once in the generated Markdown (for example
  // a matrix row plus a repeated presentation row). Approval is based on the unique
  // test-case IDs, not raw occurrence counts. Never compare the whole document with a
  // global TC-* regex.
  // Parse only actual Decision Matrix rows. A TC ID may also occur in
  // explanatory text or repeated presentation tables; those occurrences must
  // never affect approval validation. De-duplicate IDs defensively.
  const matrixIds=[...new Set([...matrixText.matchAll(/^\|\s*(?:\*\*)?(TC-\d+)(?:\*\*)?\s*\|/gmi)].map(m=>m[1].toUpperCase()))].sort();
  const candidateEnd=lines.findIndex((x,i)=>i>section2Start && /^##\s+3\./.test(x));
  const candidateText=lines.slice(section2Start,candidateEnd>=0?candidateEnd:lines.length).join('\n');
  const candidateIds=[...new Set([...candidateText.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)].map(m=>m[1].toUpperCase()))].sort();
  const sameIds=(a:string[],b:string[])=>a.length===b.length && a.every((id,i)=>id===b[i]);
  if(!sameIds(matrixIds,selected)) throw new Error(`Approved strategy matrix mismatch. Expected only: ${selected.join(', ')}; found: ${matrixIds.join(', ')}.`);
  if(!sameIds(candidateIds,selected)) throw new Error(`Approved strategy candidate mismatch. Expected only: ${selected.join(', ')}; found: ${candidateIds.join(', ')}.`);
  const countMatch=text.match(/\*\*Approved for E2E Automation\*\*\s*:\s*(\d+)/i);
  if(!countMatch || Number(countMatch[1])!==selected.length) throw new Error(`Approved strategy count mismatch. Expected ${selected.length}.`);
}

function parseGeneratedTests(s:Session) {
  const rel=findArtifact(s,[`tests/issue-${s.issueId}.spec.ts`]);
  if(!rel) return [];
  const text=fs.readFileSync(path.join(ROOT,rel),'utf8');
  const cases:any[]=[];
  // Only parse real executable test()/it() declarations. test.describe() is a suite.
  // Support single/double/backtick strings and multiline formatting emitted by generators.
  const re=/(?:^|[\s;])(?:test|it)\s*\(\s*([\'"`])([\s\S]*?)\1\s*,/gm; let m:any;
  while((m=re.exec(text))) {
    const title=String(m[2]||'').trim();
    if(!title || title.startsWith('(')) continue;
    const idMatch=title.match(/\b(TC-\d+)\b/i);
    if(!idMatch) continue;
    const id=idMatch[1].toUpperCase();
    if(cases.some(x=>x.id===id)) continue;
    cases.push({id,title});
  }
  return cases;
}

function generatedExecutionCases(s:Session) {
  const generated=parseGeneratedTests(s);
  const dataRel=findArtifact(s,[`test-data/issue-${s.issueId}.json`]);
  let data:any={};
  if(dataRel){ try { data=JSON.parse(fs.readFileSync(path.join(ROOT,dataRel),'utf8')); } catch {} }
  const dataCases:any[]=[];
  if(Array.isArray(data)) {
    for(const item of data) {
      const id=String(item?.id || item?.reference || '').toUpperCase();
      if(/^TC-\d+$/.test(id)) dataCases.push({id,title:item?.title || item?.name || id});
    }
  } else if(data && typeof data==='object') {
    for(const [key,item] of Object.entries(data)) {
      const id=String((item as any)?.id || key).toUpperCase();
      if(/^TC-\d+$/.test(id)) dataCases.push({id,title:(item as any)?.title || (item as any)?.name || id});
    }
  }
  const merged=[...generated,...dataCases];
  return merged.filter((item:any,index:number,arr:any[])=>arr.findIndex(x=>x.id===item.id)===index)
    .map((item:any)=>({id:item.id,title:String(item.title||item.id).trim() || item.id}));
}

function executionCases(s:Session) {
  const generated=generatedExecutionCases(s);
  const approved=approvedExecutionCases(s);
  const allowed:Map<string,any>|undefined = approved.length ? new Map<string,any>(approved.map((x:any)=>[String(x.id).toUpperCase(),x] as [string,any])) : undefined;
  if(generated.length) {
    return generated.map((item:any)=>({id:item.id,title:item.title || allowed?.get(item.id)?.title || item.id}));
  }
  return approved.map((item:any)=>({id:String(item.id).toUpperCase(),title:String(item.title||item.id).trim() || item.id}));
}

function projectExecutionCatalog(primaryIssueId?: string) {
  const testsDir=path.join(ROOT,'tests');
  const catalog:any[]=[];
  if(!fs.existsSync(testsDir)) return catalog;
  const walk=(dir:string)=>{
    for(const entry of fs.readdirSync(dir,{withFileTypes:true})) {
      const full=path.join(dir,entry.name);
      if(entry.isDirectory()) walk(full);
      else if(entry.isFile() && /\.spec\.(?:ts|tsx|js|jsx|mjs|cjs)$/i.test(entry.name)) {
        const rel=path.relative(ROOT,full).replace(/\\/g,'/');
        const issueMatch=entry.name.match(/^issue-(\d+)\.spec\./i);
        if(!issueMatch) continue;
        const issueId=issueMatch[1];
        const text=fs.readFileSync(full,'utf8');
        const re=/(?:^|[\s;])(?:test|it)\s*\(\s*([\'"`])([\s\S]*?)\1\s*,/gm;
        let m:any;
        while((m=re.exec(text))) {
          const title=String(m[2]||'').trim();
          const idMatch=title.match(/\b(TC-\d+)\b/i);
          if(!idMatch) continue;
          const id=idMatch[1].toUpperCase();
          const key=`${issueId}::${id}`;
          if(catalog.some(x=>x.key===key)) continue;
          catalog.push({key,issueId,id,title,spec:rel});
        }
      }
    }
  };
  walk(testsDir);
  const primary=String(primaryIssueId||'').trim();
  return catalog.sort((a,b)=>{
    const ap=String(a.issueId)===primary ? 0 : 1;
    const bp=String(b.issueId)===primary ? 0 : 1;
    return ap-bp || Number(a.issueId)-Number(b.issueId) || a.id.localeCompare(b.id);
  });
}

function executionCatalogForSession(s:Session) {
  const catalog=projectExecutionCatalog(s.issueId);
  return catalog.length ? catalog : executionCases(s).map((x:any)=>({key:`${s.issueId}::${x.id}`,issueId:s.issueId,id:x.id,title:x.title,spec:`tests/issue-${s.issueId}.spec.ts`}));
}

function approvedExecutionCases(s:Session) {
  const strategyOutput:any=s.stages.strategy.output || {};
  const included=Array.isArray(strategyOutput.includedTestCases)
    ? [...new Set(strategyOutput.includedTestCases.map((x:any)=>String(x).trim().toUpperCase()).filter(Boolean))]
    : [];
  const all:any[] = strategyOutput?.proposal?.strategies || strategyOutput?.strategies || [];
  if(included.length) return (included as string[]).map((id:string)=>{
    const row=all.find((x:any)=>String(x.id).toUpperCase()===id);
    return {id, title:row?.description || id};
  });
  if(all.length) return all.filter((x:any)=>/^AUTOMATE\b/i.test(String(x.decision||'')))
    .map((x:any)=>({id:String(x.id).toUpperCase(),title:x.description||x.id}));

  // Backfill selection from the final approved strategy artifact for sessions created
  // by older UI builds that did not persist includedTestCases in stage output.
  const rel=findArtifact(s,[finalStrategyRel(s),`test-scenarios/strategy/${s.issueId}-strategy-proposal.md`]);
  if(!rel) return [];
  try {
    const text=fs.readFileSync(path.join(ROOT,rel),'utf8').replace(/\r/g,'');
    const ids=[...text.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)].map(m=>m[1].toUpperCase());
    if(ids.length) return [...new Set(ids)].map(id=>({id,title:id}));
    return [...new Set([...text.matchAll(/^\|\s*(?:\*\*)?(TC-\d+)(?:\*\*)?\s*\|.*?\|\s*\*\*AUTOMATE(?: \(E2E\))?\*\*/gmi)].map(m=>m[1].toUpperCase()))]
      .map(id=>({id,title:id}));
  } catch { return []; }
}


function reconcileStagePrerequisites(s:Session): boolean {
  let changed = false;
  // A completed Test Scenarios stage is proof that Business Requirements Review
  // was already approved. Older persisted sessions could lose that dependency
  // state after a restart, so restore it before enforcing the rerun gate.
  // An explicit approvalStatus from an older session is also treated as proof.
  const prior:any = s.stages.businessReview.output || {};
  const scenariosCompleted = s.stages.scenarios.status === 'completed';
  const businessAlreadyApproved = prior.approvalStatus === 'approved' ||
    prior.approvalStatus === 'approved_with_reviewer_override';
  if ((scenariosCompleted || businessAlreadyApproved) &&
      !['completed','running','waiting_for_approval'].includes(s.stages.businessReview.status)) {
    const review = parseBusinessReview(s);
    const approvedAt = prior.approvedAt || s.stages.scenarios.completedAt || new Date().toISOString();
    s.stages.businessReview = {
      ...s.stages.businessReview,
      status: 'completed',
      completedAt: s.stages.businessReview.completedAt || approvedAt,
      output: { ...prior, ...(review ? {review} : {}), approvalStatus: prior.approvalStatus || 'approved', approvedAt },
      message: 'Business Requirements Review was previously approved; restored as approved because Test Scenarios are already completed.'
    };
    addEvent(s,'stage.restored','Business Requirements Review restored as approved because Test Scenarios are already completed.','businessReview');
    changed = true;
  }

  // Test Execution must reflect the real repository state. If the current
  // approved strategy exists and a valid Playwright spec exists, an old READY
  // scriptGeneration flag must not block execution. We only refuse this repair
  // when the user explicitly marked the stage for rerun. The old timestamp-only
  // comparison was too brittle because generated files can have different mtimes
  // after checkout/copy/zip operations.
  if (s.stages.strategy.status === 'completed' &&
      !['completed','running','waiting_for_approval'].includes(s.stages.scriptGeneration.status) &&
      !(s.stages.scriptGeneration.output as any)?.rerunRequired) {
    const generatedSpecRel = findArtifact(s, [`tests/issue-${s.issueId}.spec.ts`, `tests/issue-${s.issueId}.spec.js`]);
    if (generatedSpecRel) {
      try {
        const generatedArtifacts = validateScriptGenerationArtifacts(s);
        if (generatedArtifacts.length) {
          const executionList = executionCases(s);
          s.stages.scriptGeneration = {
            ...s.stages.scriptGeneration,
            status: 'completed',
            completedAt: s.stages.scriptGeneration.completedAt || new Date().toISOString(),
            output: { ...(s.stages.scriptGeneration.output as any || {}), generatedArtifacts, executionCases: executionList, restoredFromArtifacts: true },
            message: `Existing valid Playwright script artifacts are present (${generatedSpecRel}); Test Script Generation restored as completed.`
          };
          addEvent(s,'stage.restored',`Test Script Generation restored as completed from existing Playwright artifacts: ${generatedSpecRel}.`,'scriptGeneration');
          changed = true;
        }
      } catch {}
    }
  }
  if (changed) save(s);
  return changed;
}

function requireStage(s:Session,n:StageName){
  hydrateExistingArtifacts(s);
  reconcileStagePrerequisites(s);
  if(n==='scenarios' && s.stages.businessReview.status!=='completed') throw new Error('Business Requirements Review must be approved before Test Scenarios can start.');
  if(n==='strategy' && s.stages.scenarios.status!=='completed') throw new Error('Test Scenarios must be completed before Test Strategy can start.');
  if(n==='squash' && s.stages.strategy.status!=='completed') throw new Error('Test Strategy must be approved before Squash Upload can start.');
  if(n==='scriptGeneration' && s.stages.strategy.status!=='completed') throw new Error('Test Strategy must be approved before Script Generation can start.');
  if(n==='execution' && s.stages.scriptGeneration.status!=='completed') throw new Error('Test Script Generation must be completed before Test Execution can start.');
  if(n==='squashExecution' && s.stages.squashExecution.status==='locked') throw new Error('Squash Test Case Execution is locked until Test Execution has completed and produced results. Test Healer is not required.');
  if(n==='defect' && !defectReportingAvailable(s)) throw new Error('Defect Reporting is available after a Test Execution or Test Healer failure.');
  if(!['ready','completed','failed','waiting_for_approval'].includes(s.stages[n].status)) throw new Error(`Stage ${n} is not ready. Current status: ${s.stages[n].status}`);
}

async function startMcp(kind:'gitlab'|'playwright') {
  if(kind==='gitlab' && !runtimeSecrets.gitlabToken) throw new Error('GitLab MCP token is not configured. Enter it in the UI first.');
  if(mcp[kind] && !mcp[kind]!.killed) return;
  const isGitlab=kind==='gitlab';
  // Windows exposes npm's npx shim as npx.cmd. Spawning plain `npx` from Node can fail with ENOENT.
  const defaultCommand = process.platform==='win32' ? 'npx.cmd' : 'npx';
  const command=process.env[isGitlab?'GITLAB_MCP_COMMAND':'PLAYWRIGHT_MCP_COMMAND'] || defaultCommand;
  const args=(process.env[isGitlab?'GITLAB_MCP_ARGS':'PLAYWRIGHT_MCP_ARGS'] || (isGitlab?'--no-install @zereight/mcp-gitlab':'--no-install @playwright/mcp --headless')).match(/(?:[^\s"]+|"[^"]*")+/g) || [];
  const env=sanitizedEnv();
  // Runtime UI secret wins and is not persisted. Do not fall back to .env token values.
  if(isGitlab){ env.GITLAB_PERSONAL_ACCESS_TOKEN=runtimeSecrets.gitlabToken!; env.GITLAB_API_URL=env.GITLAB_API_URL||'https://gitlab.com/api/v4'; env.GITLAB_READ_ONLY_MODE=env.GITLAB_READ_ONLY_MODE||'false'; }
  // Windows can return EINVAL when Node tries to spawn the npm .cmd shim directly
  // in some environments. Run the shim through cmd.exe instead; stdio is still
  // passed through unchanged so MCP's stdio transport continues to work.
  let child: ChildProcessWithoutNullStreams;
  if (process.platform === 'win32') {
    const comspec = process.env.ComSpec || process.env.COMSPEC || 'cmd.exe';
    const commandLine = [command, ...args].map(a => /[\s"&|<>^]/.test(a) ? `\"${a.replace(/\"/g, '\\"')}\"` : a).join(' ');
    child = spawn(comspec, ['/d', '/s', '/c', commandLine], { cwd: ROOT, env, stdio: 'pipe', windowsHide: true });
  } else {
    child = spawn(command, args, { cwd: ROOT, env, stdio: 'pipe' });
  }
  mcp[kind]=child;
  child.stderr.on('data',d=>console.error(`[${kind}] ${d}`));
  child.on('error',err=>console.error(`[${kind}] process error: ${err.message}`));
  child.on('exit',()=>{mcp[kind]=undefined;});
}
function stopMcp(kind:'gitlab'|'playwright'){if(mcp[kind]){mcp[kind]!.kill();mcp[kind]=undefined;}}
function mcpStatus(){return {gitlab:!!mcp.gitlab&&!mcp.gitlab.killed,playwright:!!mcp.playwright&&!mcp.playwright.killed};}

async function handle(req:http.IncomingMessage,res:http.ServerResponse){
  const u=new URL(req.url||'/',`http://${req.headers.host}`); const p=u.pathname;
  try {
    if(req.method==='GET' && p==='/api/health') return json(res,200,{ok:true,mcp:mcpStatus()});
    if(req.method==='GET' && p==='/api/artifact'){const requested=u.searchParams.get('path'); if(!requested)return json(res,400,{error:'Artifact path is required'}); return artifactPreview(res,requested);}
    const rp=p.match(/^\/api\/session\/([^/]+)\/report\/([^/]+)(?:\/(.*))?$/); if(req.method==='GET'&&rp){const rs=sessions.get(rp[1]); if(!rs)return json(res,404,{error:'Session not found'}); const rn=rp[2] as StageName; if(!(rn in rs.stages))return json(res,404,{error:'Unknown stage'}); if(rp[3] && rn==='execution' && hasExecutionReport(rs)) return serveReportFile(res,executionReportDir(rs),rp[3]); return stageReport(res,rs,rn);}
    if(req.method==='GET' && p==='/api/mcp/status') return json(res,200,mcpStatus());
    if(req.method==='POST' && p==='/api/secrets'){const b=await readBody(req); if(typeof b.gitlabToken==='string' && b.gitlabToken.trim()) runtimeSecrets.gitlabToken=b.gitlabToken.trim(); if(typeof b.squashToken==='string' && b.squashToken.trim()) runtimeSecrets.squashToken=b.squashToken.trim(); return json(res,200,secretStatus());}
    if(req.method==='POST' && p==='/api/secrets/clear'){runtimeSecrets.gitlabToken=undefined; runtimeSecrets.squashToken=undefined; stopMcp('gitlab'); return json(res,200,secretStatus());}
    if(req.method==='GET' && p==='/api/secrets/status') return json(res,200,secretStatus());
    if(req.method==='POST' && p==='/api/mcp/start'){const b=await readBody(req); const kinds=b.kind==='all'?['gitlab','playwright']:[b.kind]; for(const k of kinds) await startMcp(k); return json(res,200,mcpStatus());}
    if(req.method==='POST' && p==='/api/mcp/stop'){const b=await readBody(req); const kinds=b.kind==='all'?['gitlab','playwright']:[b.kind]; for(const k of kinds) stopMcp(k); return json(res,200,mcpStatus());}
    if(req.method==='POST' && p==='/api/session'){
      const b=await readBody(req); const issueId=issueIdFromUrl(b.issueUrl||'');
      if(!runtimeSecrets.gitlabToken && !process.env.GITLAB_PERSONAL_ACCESS_TOKEN) return json(res,400,{error:'GitLab token is required before creating a workspace. Enter the GitLab token in Project setup so the requirement can be verified from GitLab.'});
      const s:Session={id:randomUUID(),issueUrl:b.issueUrl,issueId,folderId:Number(b.testCaseFolderId||b.folderId||1),testCaseFolderId:Number(b.testCaseFolderId||b.folderId||1),executionFolderName:String(b.executionFolderName||`Issue #${issueId} Execution`),campaignName:String(b.campaignName||`Issue #${issueId} Campaign`),iterationName:String(b.iterationName||`Issue #${issueId} Iteration`),testSuiteName:typeof b.testSuiteName==='string'&&b.testSuiteName.trim()?b.testSuiteName.trim():undefined,appUrl:b.appUrl,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),mcp:mcpStatus(),stages:initStages(),events:[]};
      const issueContext=await fetchGitLabIssueForScenarioFallback(s);
      if(!issueContext) return json(res,400,{error:`GitLab requirement #${issueId} could not be retrieved. Verify the issue URL, project access, GitLab token, and GITLAB_API_URL.`});
      s.issueTitle=issueContext.title; sessions.set(s.id,s);
      addEvent(s,'session.created',`Session created from authoritative GitLab requirement #${issueId} — ${s.issueTitle}`);
      addEvent(s,'gitlab.verified',`Verified GitLab requirement #${issueId}: ${s.issueTitle}. Business review will use this retrieved title and description as its source of truth.`);
      hydrateExistingArtifacts(s); reconcileStagePrerequisites(s);
      if(s.stages.scenarios.status==='completed') addEvent(s,'stage.restored','Existing Test Scenarios artifact detected; Test Scenarios restored as completed.','scenarios');
      if(s.stages.strategy.status==='completed') addEvent(s,'stage.restored','Existing approved Test Strategy artifact detected; Test Strategy restored as completed.','strategy');
      return json(res,201,s);
    }
    const sm=p.match(/^\/api\/session\/([^/]+)$/); if(req.method==='GET'&&sm){const s=sessions.get(sm[1]); if(!s)return json(res,404,{error:'Session not found'}); hydrateExistingArtifacts(s); reconcileStagePrerequisites(s); if(!s.issueTitle){ try { const issueContext=await fetchGitLabIssueForScenarioFallback(s); if(issueContext?.title){s.issueTitle=issueContext.title; save(s);} } catch {} } s.mcp=mcpStatus(); const catalog=executionCatalogForSession(s); const execOut:any=s.stages.execution.output||{}; if(JSON.stringify(execOut.catalog||[])!==JSON.stringify(catalog)){ stage(s,'execution',{output:{...execOut,catalog}}); } if(s.stages.scriptGeneration.status==='completed'){ const currentCases=executionCases(s); const out:any=s.stages.scriptGeneration.output||{}; if(JSON.stringify(out.executionCases||[])!==JSON.stringify(currentCases)){ stage(s,'scriptGeneration',{output:{...out,executionCases:currentCases}}); } } return json(res,200,s);}
    const stopMatch=p.match(/^\/api\/session\/([^/]+)\/stage\/([^/]+)\/stop$/);
    if(req.method==='POST'&&stopMatch){
      const s=sessions.get(stopMatch[1]); if(!s)return json(res,404,{error:'Session not found'});
      const n=stopMatch[2] as StageName; if(!(n in s.stages))return json(res,400,{error:'Unknown stage'});
      const key=`${s.id}:${n}`; const active=activeRuns.get(key);
      if(s.stages[n].status!=='running' && !active) return json(res,400,{error:`Stage is ${s.stages[n].status}; nothing is running.`});
      if(active){ active.stopRequested=true; killProcessTree(active.child); }
      stage(s,n,{status:'ready',completedAt:new Date().toISOString(),message:'Stopped by user.',error:undefined});
      addEvent(s,'stage.stopped','Stopped by user.',n);
      if(n==='healer') stage(s,n,{status:'ready',message:'Stopped by user. Review the queued cases and run Healer again when ready.'});
      return json(res,200,s);
    }
    const clearEvents=p.match(/^\/api\/session\/([^/]+)\/events\/clear$/); if(req.method==='POST'&&clearEvents){
      const s=sessions.get(clearEvents[1]); if(!s)return json(res,404,{error:'Session not found'});
      s.events=[]; save(s); return json(res,200,s);
    }
    const editArtifact=p.match(/^\/api\/session\/([^/]+)\/artifact\/(scenarios|strategy)$/);
    if(editArtifact && req.method==='GET'){
      const s=sessions.get(editArtifact[1]); if(!s)return json(res,404,{error:'Session not found'});
      const n=editArtifact[2] as StageName; const rel=editableMarkdownArtifact(s,n);
      if(!rel)return json(res,404,{error:`No editable ${n} Markdown artifact found.`});
      const file=path.resolve(ROOT,rel); if(!file.startsWith(`${ROOT}${path.sep}`)||path.extname(file).toLowerCase()!=='.md')return json(res,403,{error:'Invalid editable artifact'});
      return json(res,200,{stage:n,path:rel,content:fs.readFileSync(file,'utf8')});
    }
    if(editArtifact && req.method==='PUT'){
      const s=sessions.get(editArtifact[1]); if(!s)return json(res,404,{error:'Session not found'});
      const n=editArtifact[2] as StageName; const rel=editableMarkdownArtifact(s,n);
      if(!rel)return json(res,404,{error:`No editable ${n} Markdown artifact found.`});
      const b=await readBody(req); if(typeof b.content!=='string')return json(res,400,{error:'Markdown content is required.'});
      const file=path.resolve(ROOT,rel); if(!file.startsWith(`${ROOT}${path.sep}`)||path.extname(file).toLowerCase()!=='.md')return json(res,403,{error:'Invalid editable artifact'});
      fs.writeFileSync(file,b.content.replace(/\r\n/g,'\n'),'utf8');
      if(n==='scenarios'){
        const parsed=parseScenarios(s);
        if(parsed) {
          stage(s,'scenarios',{status:'completed',completedAt:new Date().toISOString(),output:{...(s.stages.scenarios.output||{}),...parsed,artifact:artifactDetails(rel),rerunRequired:false},message:`Scenario Markdown edited and saved to ${rel}.`});
          // Editing a completed scenario changes the input to Test Strategy. The
          // previous strategy approval must therefore be invalidated before the
          // next strategy proposal is generated.
          const downstream:StageName[]=['strategy','squash','scriptGeneration','execution','healer','squashExecution','gitlabCommit'];
          stage(s,'strategy',{status:'ready',completedAt:undefined,output:{rerunRequired:true},error:undefined,message:'Scenario was edited and saved. A fresh Test Strategy proposal is required.'});
          for(const d of downstream.slice(1)) {
            if(d==='squashExecution') stage(s,d,{status:'locked',output:{},completedAt:undefined,error:undefined,message:'Complete the newly approved Test Strategy and Test Execution before creating Squash executions.'});
            else stage(s,d,{status:'ready',output:{},completedAt:undefined,error:undefined});
          }
          addEvent(s,'stage.invalidated','Test Strategy and downstream stages were invalidated because Test Scenarios were edited.','strategy');
        }
      } else if(n==='strategy'){
        const proposal=parseStrategy(s,rel);
        if(proposal){
          const includedTestCases=[...new Set((proposal.strategies||[]).filter((x:any)=>/^AUTOMATE\b/i.test(String(x.decision||''))).map((x:any)=>String(x.id||'').trim().toUpperCase()).filter(Boolean))];
          // Editing an already-approved strategy creates a new reviewable revision.
          // Do not leave it in COMPLETED state: the user must explicitly approve the
          // edited strategy again before downstream stages can continue.
          stage(s,'strategy',{status:'waiting_for_approval',completedAt:undefined,error:undefined,output:{...(s.stages.strategy.output||{}),proposal,artifact:artifactDetails(rel),proposalArtifact:artifactDetails(rel),includedTestCases,rerunRequired:false,editedAfterApproval:true},message:`Strategy Markdown edited and saved to ${rel}. Review and approve the updated strategy before continuing.`});
          const downstream:StageName[]=['squash','scriptGeneration','execution','healer','squashExecution','gitlabCommit'];
          for(const d of downstream){
            if(d==='squashExecution') stage(s,d,{status:'locked',output:{},completedAt:undefined,error:undefined,message:'Approve the updated Test Strategy and complete Test Execution before creating Squash executions.'});
            else stage(s,d,{status:'ready',output:{},completedAt:undefined,error:undefined,message:'Waiting for the updated approved Test Strategy.'});
          }
          addEvent(s,'stage.invalidated','Test Strategy was edited after approval; approval and downstream stages were reset.','strategy');
        }
      }
      addEvent(s,'artifact.edited',`${n==='scenarios'?'Test Scenarios':'Test Strategy'} Markdown saved: ${rel}`,n); save(s);
      return json(res,200,{ok:true,stage:n,path:rel,content:b.content});
    }
    const am=p.match(/^\/api\/session\/([^/]+)\/stage\/([^/]+)\/start$/); if(req.method==='POST'&&am){const s=sessions.get(am[1]); if(!s)return json(res,404,{error:'Session not found'}); const n=am[2] as StageName; if(!(n in s.stages))return json(res,400,{error:'Unknown stage'}); hydrateExistingArtifacts(s); reconcileStagePrerequisites(s); requireStage(s,n); const b=await readBody(req); if(b.appUrl)s.appUrl=b.appUrl;
      // Starting Scenarios or Strategy again invalidates the previous approval chain.
      // Keep the old files on disk for traceability, but mark this stage as requiring a
      // fresh run so hydrateExistingArtifacts cannot silently restore the old result.
      if(n==='scenarios' || n==='strategy') {
        const downstream:StageName[] = n==='scenarios'
          ? ['strategy','squash','scriptGeneration','execution','healer','squashExecution','gitlabCommit']
          : ['squash','scriptGeneration','execution','healer','squashExecution','gitlabCommit'];
        stage(s,n,{output:{rerunRequired:true},error:undefined,completedAt:undefined});
        for(const d of downstream) {
          if(d==='strategy' && n==='scenarios') stage(s,d,{status:'ready',output:{rerunRequired:true},error:undefined,completedAt:undefined,message:'Waiting for a fresh Test Strategy proposal after Test Scenarios rerun.'});
          else if(d==='squash' || d==='scriptGeneration') stage(s,d,{status:'ready',output:{},error:undefined,completedAt:undefined,message:'Waiting for the newly approved Test Strategy.'});
          else if(d==='squashExecution') stage(s,d,{status:'locked',output:{},error:undefined,completedAt:undefined,message:'Complete the new Test Execution before creating Squash executions.'});
          else stage(s,d,{status:'ready',output:{},error:undefined,completedAt:undefined});
        }
      }
      if(n==='healer' && !defectReportingAvailable(s) && s.stages.defect.status!=='completed') stage(s,'defect',{status:'locked',output:{},completedAt:undefined,error:undefined,message:'Available after a Test Execution or Test Healer failure.'});
      stage(s,n,{status:'running',startedAt:new Date().toISOString(),message:n==='healer'?'Preparing the healing proposal for review...':'Generating a fresh result for review...'}); addEvent(s,'stage.started',`Started ${n}${n==='scenarios'||n==='strategy'?' (rerun; previous approval is invalid until this run is reviewed)':''}`,n);
      try {
        let output:any='';
        if(n==='businessReview'){
          await executeBusinessReview(s);
        }
        else if(n==='scenarios'){
          // Fetch the issue once through the backend and pass the authoritative
          // title/description to the agent. The scenario agent does not need a
          // second GitLab MCP round-trip just to retrieve the same context.
          let issueContext: {title:string;description:string}|undefined;
          try { issueContext=await fetchGitLabIssueForScenarioFallback(s); } catch {}
          if(!issueContext) throw new Error(`GitLab requirement #${s.issueId} could not be retrieved. Test Scenarios will not generate from an unverified requirement.`);
          addEvent(s,'stage.progress',`Authoritative GitLab requirement loaded: ${issueContext.title}`,n);
          const scenarioRel=`test-scenarios/scenarios/${s.issueId}.md`;
          const scenarioStartedAt=Date.now();
          try { const old=path.join(ROOT,scenarioRel); if(fs.existsSync(old)) fs.unlinkSync(old); } catch {}
          try {
            output=await runConfiguredAgent(n,s,{ISSUE_TITLE:issueContext.title,ISSUE_DESCRIPTION:issueContext.description});
          } catch(e:any) {
            if(!artifactFreshEnough(scenarioRel,scenarioStartedAt)) throw e;
            output=String(e?.message || 'Agent returned a non-zero exit code after creating the scenario artifact.');
            addEvent(s,'stage.progress','Test Scenarios agent returned a non-zero exit code, but it created a fresh scenario artifact during this run. Validating the artifact instead of treating the completed agent work as a failure.','scenarios');
          }
          let parsed=parseScenarios(s);
          if(!parsed?.scenarios?.length) throw new Error(`Test Scenarios agent completed without creating a parseable scenario artifact for issue #${s.issueId}. No fallback scenarios were generated.`);
          if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s);
          const artifact=artifactDetails(parsed.artifact);
          const message=`Scenario description created at ${artifact!.localPath}`;
          stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{...parsed,artifact,raw:output,fallback:false},message});
          addEvent(s,'artifact.created',`Scenario description: ${artifact!.localPath}`,n);
          unlockAfter(s,n);
        }
        else if(n==='strategy'){
          prepareStrategyProposal(s);
          const strategyStartedAt=Date.now();
          // The strategy agent's normal output is the proposal artifact. The final
          // approved strategy must remain intact until approval, so do not use the
          // final strategy path as the freshness check for a new proposal.
          const strategyCaptureTarget=`test-scenarios/strategy/${s.issueId}-strategy-proposal.md`;
          const strategyLegacyTarget=finalStrategyRel(s);
          try { const old=path.join(ROOT,strategyCaptureTarget); if(fs.existsSync(old)) fs.unlinkSync(old); } catch {}
          let output:string;
          try {
            output=await runConfiguredAgent(n,s);
          } catch(e:any) {
            const freshProposal=artifactFreshEnough(strategyCaptureTarget,strategyStartedAt);
            const freshLegacy=artifactFreshEnough(strategyLegacyTarget,strategyStartedAt);
            if(!freshProposal && !freshLegacy) throw e;
            output=String(e?.message || 'Agent returned a non-zero exit code after creating the strategy artifact.');
            addEvent(s,'stage.progress','Test Strategy agent returned a non-zero exit code, but it created a fresh strategy artifact during this run. Validating the artifact instead of treating the completed agent work as a failure.','strategy');
          }
          let proposalRel:string;
          try {
            proposalRel=captureStrategyProposal(s);
          } catch(e:any) {
            throw new Error(`Test Strategy agent completed without creating a proposal artifact: ${e?.message || 'unknown error'}. No fallback strategy was generated.`);
          }
          const proposal=parseStrategy(s,proposalRel);
          const artifact=artifactDetails(proposalRel);
          if(!proposal?.strategies?.length) throw new Error('Test Strategy agent created an invalid or empty proposal artifact. No fallback strategy was generated.');
          if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s);
          const message=`Strategy proposal created at ${artifact!.localPath}. Review the selection before approval.`;
          stage(s,n,{status:'waiting_for_approval',output:{proposal,artifact,proposalArtifact:artifact,raw:output,fallback:false},message});
          addEvent(s,'artifact.created',`Strategy proposal: ${artifact!.localPath}`,n);
        } else if(n==='squash'){
          // Squash synchronization is source-driven and idempotent. Reuse the
          // configured folder and existing test cases; create only genuinely new
          // cases, and update an existing same-reference case instead of creating
          // a duplicate. Never use PASS/FAIL as a synchronization filter.
          const strategyRel=findArtifact(s,[finalStrategyRel(s)]);
          const scenarioRel=findArtifact(s,[`test-scenarios/scenarios/${s.issueId}.md`]);
          if(!strategyRel) throw new Error(`Approved strategy file ${finalStrategyRel(s)} was not found. Approve Test Strategy before running Squash.`);
          if(!scenarioRel) throw new Error(`Scenario artifact for issue #${s.issueId} was not found.`);
          const token=runtimeSecrets.squashToken;
          if(!token) throw new Error('Squash token is not configured. Enter it in the UI first.');
          const base=process.env.SQUASH_BASE_URL || 'http://localhost:8080/squash/api/rest/latest/test-cases';
          const {syncApprovedTestCasesToSquash}=require(path.join(ROOT,'utils','sync-approved-squash.js'));
          addEvent(s,'stage.progress',`Synchronizing approved test cases into existing Squash Test Case Folder ${s.testCaseFolderId}...`,n);
          const syncResult=await syncApprovedTestCasesToSquash({
            rootDir:ROOT, baseUrl:base, token, folderId:Number(s.testCaseFolderId),
            strategyPath:strategyRel, scenarioPath:scenarioRel, issueId:s.issueId
          });
          const squashDir=path.join(ROOT,'test-scenarios','squash'); fs.mkdirSync(squashDir,{recursive:true});
          const rel=`test-scenarios/squash/testcase_${s.issueId}.json`;
          fs.writeFileSync(path.join(ROOT,rel),JSON.stringify(syncResult.payload,null,2),'utf8');
          const artifact=artifactDetails(rel);
          addEvent(s,'artifact.created',`Squash payload created from approved strategy: ${artifact!.localPath}`,n);
          addEvent(s,'stage.progress',`Squash synchronization complete: ${syncResult.uploadedCount} new, ${syncResult.updatedCount||0} updated/reused, ${syncResult.duplicateReferences?.length||0} duplicate-reference group(s) detected.`,n);
          stage(s,n,{
            status:'completed', completedAt:new Date().toISOString(),
            output:{
              payload:artifact, selectedIds:syncResult.selectedIds, uploaded:syncResult.uploaded,
              updated:syncResult.updated||[], kept:syncResult.kept,
              duplicateReferences:syncResult.duplicateReferences||[], sourceStrategy:artifactDetails(strategyRel),
              squashFolder:syncResult.folder
            },
            message:`Synchronized ${syncResult.selectedIds.length} approved test case(s) into Squash folder ${syncResult.folder.id}; ${syncResult.uploadedCount} new and ${syncResult.updatedCount||0} updated/reused. Existing resources were preserved.`
          });
          unlockAfter(s,n);
        } else if(n==='squashExecution') {
          const token=runtimeSecrets.squashToken;
          if(!token) throw new Error('Squash token is not configured. Enter it in the UI first.');
          const base=process.env.SQUASH_BASE_URL || 'http://localhost:8080/squash/api/rest/latest';
          const utilPath=path.join(ROOT,'utils','execution','upload-squash-execution.js');
          if(!fs.existsSync(utilPath)) throw new Error(`Squash execution utility was not found at ${utilPath}`);
          // The Squash execution stage is intentionally self-contained: before creating
          // any execution records, synchronize the approved source test cases into the
          // existing Squash Test Case Folder. This prevents an operator from having to
          // run the separate Squash synchronization button first.
          const strategyRel=findArtifact(s,[finalStrategyRel(s),`test-scenarios/strategy/${s.issueId}-strategy-proposal.md`]);
          const scenarioRel=findArtifact(s,[`test-scenarios/scenarios/${s.issueId}.md`]);
          if(!strategyRel) throw new Error(`Approved strategy file ${finalStrategyRel(s)} was not found. Approve Test Strategy before creating Squash executions.`);
          if(!scenarioRel) throw new Error(`Scenario artifact for issue #${s.issueId} was not found.`);
          const {syncApprovedTestCasesToSquash}=require(path.join(ROOT,'utils','sync-approved-squash.js'));
          addEvent(s,'stage.progress',`Synchronizing approved test cases into existing Squash Test Case Folder ${s.testCaseFolderId} before execution...`,n);
          const syncResult=await syncApprovedTestCasesToSquash({rootDir:ROOT,baseUrl:process.env.SQUASH_BASE_URL||'http://localhost:8080/squash/api/rest/latest/test-cases',token,folderId:Number(s.testCaseFolderId),strategyPath:strategyRel,scenarioPath:scenarioRel,issueId:s.issueId});
          addEvent(s,'stage.progress',`Squash synchronization complete: ${syncResult.uploadedCount} new test case(s) added; ${syncResult.keptCount} existing test case(s) reused.`,n);
          const {executeSquashTestCaseExecution}=require(utilPath);
          const executionOutput:any=s.stages.execution.output||{};
          const suiteEvidencePath=path.join(ROOT,'playwright-report',`execution-${s.id}`,'index.html');
          const synchronizedIds=Array.isArray(syncResult.resolvedTestCases)
            ? syncResult.resolvedTestCases.map((tc:any)=>Number(tc?.id)).filter((id:number)=>Number.isFinite(id)&&id>0)
            : [];
          const result=await executeSquashTestCaseExecution({
            baseUrl:base, token, testCaseFolderId:s.testCaseFolderId,
            executionFolderName:s.executionFolderName, campaignName:s.campaignName,
            iterationName:s.iterationName, testSuiteName:s.testSuiteName, suiteEvidencePath,
            testCaseIds:synchronizedIds, testCaseReferences:syncResult.selectedIds,
            executionResults:Array.isArray(executionOutput.executionCaseResults)?executionOutput.executionCaseResults:[]
          });
          const rel=`test-scenarios/squash/execution_${s.issueId}.json`;
          const dir=path.join(ROOT,'test-scenarios','squash'); fs.mkdirSync(dir,{recursive:true});
          fs.writeFileSync(path.join(ROOT,rel),JSON.stringify(result,null,2),'utf8');
          const artifact=artifactDetails(rel);
          stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{result,artifact,squashSync:syncResult,createdExecutions:result.executions.length},message:`Synchronized ${syncResult.selectedIds.length} approved test case(s) into Squash, then created ${result.executions.length} execution(s) in iteration ${result.iteration?.id||''}.`});
          addEvent(s,'artifact.created',`Squash execution report: ${artifact!.localPath}`,n);
          addEvent(s,'stage.progress',`Created ${result.executions.length} Squash execution(s).`,n);
        }
        else if(n==='scriptGeneration'){
          output=await runConfiguredAgent(n,s,{APP_URL:s.appUrl||''});
          if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s);
          const generatedArtifacts=validateScriptGenerationArtifacts(s);
          const testData=artifactDetails(findArtifact(s,[`test-data/issue-${s.issueId}.json`]));
          const spec=artifactDetails(findArtifact(s,[`tests/issue-${s.issueId}.spec.ts`]));
          const pages=fs.existsSync(path.join(ROOT,'pages'))?fs.readdirSync(path.join(ROOT,'pages')).filter(x=>x.endsWith('.page.ts')).map(x=>artifactDetails(path.join('pages',x))):[];
          const executionList=executionCases(s);
          stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{raw:output,artifacts:{testData,spec,pages},generatedArtifacts,testCases:parseGeneratedTests(s),executionCases:executionList},message:`Generated and validated ${generatedArtifacts.length} artifact file(s).`});
          generatedArtifacts.forEach((artifact:any)=>addEvent(s,'artifact.created',`Generated artifact: ${artifact.repositoryPath} (${artifact.size} bytes)`,n));
          addEvent(s,'stage.progress',`Execution selector prepared with ${executionList.length} approved test case(s).`,n);
          unlockAfter(s,n);
        }
        else if(n==='execution'){
          const catalog=executionCatalogForSession(s);
          const selectedKeys=Array.isArray(b.testCases)?[...new Set<string>(b.testCases.filter((x:any)=>typeof x==='string'&&x.trim()).map((x:string)=>x.trim()))]:[];
          if(!selectedKeys.length) throw new Error('Select at least one test case before starting execution.');
          const selected=catalog.filter((tc:any)=>selectedKeys.includes(tc.key));
          const unknown=selectedKeys.filter((key:string)=>!catalog.some((tc:any)=>tc.key===key));
          if(unknown.length) throw new Error(`Selected test case(s) are not present in the project execution catalog: ${unknown.join(', ')}`);
          const specSet=[...new Set(selected.map((x:any)=>x.spec))] as string[];
          if(!specSet.length) throw new Error('No executable Playwright spec was found for the selected test case(s).');
          const workerCount=Number(b.workers);
          if(!Number.isInteger(workerCount) || workerCount<1 || workerCount>128) throw new Error('Workers must be a whole number between 1 and 128.');
          const headless=b.headless!==false;
          const selectedIds=selected.map((x:any)=>x.key);
          const selectedTitles=selected.map((x:any)=>x.title);
          const previousResults:any[] = Array.isArray((s.stages.execution.output as any)?.executionCaseResults) ? (s.stages.execution.output as any).executionCaseResults : [];
          const previousRun=previousResults.length>0;
          const executionCaseStatuses=catalog.map((x:any)=>({key:x.key,id:x.id,title:x.title,spec:x.spec,status:selectedIds.includes(x.key)?'running':(previousRun?'not_run':'not_started')}));
          stage(s,n,{output:{...(s.stages[n].output as any||{}),catalog,selectedTestCases:selectedIds,selectedTestTitles:selectedTitles,executionCaseStatuses,workers:workerCount,headless}});
          addEvent(s,'stage.progress',`Running ${selected.length} selected project test case(s) in ${b.headless===false?'headed':'headless'} mode across ${specSet.length} spec file(s)${b.workers?` using ${b.workers} worker(s)`:''}...`,n);
          // Validate the exact files that Playwright is about to execute before
          // starting the browser. This prevents a stale/partial generated suite from
          // being mistaken for a valid execution and makes missing POM imports visible
          // in the Execution stage and Test Healer.
          const resolveSourceImport=(fromFile:string, specifier:string):string|undefined=>{
            if(!specifier.startsWith('.')) return undefined;
            const base=path.resolve(path.dirname(fromFile),specifier);
            const candidates=[base,...['.ts','.tsx','.js','.jsx','.mjs','.cjs','.json'].map(ext=>base+ext),...['index.ts','index.tsx','index.js','index.jsx','index.mjs','index.cjs','index.json'].map(name=>path.join(base,name))];
            return candidates.find(file=>fs.existsSync(file)&&fs.statSync(file).isFile());
          };
          const findMissingImports=(entryFiles:string[])=>{
            const missing:string[]=[]; const visited=new Set<string>(); const importRe=/(?:import\s+(?:[^'\"]+?\s+from\s+)?|export\s+(?:[^'\"]+?\s+from\s+)?|require\s*\(\s*|import\s*\(\s*)(['\"])([^'\"]+)\1/g;
            const walk=(file:string)=>{
              const abs=path.resolve(ROOT,file); if(visited.has(abs)||!fs.existsSync(abs)||!fs.statSync(abs).isFile()) return; visited.add(abs);
              let text=''; try{text=fs.readFileSync(abs,'utf8')}catch{return;}
              let m:any; while((m=importRe.exec(text))){ const specifier=String(m[2]||''); if(!specifier.startsWith('.')) continue; const resolved=resolveSourceImport(abs,specifier); if(!resolved){ missing.push(`${path.relative(ROOT,abs).replace(/\\/g,'/')} -> ${specifier}`); } else { walk(resolved); } }
            };
            entryFiles.forEach(walk);
            return [...new Set(missing)];
          };
          const missingImports=findMissingImports(specSet);
          addEvent(s,'stage.progress',`Execution workspace: ${path.resolve(ROOT)}`,n);
          addEvent(s,'stage.progress',`Playwright spec file(s): ${specSet.map(x=>path.resolve(ROOT,x)).join(', ')}`,n);
          if(missingImports.length){
            const detail=missingImports.join('; ');
            addEvent(s,'backend.error',`Execution preflight found missing local imports: ${detail}`,n);
            const impacted=selected.map((x:any)=>({id:x.id,title:x.title,key:x.key,spec:x.spec,error:`Missing generated/local dependency: ${detail}`}));
            const impactedStatuses=catalog.map((x:any)=>({key:x.key,id:x.id,title:x.title,spec:x.spec,status:selectedIds.includes(x.key)?'failed':(previousRun?'not_run':'not_started')}));
            stage(s,n,{status:'failed',completedAt:new Date().toISOString(),output:{catalog,selectedTestCases:selectedIds,selectedTestTitles:selectedTitles,specs:specSet,preflight:{missingImports},executionCaseResults:impacted,executionCaseStatuses:impactedStatuses,failedTestCases:impacted},message:`Execution failed before Playwright could run: ${missingImports.length} local dependency import(s) are missing.`,error:`Missing local dependency: ${detail}`});
            stage(s,'healer',{status:'ready',output:{failedTestCases:impacted},message:`${impacted.length} selected test case(s) are impacted by missing local dependencies.`});
            stage(s,'defect',{status:'ready',output:{failedTestCases:impacted},message:'Test Execution failed. GitLab Defect Reporting is available to raise a defect under the current requirement.'});
            addEvent(s,'stage.unlocked','Defect Reporting unlocked because Test Execution failed during preflight.','defect');
            stage(s,'gitlabCommit',{status:'ready'});
            addEvent(s,'stage.progress',`Test Healer queue prepared with ${impacted.length} impacted test case(s).`,'healer');
            return json(res,200,s);
          }
          let output=''; let executionExitCode=0; let executionSignal=''; let executionProcessError=''; await new Promise<void>((resolve)=>{
            const env=sanitizedEnv();
            fs.mkdirSync(path.join(ROOT,'test-results'),{recursive:true});
            fs.mkdirSync(path.join(ROOT,'playwright-report',`execution-${s.id}`),{recursive:true});
            env.PW_JSON_REPORT_FILE=path.join(ROOT,'test-results',`execution-${s.id}.json`);
            env.PW_HTML_REPORT_DIR=path.join(ROOT,'playwright-report',`execution-${s.id}`);
            env.PLAYWRIGHT_HTML_OPEN='never';
            // Do not pass --reporter=json here. CLI --reporter overrides the reporters
            // configured in playwright.config.ts and was the reason the HTML report was
            // silently not produced. The config writes both HTML and JSON reporters.
            // Never route the Playwright test command through cmd.exe/npx on Windows.
            const playwrightCli=require.resolve('@playwright/test/cli');
            const playwrightArgs=['test',...specSet];
            if(Number.isFinite(workerCount) && workerCount>0) playwrightArgs.push('--workers',String(workerCount));
            if(!headless) playwrightArgs.push('--headed');
            if(selected.length){
              const patterns=selected.map((x:any)=>String(x.id).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'));
              playwrightArgs.push('--grep',`(?:${[...new Set(patterns)].join('|')})`);
            }
            addEvent(s,'backend.stdout',`Playwright argv: ${JSON.stringify([process.execPath,playwrightCli,...playwrightArgs])}`,n);
            const child=spawn(process.execPath,[playwrightCli,...playwrightArgs],{cwd:ROOT,env,stdio:'pipe',windowsHide:process.platform==='win32'});
            const executionRunKey=`${s.id}:${n}`;
            activeRuns.set(executionRunKey,{child,stopRequested:false});
            let stdout=''; let stderr='';
            child.stdout.on('data',data=>{const text=String(data); stdout+=text; text.split(/\r?\n/).filter(Boolean).forEach((line:string)=>addEvent(s,'backend.stdout',line,n));});
            child.stderr.on('data',data=>{const text=String(data); stderr+=text; text.split(/\r?\n/).filter(Boolean).forEach((line:string)=>addEvent(s,'backend.stderr',line,n));});
            child.on('error',(err:any)=>{const run=activeRuns.get(executionRunKey); const stopped=!!run?.stopRequested; activeRuns.delete(executionRunKey); if(!stopped){executionProcessError=err.message; addEvent(s,'backend.error',`Playwright process error: ${err.message}`,n);} output=`${stdout}\n${stderr}`.trim(); resolve();});
            child.on('close',(code,signal)=>{const run=activeRuns.get(executionRunKey); const stopped=!!run?.stopRequested; activeRuns.delete(executionRunKey); executionExitCode=typeof code==='number'?code:1; executionSignal=signal||''; output=`${stdout}\n${stderr}`.trim(); if(stopped){executionExitCode=1; executionSignal='SIGSTOP'; addEvent(s,'stage.stopped','Playwright execution stopped by user.',n);} else if(executionExitCode!==0) addEvent(s,'backend.error',`Playwright process exited with code ${executionExitCode}${executionSignal?` (${executionSignal})`:''}.`,n); resolve();});
          });
          if(s.stages.execution.status==='ready' && s.stages.execution.message==='Stopped by user.') { addEvent(s,'stage.progress','Execution stopped before results were collected.',n); return json(res,200,s); }
          if(executionProcessError) throw new Error(`Playwright process could not be started: ${executionProcessError}`);
          let parsed:any={raw:output};
          const resultFile=path.join(ROOT,'test-results',`execution-${s.id}.json`);
          if(fs.existsSync(resultFile)){try{parsed=JSON.parse(fs.readFileSync(resultFile,'utf8'));}catch{}}
          const resultArtifact=artifactDetails(fs.existsSync(resultFile)?path.join('test-results',`execution-${s.id}.json`):undefined);
          const htmlReportPath=path.join(ROOT,'playwright-report',`execution-${s.id}`,'index.html');
          const htmlReportExists=fs.existsSync(htmlReportPath) && fs.statSync(htmlReportPath).isFile();
          if(!htmlReportExists){
            addEvent(s,'backend.error',`Playwright HTML report was not generated at ${htmlReportPath}.`,n);
            executionExitCode=executionExitCode===0 ? 1 : executionExitCode;
          } else {
            addEvent(s,'artifact.created',`Playwright HTML report: ${htmlReportPath}`,n);
          }
          const reportText=JSON.stringify(parsed);
          const reportHasFailedTests=/\"status\":\"failed\"/.test(reportText);
          const reportHasErrors=Array.isArray(parsed?.errors) && parsed.errors.length>0;
          const failed=reportHasFailedTests || reportHasErrors || executionExitCode!==0;
          if(executionExitCode!==0) addEvent(s,'backend.error',`Playwright execution failed with exit code ${executionExitCode}${executionSignal?` (${executionSignal})`:''}.`,n);

          // Build the healer queue from actual Playwright results. A module/import
          // failure can happen before Playwright collects any tests, leaving suites
          // empty. Those selected cases are still impacted and must be visible to
          // Test Healer.
          const reportCaseStatuses=new Map<string,any>();
          const collectReportCases=(suites:any[], inheritedIssueId='')=>{
            for(const suite of suites||[]) {
              const suiteFile=String(suite?.file||suite?.titlePath?.join?.('/')||'');
              const suiteIssue=(suiteFile.match(/(?:^|[\\/])issue-(\d+)\.spec\./i)?.[1] || inheritedIssueId || '');
              for(const sp of suite?.specs||[]) {
                const idMatch=String(sp?.title||'').match(/\b(TC-\d+)\b/i);
                const id=idMatch?.[1]?.toUpperCase();
                const tests=Array.isArray(sp?.tests)?sp.tests:[];
                const failedTest=tests.find((t:any)=>String(t?.status||'').toLowerCase()==='unexpected' || String(t?.results?.at?.(-1)?.status||'').toLowerCase()==='failed');
                const allErrors:any[]=[];
                for(const test of tests){
                  for(const result of (Array.isArray(test?.results)?test.results:[])){
                    const resultErrors=Array.isArray(result?.errors)?result.errors:[];
                    for(const err of resultErrors){
                      if(err?.message || err?.stack) allErrors.push({message:String(err?.message||''),stack:String(err?.stack||''),location:err?.location});
                    }
                    if(result?.error?.message || result?.error?.stack) allErrors.push({message:String(result.error.message||''),stack:String(result.error.stack||''),location:result.error.location});
                  }
                }
                const detailParts=allErrors.map((e:any)=>[e.message,e.stack && e.stack!==e.message?e.stack:'',e.location?.file?`Location: ${e.location.file}:${e.location.line||''}:${e.location.column||''}`:''].filter(Boolean).join('\n')).filter(Boolean);
                const errorDetail=detailParts.join('\n\n');
                if(id) {
                  const result={failed:!!failedTest || sp?.ok===false,title:String(sp?.title||id),error:errorDetail,errorDetails:allErrors};
                  reportCaseStatuses.set(id,result);
                  if(suiteIssue) reportCaseStatuses.set(`${suiteIssue}::${id}`,result);
                }
                if(Array.isArray(sp?.suites)) collectReportCases(sp.suites,suiteIssue);
              }
              if(Array.isArray(suite?.suites)) collectReportCases(suite.suites,suiteIssue);
            }
          };
          collectReportCases(parsed?.suites||[]);
          const primaryIssue=selected[0]?.issueId || s.issueId;
          const executionCaseResults=selected.map((x:any)=>{
            const result=reportCaseStatuses.get(`${x.issueId}::${String(x.id).toUpperCase()}`) || reportCaseStatuses.get(String(x.id).toUpperCase());
            return {id:x.id,title:x.title,key:x.key,spec:x.spec,status:result?.failed?'failed':'passed',error:result?.error||'',errorDetails:result?.errorDetails||[]};
          });
          let failedTestCases=executionCaseResults.filter((x:any)=>x.status==='failed');
          // If execution failed before per-test results existed, every selected
          // case is an impacted case for this run (for example missing POM import).
          if(failed && !failedTestCases.length) {
            const errorMessage=reportHasErrors ? String(parsed?.errors?.[0]?.message||'Playwright failed before test execution.') : 'Playwright execution failed before a per-test result was produced.';
            failedTestCases=selected.map((x:any)=>({id:x.id,title:x.title,key:x.key,spec:x.spec,status:'failed',error:errorMessage,errorDetails:[{message:errorMessage,stack:'',location:undefined}] }));
            executionCaseResults.splice(0,executionCaseResults.length,...failedTestCases);
            addEvent(s,'stage.progress',`Test Healer queue prepared with ${failedTestCases.length} impacted test case(s).`,'healer');
          }
          const completedCaseStatuses=catalog.map((x:any)=>{
            const result=executionCaseResults.find((r:any)=>r.key===x.key);
            return {key:x.key,id:x.id,title:x.title,spec:x.spec,status:result?(result.status==='failed'?'failed':'completed'):(selectedIds.includes(x.key)?'failed':((previousRun||executionCaseResults.length)?'not_run':'not_started'))};
          });
          stage(s,n,{status:failed?'failed':'completed',completedAt:new Date().toISOString(),output:{catalog,selectedTestCases:selectedIds,selectedTestTitles:selectedTitles,specs:specSet,workers:workerCount,headless,result:resultArtifact,report:parsed,reportPath:htmlReportPath,reportUrl:htmlReportExists?`/api/session/${s.id}/report/execution`:undefined,resultUrl:`/api/session/${s.id}/report/execution`,executionCaseResults,executionCaseStatuses:completedCaseStatuses,failedTestCases},message:`Test execution ${failed?'failed':'completed'}${selected.length?` for ${selected.length} selected project test case(s)`:''}.`,error:failed?(reportHasErrors?String(parsed?.errors?.[0]?.message||'Playwright execution failed.'):htmlReportExists?'Test failures detected; Test Healer is ready with the impacted test cases.':'Playwright HTML report was not generated.'):undefined});
          if(resultArtifact)addEvent(s,'artifact.created',`Test results: ${resultArtifact.localPath}`,n);
          if(failed) {
            stage(s,'healer',{status:'ready',output:{failedTestCases},message:`${failedTestCases.length||selected.length} impacted test case(s) are ready for healing.`});
            stage(s,'defect',{status:'ready',output:{failedTestCases},message:'Test Execution failed. GitLab Defect Reporting is available to raise a defect under the current requirement.'});
            addEvent(s,'stage.unlocked','Defect Reporting unlocked because Test Execution failed.','defect');
          } else {
            stage(s,'healer',{status:'not_required',output:{failedTestCases:[]},completedAt:new Date().toISOString(),message:'All selected test cases passed. Test Healer is not required for this execution.'});
            stage(s,'defect',{status:'not_required',output:{failedTestCases:[]},completedAt:new Date().toISOString(),message:'All selected test cases passed. Defect Reporting is not required for this execution.'});
            addEvent(s,'stage.locked','Test Healer and GitLab Defect Reporting are not required because Test Execution passed.','healer');
          }
          stage(s,'gitlabCommit',{status:'ready'});
          // Squash Test Case Execution is independent of the outcome: pass, fail,
          // or a completed run with mixed results all make it available.
          unlockAfter(s,n);
        }
        else if(n==='defect'){
          const healerOut:any=s.stages.healer.output||{};
          const executionOut:any=s.stages.execution.output||{};
          const failedTestCases=Array.isArray(healerOut.failedTestCases)&&healerOut.failedTestCases.length
            ? healerOut.failedTestCases
            : (Array.isArray(executionOut.failedTestCases)?executionOut.failedTestCases:[]);
          const executionReportErrors=Array.isArray((s.stages.execution.output as any)?.report?.errors)?(s.stages.execution.output as any).report.errors.map((e:any)=>e?.message||e?.stack||String(e)).join('\n\n'):'';
          const healerError=s.stages.healer.status==='failed' ? String(s.stages.healer.error||s.stages.healer.message||'Test Healer failed.') : '';
          const executionError=[String(s.stages.execution.error||s.stages.execution.message||'Test Execution failed.'),executionReportErrors].filter(Boolean).join('\n\n');
          const failureReason=healerError || executionError;
          const failureContext=compactFailureContext(failedTestCases);
          const healerProposal=String(healerOut.proposalMarkdown||healerOut.proposal||'').slice(0,8000);
          const defectTitleHint=defectTitleFromFailure(s,failedTestCases,executionReportErrors,failureReason);
          output=await runConfiguredAgent(n,s,{FAILED_TEST_CASES:failureContext,HEALER_FAILURE_REASON:failureReason.slice(0,4000),HEALER_PROPOSAL:healerProposal,DEFECT_TITLE_HINT:defectTitleHint,ISSUE_TITLE:s.issueTitle||''});
          const rawOutput=String(output||'');
          const defectUrl=(rawOutput.match(/https?:\/\/[^\s)]+/)||[])[0]||'';
          const marker=/DEFECT_CREATED\s*[:\-]?/i.test(rawOutput);
          const createdTaskMatch=rawOutput.match(/Created child Task[\s\S]*?\(IID\s*\*?\*?(\d+)\*?\*?\)[\s\S]*?under parent work item\s*\*{0,2}#?(\d+)/i);
          const createdTaskIid=createdTaskMatch?.[1]||'';
          const parentIid=createdTaskMatch?.[2]||'';
          // Accept the actual MCP confirmation even when Copilot omitted the requested
          // DEFECT_CREATED marker. This prevents a successfully-created GitLab Task
          // from being reported as a failed stage.
          const creationConfirmed=marker || (!!createdTaskIid && (!parentIid || parentIid===String(s.issueId)));
          let normalizedDefectUrl=defectUrl;
          if(!normalizedDefectUrl && createdTaskIid){
            try {
              const u=new URL(s.issueUrl);
              const match=u.pathname.match(/^(.*)\/-\/(?:issues|work_items)\/\d+$/);
              if(match) normalizedDefectUrl=`${u.origin}${match[1]}/-/work_items/${createdTaskIid}`;
            } catch {}
          }
          if(!creationConfirmed){
            stage(s,n,{status:'failed',completedAt:new Date().toISOString(),output:{raw:rawOutput,failedTestCases},message:'Defect agent completed without confirming a GitLab child task was created.',error:'No GitLab child-task creation confirmation was returned by the defect agent.'});
            throw new Error('Defect agent did not confirm creation of the GitLab defect task.');
          }
          stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{raw:rawOutput,failedTestCases,defectUrl:normalizedDefectUrl,defectIid:createdTaskIid||undefined},message:normalizedDefectUrl?`GitLab defect task created: ${normalizedDefectUrl}`:'GitLab defect task created under the requirement.'});
          addEvent(s,'stage.completed',normalizedDefectUrl?`GitLab defect child task created: ${normalizedDefectUrl}`:'GitLab defect child task created under the requirement.','defect');
          return json(res,200,s);
        }
        else if(n==='healer'){
          const failedTestCases=Array.isArray((s.stages.healer.output as any)?.failedTestCases)?(s.stages.healer.output as any).failedTestCases:[];
          // Keep Test Healer runnable after every terminal execution result. If the
          // execution passed and there is nothing to heal, complete this run locally
          // instead of disabling the stage or invoking the agent with an empty queue.
          if(!failedTestCases.length){
            stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{failedTestCases,proposalMarkdown:''},message:'No failed or impacted test cases are available. No healing changes were required.'});
            addEvent(s,'stage.completed','Test Healer checked the latest execution and found no failed or impacted test cases.','healer');
            return json(res,200,s);
          }
          const failedContext=failedTestCases.map((x:any)=>`${x.id} | ${x.title} | ${x.spec}${x.error?` | ${x.error}`:''}`).join('\n');
          output=await runConfiguredAgent(n,s,{FAILED_TEST_CASES:failedContext});
          if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s);
          const proposalMarkdown=extractHealerProposal(output);
          if(!proposalMarkdown){
            stage(s,n,{status:'failed',output:{raw:output,failedTestCases},message:'Healer agent completed but did not return a reviewable healing proposal.',error:'No healing proposal was returned by the healer agent.'});
            throw new Error('Healer agent completed but did not return a reviewable healing proposal.');
          }
          const proposalHtml=markdownToHtml(proposalMarkdown);
          stage(s,n,{status:'waiting_for_approval',output:{raw:output,failedTestCases,proposal:proposalMarkdown,proposalMarkdown,proposalHtml},message:'Healing proposal generated. Review the proposal below before approving the repair.'});
          addEvent(s,'stage.progress','Healing proposal captured and displayed for approval review.','healer');
        }
        else if(n==='gitlabCommit'){ const result=execFileSync(gitExecutable(),['status','--short'],{cwd:ROOT,encoding:'utf8'}); const repositoryPath=path.resolve(ROOT); addEvent(s,'stage.progress',`Preparing commit from ${repositoryPath}...`,n); stage(s,n,{status:'waiting_for_approval',output:{repositoryPath,gitStatus:result,branch:`test/issue-${s.issueId}-e2e`,commitMessage:`test(e2e): add automated E2E test suite and POM for issue #${s.issueId}`},message:`Review changes in ${repositoryPath} before approval.`}); }
        addEvent(s,'stage.waiting_or_completed',`Finished ${n}`,n); return json(res,200,s);
      } catch(e:any){
        if(String(e?.message||'').includes('stopped by user') || (s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.')) {
          stage(s,n,{status:'ready',message:'Stopped by user.',error:undefined,completedAt:new Date().toISOString()});
          addEvent(s,'stage.stopped','Stage stopped by user; no failure recorded.',n);
          return json(res,200,s);
        }
        stage(s,n,{status:'failed',error:e.message,message:`Failed: ${e.message}`,completedAt:new Date().toISOString()});
        if(n==='healer'){
          stage(s,'defect',{status:'ready',output:{...(s.stages.defect.output||{})},completedAt:undefined,error:undefined,message:'Test Healer failed. You can retry Test Healer or raise a defect as a child task in the current GitLab requirement.'});
          addEvent(s,'stage.unlocked','Defect Reporting unlocked because Test Healer failed.','defect');
        }
        if(n==='execution'){
          stage(s,'defect',{status:'ready',output:{...(s.stages.execution.output||{})},completedAt:undefined,error:undefined,message:'Test Execution failed. GitLab Defect Reporting is available to raise a defect under the current requirement.'});
          addEvent(s,'stage.unlocked','Defect Reporting unlocked because Test Execution failed.','defect');
        }
        addEvent(s,'stage.failed',e.message,n); return json(res,500,{error:e.message,session:s});
      }
    }
    const revision=p.match(/^\/api\/session\/([^/]+)\/stage\/businessReview\/revise$/); if(req.method==='POST'&&revision){
      const s=sessions.get(revision[1]); if(!s)return json(res,404,{error:'Session not found'});
      if(s.stages.businessReview.status!=='waiting_for_approval') return json(res,400,{error:`Business review is ${s.stages.businessReview.status}`});
      const body=await readBody(req); const feedback=String(body.feedback||'').trim();
      if(!feedback) return json(res,400,{error:'Provide specific feedback describing what should be revised.'});
      const key=`${s.id}:businessReview`; if(approvalLocks.has(key)) return json(res,409,{error:'Business review revision is already being processed.'});
      approvalLocks.add(key);
      stage(s,'businessReview',{status:'running',startedAt:new Date().toISOString(),message:'Re-running Business Requirements Reviewer with your feedback...',output:{...(s.stages.businessReview.output as any||{}),feedback}});
      addEvent(s,'review.feedback',`User requested a business requirements revision: ${feedback}`,'businessReview');
      try { await executeBusinessReview(s,feedback); return json(res,200,s); }
      catch(e:any) { stage(s,'businessReview',{status:'failed',error:e.message,message:`Business review revision failed: ${e.message}`}); return json(res,500,{error:e.message,session:s}); }
      finally { approvalLocks.delete(key); }
    }
    const approval=p.match(/^\/api\/session\/([^/]+)\/stage\/([^/]+)\/(approve|reject)$/); if(req.method==='POST'&&approval){const s=sessions.get(approval[1]); if(!s)return json(res,404,{error:'Session not found'}); const n=approval[2] as StageName; const action=approval[3]; if(!['businessReview','strategy','healer','gitlabCommit'].includes(n))return json(res,400,{error:'Stage has no approval endpoint'}); if(s.stages[n].status!=='waiting_for_approval')return json(res,400,{error:`Stage is ${s.stages[n].status}`}); const body=await readBody(req); const includedIds:string[]=Array.isArray(body.includedTestCases)?[...new Set<string>(body.includedTestCases.filter((x:any)=>typeof x==='string'&&x.trim()).map((x:string)=>x.trim()))]:[]; const included=includedIds.join(', ');
      if(action==='reject'){stage(s,n,{status:'ready',output:{...((s.stages[n].output as any)||{}),rerunRequired:true},completedAt:undefined,message:'Rejected; ready to run again. A fresh proposal is required before approval.'}); addEvent(s,'approval.rejected',`Rejected ${n}`,n); return json(res,200,s);}
      const approvalKey=`${s.id}:${n}`; if(approvalLocks.has(approvalKey)) return json(res,409,{error:'Approval is already being processed.'}); approvalLocks.add(approvalKey);
      try { if(n==='businessReview') {
          const prior:any=s.stages.businessReview.output||{};
          const review:any=prior.review||{};
          const approvedAt=new Date().toISOString();
          const reviewerDecision=String(review.decision||'NEEDS_REVISION');
          const completenessScore=Number(review.completenessScore||0);
          const reviewerRecommendationOverridden=reviewerDecision!=='READY_FOR_SCENARIOS';
          const approvalStatus=reviewerRecommendationOverridden?'approved_with_reviewer_override':'approved';
          const message=reviewerRecommendationOverridden
            ? `Approved by user at ${completenessScore}% completeness. This explicitly overrides the reviewer's ${reviewerDecision} recommendation; Test Scenarios is now unlocked.`
            : `Approved by user at ${completenessScore}% completeness. Test Scenarios is now unlocked.`;
          stage(s,n,{status:'completed',completedAt:approvedAt,output:{...prior,rerunRequired:false,approvalStatus,approvedAt,reviewerDecision,completenessScore,reviewerRecommendationOverridden},message});
          addEvent(s,'approval.approved',message,n);
          if(reviewerRecommendationOverridden) addEvent(s,'approval.override',`User approved Business Requirements Review despite reviewer decision ${reviewerDecision} and completeness ${completenessScore}%. The score was not changed.`,n);
          unlockAfter(s,n);
        }
        else if(n==='strategy'){
          const proposalRel=String((s.stages.strategy.output as any)?.proposalArtifact?.relativePath || strategyProposalRel(s) || '');
          if(!proposalRel || !fs.existsSync(path.join(ROOT,proposalRel))) throw new Error('Strategy proposal is missing. Re-run Test Strategy before approving.');
          const proposal=parseStrategy(s,proposalRel);
          const available=new Set((proposal?.strategies||[]).map((x:any)=>String(x.id).toUpperCase()));
          const invalid=includedIds.filter((id:string)=>!available.has(id.toUpperCase()));
          if(invalid.length) throw new Error(`Selected test case(s) are not present in the strategy proposal: ${invalid.join(', ')}`);
          addEvent(s,'stage.progress',`Applying UI-approved selection (${includedIds.length} case(s)); strategy agent will NOT be rerun...`,n);
          const approved=rewriteApprovedStrategy(s,includedIds,proposalRel);
          validateApprovedStrategy(s,approved.relativePath,includedIds);
          // Remove the proposal after the final artifact passes validation so downstream
          // agents cannot accidentally consume the pre-approval recommendation.
          // If the user edited the already-approved strategy in place, proposalRel
          // is the final strategy itself. Never delete that file after approval.
          if(proposalRel !== finalStrategyRel(s)) {
            try { fs.unlinkSync(path.join(ROOT,proposalRel)); } catch {}
          }
          const parsed=parseStrategy(s,approved.relativePath);
          const artifact=artifactDetails(approved.relativePath);
          stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{proposal:parsed,artifact,includedTestCases:includedIds,rerunRequired:false},message:`Approved strategy contains exactly ${includedIds.length} selected test case(s): ${artifact!.localPath}`});
          addEvent(s,'strategy.selection',`UI-approved test cases: ${includedIds.join(', ')}`,n);
          addEvent(s,'artifact.updated',`Final strategy written from UI selection only: ${artifact!.localPath}`,n);
          unlockAfter(s,n);
        }
        else if(n==='healer'){
          const prior:any=s.stages.healer.output||{};
          const approvedAt=new Date().toISOString();
          const proposalForApproval=String(prior.proposalMarkdown||prior.proposal||'').trim();
          // Approval is a user decision; keep that state visible immediately while the
          // healer agent applies the approved proposal in the background. The exact proposal
          // is passed to the agent so approval does not trigger a second diagnosis/search loop.
          stage(s,n,{status:'running',startedAt:approvedAt,output:{...prior,approvalStatus:'approved',proposalStatus:'approved',approvedAt},message:'Approved by user. Test Healer is applying the approved repair.'});
          addEvent(s,'approval.approved','Healing proposal approved by user. Test Healer is applying the approved repair.','healer');
          void (async()=>{
            try {
              const out=await runConfiguredAgent('healer',s,{APPROVAL:'approved',HEALING_PROPOSAL:JSON.stringify(proposalForApproval)});
              stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{...prior,raw:out,approvalStatus:'approved',proposalStatus:'approved',approvedAt},message:'Approved by user. Healing changes were applied. Re-run Test Execution to verify.'});
              // The user chose healing instead of raising a defect. Treat the successful
              // repair as the end of the current failure path; a defect is only offered
              // again if the subsequent execution fails or the healing application fails.
              stage(s,'defect',{status:'not_required',output:{},completedAt:new Date().toISOString(),error:undefined,message:'Test Healer completed successfully. Defect Reporting is not required unless a subsequent Test Execution fails.'});
              stage(s,'execution',{status:'ready',message:'Ready to run again after healer approval.'});
              addEvent(s,'stage.completed','Test Healer completed the approved repair.','healer');
              unlockAfter(s,'healer');
            } catch(e:any) {
              stage(s,n,{status:'failed',completedAt:new Date().toISOString(),output:{...prior,approvalStatus:'approved',proposalStatus:'approved',approvedAt},message:`Approval was accepted, but applying the healing repair failed: ${e?.message||'Unknown error'}`,error:e?.message||'Healing repair failed.'});
              stage(s,'defect',{status:'ready',output:{},completedAt:undefined,error:undefined,message:'Test Healer failed while applying the approved repair. You can retry Test Healer or raise a defect as a child task in the current GitLab requirement.'});
              addEvent(s,'stage.unlocked','Defect Reporting unlocked because the approved Test Healer repair failed.','defect');
              addEvent(s,'stage.failed',`Approved healing repair failed: ${e?.message||'Unknown error'}`,'healer');
            } finally { approvalLocks.delete(approvalKey); }
          })();
          return json(res,202,s);
        }
        else { const branch=`test/issue-${s.issueId}-e2e`; const commit=`test(e2e): add automated E2E test suite and POM for issue #${s.issueId}`; addEvent(s,'stage.progress',`Creating branch ${branch}...`,n); execFileSync(gitExecutable(),['checkout','-B',branch],{cwd:ROOT,stdio:'pipe'}); addEvent(s,'stage.progress','Staging generated artifacts...',n); execFileSync(gitExecutable(),['add','test-scenarios','test-data','pages','tests','.github/agents'],{cwd:ROOT,stdio:'pipe'}); addEvent(s,'stage.progress','Creating commit and pushing to origin...',n); execFileSync(gitExecutable(),['commit','-m',commit],{cwd:ROOT,stdio:'pipe'}); execFileSync(gitExecutable(),['push','-u','origin',branch],{cwd:ROOT,stdio:'pipe'}); stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{repositoryPath:path.resolve(ROOT),branch,commit},message:`Committed and pushed from ${path.resolve(ROOT)}.`}); }
        addEvent(s,'approval.approved',`Approved ${n}`,n); return json(res,200,s);
      }catch(e:any){stage(s,n,{status:'failed',error:e.message}); addEvent(s,'stage.failed',e.message,n); return json(res,500,{error:e.message,session:s});}
      finally { approvalLocks.delete(approvalKey); }
    }
    if(req.method==='GET'){let file=p==='/'?'/index.html':p; const fp=path.join(UI_ROOT,path.normalize(file)); if(!fp.startsWith(UI_ROOT))return json(res,403,{error:'Forbidden'}); if(fs.existsSync(fp)&&fs.statSync(fp).isFile()){const ext=path.extname(fp); const ct=ext==='.html'?'text/html':ext==='.js'?'text/javascript':ext==='.css'?'text/css':'application/octet-stream';res.writeHead(200,{'Content-Type':ct});return res.end(fs.readFileSync(fp));}}
    json(res,404,{error:'Not found'});
  }catch(e:any){json(res,500,{error:e.message||'Internal server error'});}
}

ensureState();
const HOST=process.env.UI_HOST || '127.0.0.1';
const server=http.createServer(handle); server.listen(PORT,HOST,()=>console.log(`Automation Control Center v16: http://${HOST}:${PORT}`));
process.on('SIGINT',()=>{stopMcp('gitlab');stopMcp('playwright');server.close(()=>process.exit(0));});
