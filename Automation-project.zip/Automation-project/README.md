# Automation Project — AI-Powered E2E Test Automation Framework

An agent-driven end-to-end (E2E) test automation framework that turns a GitLab requirement into reviewable test scenarios, an approved automation strategy, Playwright test assets, execution results, healing proposals, Squash TM records, defects, and controlled GitLab commits.

The project is designed around **human-controlled workflow gates**: AI agents can perform analysis and implementation, but important transitions such as business-review approval, strategy approval, healing approval, Squash upload/execution, and GitLab commit are explicitly controlled by the Automation Control Center.

> **Current architecture:** TypeScript + Node.js backend, Playwright for browser automation, GitHub Copilot CLI for LLM-powered agents, GitLab MCP/API integration, Playwright MCP, Squash TM integration, and a local web-based Automation Control Center.

---

## 1. What this framework does

The framework covers the complete test-automation lifecycle:

1. **Authoritative requirement** — retrieves a GitLab issue and treats its title/description as the source of truth.
2. **Business review** — an AI reviewer checks whether the requirement is complete, unambiguous, and testable.
3. **Test scenarios** — generates E2E test scenarios from the approved requirement/review.
4. **Test strategy** — decides what should be automated and what should be offloaded/non-E2E.
5. **Script generation** — uses Playwright MCP/live application inspection to generate Page Objects, test data, and executable Playwright specs.
6. **Test execution** — runs the selected Playwright tests and creates machine-readable/HTML results.
7. **Healing** — analyzes failures and proposes a focused repair; approved repairs are applied and verified by the backend.
8. **Squash TM** — optionally uploads approved test cases and creates/executes Squash test plans.
9. **Defect reporting** — creates a GitLab defect/task under the original requirement when an execution/healing failure requires a defect.
10. **GitLab commit** — optionally commits generated/updated automation assets to a feature branch.

The UI supports individual stages as well as controlled **Run All** orchestration. User decisions are gates; the next stage must not silently start before the required decision is made.

---

## 2. Technology stack

| Technology | Purpose |
|---|---|
| **Node.js** | Runtime for the Control Center backend, agent runner, utilities, and integration code |
| **TypeScript** | Main implementation language and compile-time type safety |
| **GitHub Copilot CLI** | Executes the Markdown-defined AI agents and selects the configured Copilot model |
| **GitHub Copilot agent definitions (`.github/agents/*.agent.md`)** | Source of truth for agent instructions, inputs, outputs, and workflow contracts |
| **Model Context Protocol (MCP)** | Standard bridge between agents and external tools/services |
| **GitLab MCP** | GitLab issue/work-item/branch/commit interaction used by agent stages |
| **GitLab REST API** | Backend fallback/direct integration where appropriate |
| **Playwright** | Browser E2E automation, test execution, reporting, and verification |
| **Playwright MCP** | Live browser/application inspection used by script generation and bounded agent reconnaissance |
| **Squash TM** | Test management, test-case upload, execution planning, and execution tracking |
| **HTTP/HTTPS proxy support** | Corporate network/proxy compatibility for APIs, MCP processes, Copilot CLI, and browsers |
| **dotenv** | Loads the single project-level `.env` configuration |
| **undici** | HTTP client support for application-side GitLab/Squash requests and proxy-aware networking |
| **HTML/JSON Playwright reports** | Execution evidence consumed by the Control Center and Test Healer |

### UI/backend architecture

The project does not require a separate frontend framework or database for its local Control Center. The backend serves the web UI and owns the workflow/session state in memory. TypeScript source is compiled to `automation-ui/dist` and utility JavaScript is generated from `utils/*.ts`.

---

## 3. High-level architecture

```mermaid
flowchart TB
    U[User / QA Engineer] --> UI[Automation Control Center<br/>Local Web UI]
    UI --> S[Node.js + TypeScript<br/>Control Center Server]

    S --> AR[Agent Runner<br/>automation-ui/agent-runner.js]
    AR --> C[GitHub Copilot CLI]
    C --> A[Markdown Agent Definitions<br/>.github/agents/]

    S --> GM[GitLab MCP / GitLab API]
    C --> GM
    S --> PM[Playwright MCP]
    C --> PM
    S --> PW[Playwright Test Runner]
    S --> SQ[Squash TM API / Utilities]

    GM --> G[GitLab Requirement<br/>Issues / Work Items / Branches]
    PM --> APP[Target Application]
    PW --> APP
    SQ --> Q[Squash TM]

    S --> ART[Artifacts & Reports<br/>scenarios / strategy / scripts / reports]
    PW --> ART
    ART --> H[Test Healer]
    H --> S

    S --> D[Defect Reporter]
    D --> GM
    S --> GC[GitLab Committer]
    GC --> GM

    U -->|Approve / Reject / Revise / Stop| S
```

### Important architectural principle

**The Control Center is the workflow authority.** Agents perform bounded work; they do not decide on their own to advance the entire pipeline. The backend owns stage state, approvals, stop/resume behavior, artifact validation, and the final Playwright verification after approved healing.

---

## 4. End-to-end execution flow

```mermaid
flowchart TD
    START([Start]) --> MCP[Start GitLab MCP + Playwright MCP]
    MCP --> ISSUE[Enter GitLab Issue URL]
    ISSUE --> SESSION[Create Session]
    SESSION --> BR[Business Requirements Review]

    BR --> DEC{Business Review Decision}
    DEC -->|Needs revision| FB[User enters feedback]
    FB --> RBR[Re-review]
    RBR --> BR
    DEC -->|Approved / Ready for scenarios| SC[Create Test Scenarios]

    SC --> STR[Test Strategy]
    STR --> SDEC{Strategy Approval}
    SDEC -->|Edit / Reject| STR
    SDEC -->|Approved| CHOICE1{Continue?}

    CHOICE1 -->|Squash upload| SQ[Squash TM Upload]
    SQ --> CHOICE2{Execute Squash tests?}
    CHOICE2 -->|Yes| SQE[Squash Test Execution]
    CHOICE2 -->|No| SG[Script Generation]
    SQE --> SG
    CHOICE1 -->|Skip Squash| SG

    SG --> EX[Test Execution]
    EX --> RESULT{Execution result}

    RESULT -->|Passed| COMMIT{Commit to GitLab?}
    RESULT -->|Failed| HEAL[Test Healer]
    HEAL --> HDEC{Healing decision}
    HDEC -->|Approve repair| VERIFY[Backend runs targeted Playwright verification]
    VERIFY --> VRES{Verification result}
    VRES -->|Passed| COMMIT
    VRES -->|Failed| DEF[Create GitLab Defect]
    HDEC -->|Raise defect| DEF
    DEF --> COMMIT

    COMMIT -->|Yes| GC[GitLab Commit / Branch]
    COMMIT -->|No| END([Workflow complete])
    GC --> END
```

### Human-controlled gates

The following transitions are intentionally gated:

- Business Review → Scenarios
- Business Review → Re-review
- Strategy → next stage
- Squash upload → Squash execution
- Test execution failure → healing/defect decision
- Healing proposal → approved repair
- Successful final flow → GitLab commit

If the user clicks **Stop**, the backend attempts to terminate the underlying child process/process tree and ignores late results from that stopped run. A stopped stage is not treated as a test failure and therefore should not automatically trigger defect/healing logic.

---

## 5. Agent model

The project contains ten pipeline agent definitions/stages. Some are LLM-driven through Copilot CLI; integration stages can be deterministic backend operations while retaining agent files/contracts for consistency.

| # | Agent / Stage | Main responsibility | Primary output |
|---:|---|---|---|
| 1 | **Test Orchestrator** | Defines/coordinates the overall pipeline contract | Pipeline coordination |
| 2 | **Business Requirements Reviewer** | Checks GitLab requirement completeness/testability | Business review + decision |
| 3 | **Test Scenarios Agent** | Converts approved requirement into E2E scenarios | Scenario artifact |
| 4 | **Test Strategy Agent** | Separates automate/offload scope and proposes test coverage | Strategy + decision matrix |
| 5 | **Script Generator** | Inspects application and generates POM/spec/data | Playwright assets |
| 6 | **Test Healer** | Diagnoses failed tests and proposes focused repair | Healing proposal |
| 7 | **Squash User Agent** | Defines the Squash upload contract | Squash test-case payload |
| 8 | **Squash Test Case Execution** | Creates/runs Squash execution workflow | Execution status/results |
| 9 | **Defect Reporter** | Creates a defect/task from an actual failure | GitLab defect |
| 10 | **GitLab Committer** | Commits approved automation assets | Branch/commit |

Agent source files are under:

```text
.github/agents/
```

Shared contracts and templates are kept in:

```text
.github/agents/_agent-shared-context.md
.github/agents/_agent-execution-template.md
.github/agents/_agent-templates.md
```

The Markdown agent files are the **source of truth** for agent instructions. The Control Center supplies stage-specific context to the runner.

---

## 6. Business Review lifecycle

Business Review is deliberately different from a normal one-shot AI call.

### Initial review

```text
GitLab requirement
      ↓
Business Requirements Reviewer
      ↓
Review artifact + decision
      ↓
Waiting for user approval
```

### Request Changes & Re-review

```text
Existing review
      ↓
User enters feedback
      ↓
Stage = RUNNING
      ↓
Previous decision hidden as current decision
      ↓
Copilot Business Review agent runs again
      ↓
New review artifact
      ↓
New decision
      ↓
Waiting for user approval
```

While re-review is running, the UI should display a clear **Re-review in progress** state rather than continuing to show the previous `Ready for scenarios` decision as if it were the current result.

If the user presses **Stop stage**, the backend terminates the associated process tree where possible and protects the stage from late asynchronous output from the stopped run.

---

## 7. Generated artifacts

The framework keeps important intermediate outputs as inspectable files instead of hiding all results inside the UI.

```text
.test / runtime data
├── test-scenarios/
│   ├── business-review/       # Business review artifacts
│   ├── scenarios/             # Generated scenarios
│   ├── strategy/              # Approved strategies
│   └── squash/                # Squash payload/export artifacts
│
├── pages/                     # Generated Playwright Page Objects
├── tests/                     # Executable Playwright specs
├── test-data/                 # JSON test data
├── test-results/              # Playwright machine-readable results
└── playwright-report/         # Playwright HTML report
```

The exact files generated depend on the GitLab issue and the selected workflow stages.

---

## 8. Project structure

```text
Automation-project/
│
├── .github/
│   └── agents/                # Agent definitions and shared contracts
│
├── .vscode/
│   └── mcp.json               # Local MCP configuration
│
├── automation-ui/
│   ├── src/
│   │   └── server.ts          # Control Center backend/workflow engine
│   ├── public/                # Control Center browser UI
│   ├── agent-runner.js        # Copilot CLI bridge
│   └── dist/                  # Generated build output
│
├── pages/                     # Playwright Page Objects
├── tests/                     # Playwright test specifications
├── test-data/                 # Test input JSON
├── test-scenarios/            # Review/scenario/strategy/Squash artifacts
├── utils/                     # GitLab/Squash/execution utilities
├── docs/                      # Domain-specific technical documentation
├── .env.example               # Configuration template
├── package.json               # Root build/run scripts and dependencies
├── playwright.config.ts      # Playwright settings
├── tsconfig.json              # Main TypeScript configuration
├── tsconfig.utils.json        # Utility TypeScript configuration
├── CHANGELOG.md               # Project history
└── README.md                  # This document
```

---

## 9. Getting started

### Prerequisites

- Node.js 18+
- npm
- Git
- GitHub Copilot CLI with access to the required models/agents
- Playwright browser dependencies
- GitLab access/token
- Squash TM access if Squash stages are used
- Network access to the target application

### Install

```bash
git clone <repository-url>
cd Automation-project
npm install
npx playwright install
```

### Configure

Use one project-level environment file:

```bash
# Windows
copy .env.example .env

# Linux/macOS
cp .env.example .env
```

Edit `.env` for your organization's endpoints, proxy, MCP commands, Copilot model, and timeouts.

**Do not commit `.env`.** It is intentionally ignored by Git.

### Authenticate Copilot CLI

```bash
npm install -g @github/copilot
copilot login
```

Verify that `copilot` is available in the terminal used to start the Control Center.

### Start the Control Center

Development mode:

```bash
npm run ui:dev
```

Compiled mode:

```bash
npm run ui:build
npm run ui:start
```

The default UI is:

```text
http://localhost:4173
```

---

## 10. Configuration

The project uses a **single root `.env` file** for configuration. The template is `.env.example`.

| Area | Important variables |
|---|---|
| Control Center | `UI_PORT` |
| GitLab | `GITLAB_API_URL`, `GITLAB_READ_ONLY_MODE`, `GITLAB_PERMISSION_MODE`, `USE_GITLAB_WIKI` |
| GitLab MCP | `GITLAB_MCP_COMMAND`, `GITLAB_MCP_ARGS` |
| Squash | `SQUASH_BASE_URL` |
| Playwright MCP | `PLAYWRIGHT_MCP_COMMAND`, `PLAYWRIGHT_MCP_ARGS` |
| Browser proxy | `PLAYWRIGHT_PROXY_SERVER`, `PLAYWRIGHT_PROXY_BYPASS`, `PLAYWRIGHT_IGNORE_HTTPS_ERRORS` |
| Corporate network | `HTTPS_PROXY`, `HTTP_PROXY`, `NO_PROXY`, `NODE_EXTRA_CA_CERTS` |
| Copilot | `COPILOT_MODEL`, `COPILOT_MODEL_<STAGE>`, `COPILOT_COMMAND`, `COPILOT_EXTRA_ARGS` |
| Agent runner | `AGENT_RUNNER_COMMAND` |
| Timeouts | `AGENT_TIMEOUT_MS`, stage-specific agent timeouts, healer diagnosis/repair timeouts |

### Tokens

The Control Center intentionally does **not** require GitLab/Squash credentials to be stored in `.env`.

- GitLab MCP authentication can prompt securely through the configured MCP client.
- The Control Center token fields are kept in backend process memory and are not persisted to `.automation-ui/session.json`.
- Squash bearer credentials entered in the Control Center are not written to `.env`.
- Restarting the Control Center requires runtime tokens to be entered again.

For VS Code/Copilot client workflows, the `.env.example` also documents optional token variables for agent-driven terminal scripts. Keep those values local and never commit them.

---

## 11. Corporate proxy / organization network

For an organization environment, configure the proxy in `.env` rather than hard-coding it in source code.

Example:

```dotenv
HTTPS_PROXY=http://proxy.mycompany.com:8080
HTTP_PROXY=http://proxy.mycompany.com:8080
NO_PROXY=localhost,127.0.0.1,.mycompany.com
PLAYWRIGHT_PROXY_SERVER=http://proxy.mycompany.com:8080
NODE_EXTRA_CA_CERTS=C:\certs\company-ca.pem
```

Use `NODE_EXTRA_CA_CERTS` when the corporate proxy performs TLS inspection and Node does not trust the corporate CA. Avoid disabling TLS verification unless there is no supported alternative.

The same configuration supports:

- GitLab API calls
- Squash API calls
- npm/npx package access
- Copilot CLI
- Playwright browser traffic
- Playwright MCP

---

## 12. GitLab integration

GitLab is the authoritative requirement source for the pipeline.

Typical flow:

```text
GitLab Issue / Work Item
        ↓
Session creation
        ↓
Authoritative title + description
        ↓
Business Review
        ↓
Scenarios / Strategy / Automation
        ↓
Optional defect
        ↓
Optional branch + commit
```

The framework supports a GitLab MCP path and backend API fallback where applicable. The original issue ID is carried through the workflow so generated artifacts and defects remain associated with the requirement.

---

## 13. Playwright integration

Playwright is responsible for actual browser automation and test execution.

The Script Generation stage generates:

- Page Object Models under `pages/`
- Test specifications under `tests/`
- Test data under `test-data/`

Before Script Generation is accepted, the backend validates that generated specs are usable and can be discovered by Playwright.

Execution then uses Playwright directly and produces JSON/HTML evidence. The Test Healer consumes the actual execution evidence instead of inventing failure details.

Useful commands:

```bash
# Run all Playwright tests
npx playwright test

# Run one issue
npx playwright test tests/issue-2.spec.ts

# Headed execution
npx playwright test --headed

# Interactive UI mode
npx playwright test --ui

# Debug
npx playwright test --debug

# View HTML report
npx playwright show-report
```

---

## 14. Squash TM integration

Squash TM is optional. It is deliberately controlled by the user instead of being silently triggered after strategy approval.

Typical flow:

```text
Approved Strategy
      ↓
User chooses Squash upload
      ↓
Squash test cases uploaded
      ↓
User chooses whether to execute
      ↓
Squash execution plan / execution
```

Configure the API root using:

```dotenv
SQUASH_BASE_URL=http://your-squash-host/squash/api/rest/latest
```

The Squash bearer token should be provided through the supported runtime token mechanism rather than committed to source control.

---

## 15. Test healing and defect handling

When Playwright execution fails, the framework uses the actual execution evidence to identify impacted test cases.

The normal decision path is:

```text
Playwright failure
      ↓
Test Healer diagnosis
      ↓
Reviewable repair proposal
      ↓
User approval
      ↓
Approved repair applied
      ↓
Backend performs one targeted Playwright verification
      ↓
┌───────────────┴───────────────┐
│                               │
Passed                       Failed
│                               │
Continue                    Defect Reporter
                                ↓
                         GitLab defect/task
```

The healer is not supposed to run an uncontrolled second verification loop. The Control Center owns the verification step after an approved repair.

Defect creation should be based on the actual failure/error evidence and linked back to the originating requirement.

---

## 16. Stop, resume, and asynchronous process safety

Every long-running stage is treated as an asynchronous child process.

The Control Center maintains an active-run registry so it can associate:

```text
Session + Stage → Child Process
```

When a stage is stopped:

1. The stage is marked **Stopped by user**.
2. The backend requests termination of the child process/process tree.
3. Late stdout/stderr or completion callbacks from that run are ignored for stage-state purposes.
4. The stopped stage does not become a false failure.
5. Resume starts a new process rather than attempting to pause an already-running Copilot/Playwright process.

This is particularly important for Copilot CLI stages, which may launch their own background work.

---

## 17. Run All behavior

Run All is an orchestration convenience, not a bypass around the workflow gates.

Conceptually:

```text
Run All
  ↓
Start eligible stage
  ↓
Wait for completion
  ↓
Check gate / user decision
  ↓
Only then start next eligible stage
```

For example, if Business Review requests revision, Run All must wait for the user's re-review/approval decision instead of immediately starting Test Scenarios.

Likewise, Squash upload/execution and healing/defect/commit decisions remain controlled transitions.

---

## 18. Building the project

The main build command is:

```bash
npm run ui:build
```

It performs both utility and UI TypeScript builds:

```text
npm run build:utils
        ↓
TypeScript → utility JavaScript
        ↓
tsc -p automation-ui/tsconfig.json
        ↓
automation-ui/dist
```

For a clean dependency setup:

```bash
npm ci
npm run ui:build
```

If the build fails, fix the **first TypeScript error** reported by the compiler before chasing later cascading errors.

---

## 19. Development commands

```bash
# Install dependencies
npm install

# Development Control Center
npm run ui:dev

# Production-style compiled Control Center
npm run ui:build
npm run ui:start

# Playwright tests
npx playwright test

# Playwright report
npx playwright show-report
```

---

## 20. Troubleshooting

### Build fails

```bash
npm ci
npm run ui:build
```

If it still fails, capture the complete compiler output, especially the first `error TS...` line.

### Copilot agent does not start

Check:

```bash
copilot --version
copilot login
```

Then verify:

- `COPILOT_COMMAND`
- `AGENT_RUNNER_COMMAND`
- `.github/agents/*.agent.md`
- organization proxy settings

### Agent starts but appears stuck

Check the Control Center Activity Log for:

- agent instruction path
- selected model
- MCP server startup
- Copilot CLI output
- proxy status

Use **Stop stage** rather than starting another copy of the same stage. A stopped run should not be allowed to overwrite the state of a newer run.

### Playwright says “No tests found”

Verify:

```bash
npx playwright test --list
```

Then check that the generated spec exists under `tests/` and matches the configured Playwright `testDir`/patterns.

### GitLab MCP fails

Check:

- GitLab URL/API URL
- authentication
- MCP command/package availability
- proxy/CA settings
- organization firewall restrictions

### Squash fails

Check:

- `SQUASH_BASE_URL`
- Squash availability from the machine
- folder/project ID
- runtime bearer token
- proxy/`NO_PROXY`

---

## 21. Security guidelines

- Never commit `.env`.
- Never commit GitLab or Squash tokens.
- Prefer `NODE_EXTRA_CA_CERTS` to disabling TLS verification.
- Keep MCP servers behind the local Control Center rather than exposing credentials to browser JavaScript.
- Review generated AI changes before approving them for execution or commit.
- Keep GitLab read-only mode enabled when an environment does not require write operations.
- Use explicit human approval before healing code, creating defects, uploading/executing Squash tests, or committing generated automation.

---

## 22. Documentation map

| Document | Purpose |
|---|---|
| `README.md` | Architecture, technology stack, workflow, setup, configuration |
| `CHANGELOG.md` | Project changes and fixes |
| `.github/agents/_agent-shared-context.md` | Shared agent rules and pipeline contracts |
| `.github/agents/_agent-execution-template.md` | Standard execution patterns |
| `.github/agents/_agent-templates.md` | Agent output templates |
| `automation-ui/README.md` | Control Center-specific operation and runtime details |
| `docs/squash-integration-fixes.md` | Squash integration details |
| `docs/healer-optimization.md` | Test Healer design and optimization |
| `docs/ui-improvements.md` | UI-specific changes |
| `docs/runtime-fixes.md` | Runtime and process fixes |
| `docs/OPTIMIZATION_NOTES.md` | Repository/code optimization notes |

---

## 23. Extending the framework

### Add a new agent

1. Add an agent definition under `.github/agents/`.
2. Define PURPOSE / PIPELINE / RUN MODE / INPUT / OUTPUT.
3. Add the stage to the backend stage model if it needs Control Center lifecycle management.
4. Add the stage mapping to `automation-ui/agent-runner.js` when Copilot CLI execution is required.
5. Define its artifacts and validation rules.
6. Add the appropriate UI gate/approval behavior.
7. Test success, failure, stop, and rerun behavior.
8. Update this README and `CHANGELOG.md`.

### Add a new integration

Prefer keeping integration-specific logic in `utils/` or a focused backend module. Do not put credentials or organization-specific endpoints directly into source code; use `.env` configuration and runtime tokens.

---

## 24. Design principles

The framework follows these principles:

- **Requirement first:** GitLab is the authoritative requirement source.
- **Human in the loop:** AI proposes; users approve important transitions.
- **Evidence based:** execution/healing/defect decisions use actual artifacts and logs.
- **Deterministic gates:** downstream stages do not silently bypass approvals.
- **One configuration file:** organization-specific infrastructure belongs in `.env`.
- **Process safety:** long-running agents can be stopped and stale callbacks cannot overwrite newer state.
- **Tool separation:** Copilot handles agent reasoning; Playwright performs browser automation; GitLab/Squash handle their respective systems.
- **Reviewable artifacts:** generated scenarios, strategies, scripts, reports, and defects remain inspectable.
- **Safe automation:** destructive or externally visible actions require explicit user control.

---

## 25. License

No `LICENSE` file is currently included. Add an organization-approved license before distributing the framework outside its intended environment.

---

**Last updated:** October 4, 2026
