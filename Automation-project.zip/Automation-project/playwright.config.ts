import { defineConfig, devices } from '@playwright/test';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// The single project-root .env is loaded here (plus proxy / CA normalisation) so that
// `npx playwright test` behaves the same as runs started from the Control Center.
import { initRuntime, playwrightProxy, playwrightIgnoreHttpsErrors } from './utils/runtime-env';
initRuntime();

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  testDir: './tests',

  outputDir: 'test-results', // Stores screenshots, videos, and trace zips
  
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [
    ['list'],
    ['html', { outputFolder: process.env.PW_HTML_REPORT_DIR || 'playwright-report' }],
    ['json', { outputFile: process.env.PW_JSON_REPORT_FILE || 'test-results/results.json' }] // Generates structural log for AI Healer
  ],
  
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : undefined,
  
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    // Keep CI/control-center execution headless by default. Use --headed only when
    // a developer explicitly wants a visible browser for local debugging.
    headless: true,
    // Corporate proxy for the browser (PLAYWRIGHT_PROXY_SERVER, or the general HTTPS_PROXY/HTTP_PROXY).
    // Left undefined when no proxy is configured, so local runs are unaffected.
    proxy: playwrightProxy(),
    // Only for TLS-inspecting proxies whose CA is not trusted by the browser. Prefer a proper CA.
    ignoreHTTPSErrors: playwrightIgnoreHttpsErrors(),
    /* Base URL to use in actions like `await page.goto('')`. */
    // baseURL: 'http://localhost:3000',

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  


  /* Configure projects for major browsers */
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    }
    /* Test against mobile viewports. */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Test against branded browsers. */
    // {
    //   name: 'Microsoft Edge',
    //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
  
});
