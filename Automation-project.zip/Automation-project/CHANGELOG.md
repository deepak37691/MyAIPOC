# v60 — Runtime credential isolation hardening

- GitLab credentials are no longer passed to unrelated Copilot agent stages. Only the GitLab-backed `scenarios` and `defect` agents receive the runtime GitLab token; Business Review, Strategy, Script Generation, Test Healer, and Squash-related agent processes do not.
- Added defense-in-depth runtime secret redaction for Activity Log messages, agent output/errors, and persisted session state.
- Preserved the existing GitLab MCP and Squash runtime-token flows; no stage sequencing, artifact, approval, execution, or MCP functionality was changed.

## v57

- Fixed Copilot CLI MCP startup on Windows by using `--additional-mcp-config @<temporary-file>` instead of inline JSON, preventing `configuration must be an object` caused by Windows command-line quoting.
- Do not pass an empty MCP configuration to stages that do not use MCP.
- Updated per-session MCP definitions to the current Copilot CLI `type: local` format and explicit tool lists.
- Runtime GitLab credentials remain inherited in memory and are not written to the temporary MCP config.

# Project Changelog

This document provides an overview of significant changes by version and domain.

For detailed fix documentation, see:
- [Squash Integration Fixes](./docs/squash-integration-fixes.md) - Association, suite validation, test case execution
- [Healer Optimization](./docs/healer-optimization.md) - Healing performance and reliability improvements
- [UI Improvements](./docs/ui-improvements.md) - Control Center interface enhancements
- [Runtime Fixes](./docs/runtime-fixes.md) - Execution environment and synchronization issues

---

## Version 33 (Current)

### ✨ Project Optimization
- **Code Cleanup**: Removed duplicate compiled files (.js), build artifacts, and backups
- **Documentation**: Consolidated 11 version-specific docs into domain-organized guides
- **Agent Optimization**: Refactored agents with shared context modules (32% token reduction)
- **Impact**: Smaller repo, faster builds, cleaner git history, zero functionality impact

### 🔧 Maintenance Improvements
- Updated `.gitignore` to exclude build outputs and compiled files
- Standardized documentation structure
- Centralized agent rules and patterns
- See [OPTIMIZATION_NOTES.md](./docs/OPTIMIZATION_NOTES.md) for technical details

---

## Version 32 and Earlier

See git history for detailed changes:
```bash
git log --oneline
git show <commit>  # View specific change
```

---

## How to Use This Changelog

1. **For recent changes**: Check "Version 33 (Current)" above
2. **For domain-specific fixes**: See links at top for consolidated guides
3. **For version history**: Use git commands above
4. **For technical details**: See docs/ folder

---

## Contributing

When making changes:
1. Update relevant domain doc (see docs/)
2. Update this CHANGELOG.md with a summary
3. Follow semantic versioning for releases

