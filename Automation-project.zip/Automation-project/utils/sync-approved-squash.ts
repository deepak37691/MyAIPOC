import fs from 'node:fs';
import path from 'node:path';

export interface SyncApprovedSquashOptions {
  rootDir: string;
  baseUrl: string;
  token: string;
  folderId: number;
  strategyPath: string;
  scenarioPath: string;
  issueId: string;
}

function apiRoot(baseUrl: string): string {
  return baseUrl.replace(/\/+$/, '').replace(/\/test-cases\/?$/i, '');
}

async function json(response: Response): Promise<any> {
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

async function requestJson(url: string, token: string, init?: RequestInit): Promise<any> {
  const response = await fetch(url, {
    ...init,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(init?.headers || {})
    }
  });
  const body = await json(response);
  if (!response.ok) throw new Error(`${init?.method || 'GET'} ${url} failed with HTTP ${response.status}: ${JSON.stringify(body)}`);
  return body;
}

function selectedIds(strategyText: string): string[] {
  const candidateIds = [...strategyText.replace(/\r/g, '').matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)]
    .map(m => m[1].toUpperCase());
  if (candidateIds.length) return [...new Set(candidateIds)];
  return [...new Set([...strategyText.matchAll(/^\|\s*(?:\*\*)?(TC-\d+)(?:\*\*)?\s*\|.*?\|\s*\*\*AUTOMATE(?: \(E2E\))?\*\*/gmi)].map(m => m[1].toUpperCase()))];
}

function scenarioDetail(scenarioText: string, id: string): any | undefined {
  const lines = scenarioText.replace(/\r/g, '').split('\n');
  const idx = lines.findIndex(line => new RegExp(`^###\\s+${id}\\b`, 'i').test(line));
  if (idx < 0) return undefined;
  const end = lines.findIndex((line, i) => i > idx && (/^###\s+TC-\d+/i.test(line) || /^##\s+\d+\./.test(line)));
  const block = lines.slice(idx, end < 0 ? lines.length : end);
  const heading = block[0].match(/^###\s+(TC-\d+)\s*:\s*(.*)$/i);
  const title = heading?.[2]?.trim() || id;
  const preIdx = block.findIndex(line => /^[-*]\s+\*\*Preconditions\*\*:/i.test(line));
  const stepsIdx = block.findIndex(line => /^[-*]\s+\*\*Steps\*\*\s*:/i.test(line));
  const expectedIdx = block.findIndex(line => /^[-*]\s+\*\*Expected Results\*\*\s*:/i.test(line));
  const pre = preIdx >= 0
    ? block.slice(preIdx + 1, Math.max(stepsIdx >= 0 ? stepsIdx : block.length, preIdx + 1)).map(x => x.replace(/^\s*[-*]\s*/, '').trim()).filter(Boolean).join(' ')
    : 'Environment and application are available for the scenario.';
  const priority = /TC-\d+/i.test(id) ? (() => {
    const line = block.find(x => /\*\*Priority\*\*:/i.test(x));
    return line?.match(/\*\*Priority\*\*:\s*([^\s]+)/i)?.[1] || 'P2';
  })() : 'P2';
  const importance = /P0/i.test(priority) ? 'VERY_HIGH' : /P1/i.test(priority) ? 'HIGH' : 'MEDIUM';
  const steps: any[] = [];
  if (stepsIdx >= 0) {
    const stepLines = block.slice(stepsIdx + 1, expectedIdx >= 0 ? expectedIdx : block.length);
    for (let i = 0; i < stepLines.length; i++) {
      const m = stepLines[i].match(/^\s*\d+[.)]\s+(.*)$/);
      if (!m) continue;
      const action = m[1].replace(/\*\*/g, '').trim();
      let expected = 'Verify the expected outcome for the action.';
      const next = stepLines.slice(i + 1).find(x => /^\s*[-*]\s+\*\*Expected Result\*\*\s*:/i.test(x));
      if (next) expected = next.replace(/^\s*[-*]\s+\*\*Expected Result\*\*\s*:\s*/i, '').replace(/\*\*/g, '').trim();
      steps.push({ action, expected });
    }
  }
  if (!steps.length) steps.push({ action: `Execute the scenario: ${title}.`, expected: 'The scenario behaves as specified in the source scenario document.' });
  return { title, priority, importance, prerequisite: pre, steps };
}

const html = (value: string) => `<p>${String(value || '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' } as any)[c]).replace(/\n/g, '<br>')}</p>`;

export async function syncApprovedTestCasesToSquash(options: SyncApprovedSquashOptions) {
  const strategy = fs.readFileSync(path.resolve(options.rootDir, options.strategyPath), 'utf8');
  const scenarios = fs.readFileSync(path.resolve(options.rootDir, options.scenarioPath), 'utf8');
  const ids = selectedIds(strategy);
  if (!ids.length) throw new Error('The approved strategy contains no approved Candidate test cases.');

  const root = apiRoot(options.baseUrl);
  const folder = await requestJson(`${root}/test-case-folders/${options.folderId}`, options.token);
  const contents = await requestJson(`${root}/test-case-folders/${options.folderId}/content?page=0&size=2000`, options.token);
  const existing = Array.isArray(contents?._embedded?.content) ? contents._embedded.content : (Array.isArray(contents?.content) ? contents.content : []);
  const existingByReference = new Map<string, any[]>();
  for (const item of existing) {
    const ref = String(item?.reference || '').trim().toUpperCase();
    if (!ref) continue;
    const bucket = existingByReference.get(ref) || [];
    bucket.push(item);
    existingByReference.set(ref, bucket);
  }

  const payload: any[] = [];
  for (const id of ids) {
    const detail = scenarioDetail(scenarios, id);
    if (!detail) throw new Error(`Selected test case ${id} was not found in the scenario artifact.`);
    payload.push({
      _type: 'test-case',
      name: `${id}: ${detail.title}`,
      reference: id,
      prerequisite: detail.prerequisite,
      description: html(detail.title),
      importance: detail.importance,
      status: 'WORK_IN_PROGRESS',
      parent: { _type: 'test-case-folder', id: options.folderId },
      steps: detail.steps.map((step: any) => ({ _type: 'action-step', action: html(step.action), expected_result: html(step.expected) }))
    });
  }

  const uploaded: any[] = [];
  const updated: any[] = [];
  const kept: any[] = [];
  const resolvedTestCases: any[] = [];
  const duplicateReferences: any[] = [];

  // Squash does not allow `steps` to be patched through /test-cases/{id}.
  // The API explicitly requires the steps entity URL. Keep metadata and steps
  // as two separate synchronization operations.
  async function syncExistingTestCaseSteps(testCaseId: number, desiredSteps: any[]) {
    const current = await requestJson(`${root}/test-cases/${testCaseId}`, options.token);
    const currentSteps = Array.isArray(current?.steps)
      ? current.steps
      : Array.isArray(current?._embedded?.steps) ? current._embedded.steps : [];

    const stepsHref = current?._links?.steps?.href || current?._links?.['test-steps']?.href || `${root}/test-cases/${testCaseId}/steps`;
    const normalizeStep = (step: any) => ({
      _type: step?._type || 'action-step',
      action: step?.action ?? '',
      expected_result: step?.expected_result ?? step?.expectedResult ?? ''
    });

    // Update steps that already exist. The self link is the safest direct
    // entity URL because Squash versions can expose different step routes.
    const common = Math.min(currentSteps.length, desiredSteps.length);
    for (let i = 0; i < common; i++) {
      const selfHref = currentSteps[i]?._links?.self?.href || `${root}/test-steps/${currentSteps[i]?.id}`;
      if (!currentSteps[i]?.id && !currentSteps[i]?._links?.self?.href) {
        throw new Error(`Squash test case ${testCaseId} returned a test step without an id/self URL.`);
      }
      await requestJson(selfHref, options.token, {
        method: 'PATCH',
        body: JSON.stringify(normalizeStep(desiredSteps[i]))
      });
    }

    // Remove stale steps only when the synchronized scenario has fewer steps.
    for (let i = currentSteps.length - 1; i >= desiredSteps.length; i--) {
      const selfHref = currentSteps[i]?._links?.self?.href || `${root}/test-steps/${currentSteps[i]?.id}`;
      await requestJson(selfHref, options.token, { method: 'DELETE' });
    }

    // Append missing steps through the test-case's direct steps collection.
    for (let i = currentSteps.length; i < desiredSteps.length; i++) {
      await requestJson(stepsHref, options.token, {
        method: 'POST',
        body: JSON.stringify(normalizeStep(desiredSteps[i]))
      });
    }

    // Verify the actual step list after mutation.
    const verified = await requestJson(`${root}/test-cases/${testCaseId}`, options.token);
    const verifiedSteps = Array.isArray(verified?.steps)
      ? verified.steps
      : Array.isArray(verified?._embedded?.steps) ? verified._embedded.steps : [];
    if (verifiedSteps.length !== desiredSteps.length) {
      throw new Error(`Squash test case ${testCaseId} step synchronization failed: expected ${desiredSteps.length}, found ${verifiedSteps.length}.`);
    }
    return verified;
  }

  for (const tc of payload) {
    const ref = String(tc.reference).trim().toUpperCase();
    const matches = existingByReference.get(ref) || [];

    if (matches.length > 1) {
      duplicateReferences.push({ reference: tc.reference, ids: matches.map((x: any) => Number(x?.id)).filter(Boolean), names: matches.map((x: any) => x?.name).filter(Boolean) });
    }

    if (matches.length) {
      // A reference is the stable identity for synchronization. If an old test case
      // reused the same reference but has a different title, update that existing
      // resource instead of creating another TC-001/TC-002. Prefer an exact-name
      // match when one already exists; otherwise update the first existing resource.
      const desiredName = String(tc.name).trim().toLowerCase();
      const target = matches.find((x: any) => String(x?.name || '').trim().toLowerCase() === desiredName) || matches[0];
      const targetId = Number(target?.id);
      if (!targetId) throw new Error(`Squash test case ${tc.reference} exists but has no numeric id.`);

      // IMPORTANT: `steps` is not a patchable test-case attribute in Squash.
      // Patch only fields that belong to the test-case entity itself.
      const { parent: _parent, steps: desiredSteps, ...metadataPayload } = tc;
      const updatedCase = await requestJson(`${root}/test-cases/${targetId}`, options.token, {
        method: 'PATCH',
        body: JSON.stringify({ ...metadataPayload, id: targetId })
      });

      const verifiedCase = await syncExistingTestCaseSteps(targetId, desiredSteps || []);
      const resolved = verifiedCase?.id ? verifiedCase : (updatedCase?.id ? updatedCase : { ...target, ...tc, id: targetId });
      updated.push({ reference: tc.reference, name: tc.name, id: targetId, response: updatedCase, stepsSynchronized: true });
      kept.push({ reference: tc.reference, name: tc.name, id: targetId, existing: true, updated: true });
      resolvedTestCases.push(resolved);
      continue;
    }

    const created = await requestJson(`${root}/test-cases`, options.token, { method: 'POST', body: JSON.stringify(tc) });
    const createdId = Number(created?.id);
    let resolved = created?.id ? created : { ...tc };
    if (createdId > 0) {
      // Some Squash deployments accept the test-case metadata on create but do not
      // persist the nested steps collection from the same payload. Verify and repair
      // the actual step entities immediately after creation so a new case is never
      // left with all of its scenario content in the prerequisite field.
      resolved = await syncExistingTestCaseSteps(createdId, tc.steps || []);
    }
    uploaded.push({ reference: tc.reference, name: tc.name, id: created?.id, response: created, stepsSynchronized: createdId > 0 });
    resolvedTestCases.push(resolved);
    existingByReference.set(ref, [resolved]);
  }

  return {
    folder: { id: Number(folder?.id || options.folderId), name: folder?.name, projectId: Number(folder?.project?.id || 0) || undefined },
    selectedIds: ids,
    payload,
    uploaded,
    updated,
    kept,
    resolvedTestCases,
    duplicateReferences,
    uploadedCount: uploaded.length,
    updatedCount: updated.length,
    keptCount: kept.length
  };
}

if (require.main === module) {
  const [folderId, strategyPath, scenarioPath, issueId] = process.argv.slice(2);
  const baseUrl = process.env.SQUASH_BASE_URL || 'http://localhost:8080/squash/api/rest/latest/test-cases';
  const token = process.env.SQUASH_BEARER_TOKEN || '';
  if (!token || !folderId || !strategyPath || !scenarioPath) throw new Error('Usage: sync-approved-squash <folderId> <strategyPath> <scenarioPath> [issueId]');
  syncApprovedTestCasesToSquash({ rootDir: process.cwd(), baseUrl, token, folderId: Number(folderId), strategyPath, scenarioPath, issueId: issueId || '' })
    .then(result => console.log(JSON.stringify(result, null, 2)))
    .catch(error => { console.error(error); process.exit(1); });
}
