"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeSquashTestCaseExecution = executeSquashTestCaseExecution;
const runtime_env_1 = require("../runtime-env");
(0, runtime_env_1.initRuntime)(); // loads the root .env, applies proxy settings
const test_1 = require("@playwright/test");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
function idOf(value) {
    const id = Number(value?.id ?? value?.content?.id ?? value?.entity?.id);
    return Number.isFinite(id) && id > 0 ? id : undefined;
}
function contentOf(value) {
    if (Array.isArray(value))
        return value;
    for (const key of ['content', 'testCases', 'test_cases', 'iterations', 'campaigns', 'testSuites', 'test_suites', 'test-suites', 'test_plan', 'testPlan', 'test-plan', 'test_plan_items', 'testPlanItems', 'items', 'results', 'entities', '_embedded']) {
        const candidate = value?.[key];
        if (Array.isArray(candidate))
            return candidate;
        if (candidate && typeof candidate === 'object') {
            const nested = contentOf(candidate);
            if (nested.length)
                return nested;
        }
    }
    if (value && typeof value === 'object') {
        for (const [key, candidate] of Object.entries(value)) {
            const lower = key.toLowerCase();
            if (['content', 'testcases', 'test_cases', 'iterations', 'campaigns', 'testsuites', 'test_suites', 'test-suites', 'test_plan', 'testplan', 'test-plan', 'test_plan_items', 'testplanitems', 'items', 'results', 'entities', '_embedded', 'test-cases'].includes(lower)) {
                if (Array.isArray(candidate))
                    return candidate;
                if (candidate && typeof candidate === 'object') {
                    const nested = contentOf(candidate);
                    if (nested.length)
                        return nested;
                }
            }
        }
    }
    return [];
}
function unwrap(value) {
    if (value && typeof value === 'object') {
        for (const key of ['content', 'entity', 'resource']) {
            if (value[key] && !Array.isArray(value[key]) && typeof value[key] === 'object')
                return value[key];
        }
    }
    return value;
}
async function parseResponse(response) {
    const text = await response.text();
    if (!text)
        return {};
    try {
        return JSON.parse(text);
    }
    catch {
        return { raw: text };
    }
}
function normalizeApiBase(base) {
    // SQUASH_BASE_URL is also used by the legacy test-case uploader, where
    // some setups point it at /test-cases. Execution APIs live one level above
    // that resource, so normalize that value instead of producing
    // /test-cases/test-case-folders/{id}.
    return base.replace(/\/+$/, '').replace(/\/test-cases$/i, '');
}
function join(base, endpoint) {
    return `${normalizeApiBase(base)}/${endpoint.replace(/^\/+/, '')}`;
}
async function call(api, method, url, data) {
    const response = method === 'GET'
        ? await api.get(url)
        : method === 'PATCH' ? await api.patch(url, { data })
            : method === 'PUT' ? await api.put(url, { data })
                : method === 'DELETE' ? await api.delete(url)
                    : await api.post(url, { data });
    const body = await parseResponse(response);
    console.log(`${method} ${url} -> ${response.status()}`);
    if (!response.ok()) {
        const error = new Error(`${method} ${url} failed with HTTP ${response.status()}: ${JSON.stringify(body)}`);
        error.status = response.status();
        error.body = body;
        throw error;
    }
    return body;
}
async function firstSuccessful(api, candidates) {
    let lastError;
    for (const candidate of candidates) {
        try {
            return await candidate();
        }
        catch (e) {
            lastError = e;
        }
    }
    throw lastError || new Error('No compatible Squash API endpoint succeeded.');
}
async function getFolder(api, base, folderId) {
    return unwrap(await call(api, 'GET', join(base, `test-case-folders/${folderId}`)));
}
async function getFolderTestCases(api, base, folderId) {
    // Squash exposes folder content with the valid include values `root` and `nested`.
    // Some installations also expose the relationship directly via the filtered
    // test-cases endpoint, so keep that as a compatibility fallback.
    const result = await firstSuccessful(api, [
        () => call(api, 'GET', join(base, `test-cases?folderId=${folderId}&limit=100`)),
        () => call(api, 'GET', join(base, `test-case-folders/${folderId}/content?include=root`)),
        () => call(api, 'GET', join(base, `test-case-folders/${folderId}/content?include=nested`)),
        () => call(api, 'GET', join(base, `test-cases?parentId=${folderId}&limit=100`))
    ]);
    const all = contentOf(result).filter(x => String(x?._type || '').toLowerCase() !== 'test-case-folder');
    return all.filter(x => idOf(x));
}
async function getCampaignFoldersByProject(api, base, projectId) {
    const result = await firstSuccessful(api, [
        () => call(api, 'GET', join(base, `campaign-folders/tree/${projectId}`)),
        () => call(api, 'GET', join(base, `campaign-folders?projectId=${projectId}&size=2000`))
    ]);
    const folders = [];
    const visit = (value) => {
        if (!value)
            return;
        if (Array.isArray(value)) {
            for (const item of value)
                visit(item);
            return;
        }
        if (typeof value !== 'object')
            return;
        if (String(value?._type || '').toLowerCase() === 'campaign-folder' && idOf(value))
            folders.push(value);
        for (const key of ['folders', 'children', 'content', 'campaign-folders', '_embedded']) {
            if (value[key])
                visit(value[key]);
        }
    };
    visit(result);
    return folders;
}
async function getCampaignFolderByName(api, base, projectId, name) {
    const normalized = name.trim().toLowerCase();
    const folders = await getCampaignFoldersByProject(api, base, projectId);
    return folders.find(folder => String(folder?.name || '').trim().toLowerCase() === normalized);
}
async function getCampaignsInFolder(api, base, folderId) {
    const result = await firstSuccessful(api, [
        () => call(api, 'GET', join(base, `campaign-folders/${folderId}/content?size=2000`)),
        () => call(api, 'GET', join(base, `campaigns?folderId=${folderId}&size=2000`))
    ]);
    return contentOf(result).filter(item => String(item?._type || '').toLowerCase() === 'campaign' && idOf(item));
}
async function getCampaignByName(api, base, folderId, name) {
    const normalized = name.trim().toLowerCase();
    const campaigns = await getCampaignsInFolder(api, base, folderId);
    return campaigns.find(campaign => String(campaign?.name || '').trim().toLowerCase() === normalized);
}
async function getIterationsInCampaign(api, base, campaignId) {
    const result = await firstSuccessful(api, [
        () => call(api, 'GET', join(base, `campaigns/${campaignId}/iterations?size=2000`)),
        () => call(api, 'GET', join(base, `campaigns/${campaignId}`))
    ]);
    const direct = contentOf(result).filter(item => String(item?._type || '').toLowerCase() === 'iteration' && idOf(item));
    if (direct.length)
        return direct;
    const campaign = unwrap(result);
    return Array.isArray(campaign?.iterations) ? campaign.iterations.filter((item) => idOf(item)) : [];
}
async function getIterationByName(api, base, campaignId, name) {
    const normalized = name.trim().toLowerCase();
    const iterations = await getIterationsInCampaign(api, base, campaignId);
    return iterations.find(iteration => String(iteration?.name || '').trim().toLowerCase() === normalized);
}
async function getIterationTestSuites(api, base, iterationId) {
    const result = await call(api, 'GET', join(base, `iterations/${iterationId}/test-suites`));
    return contentOf(result).filter(item => idOf(item) && String(item?.name || '').trim());
}
async function getIterationTestPlan(api, base, iterationId) {
    const result = await call(api, 'GET', join(base, `iterations/${iterationId}/test-plan`));
    return contentOf(result).filter(item => idOf(item));
}
async function getSuiteTestPlan(api, base, suiteId) {
    const result = await call(api, 'GET', join(base, `test-suites/${suiteId}/test-plan`));
    return contentOf(result).filter(item => idOf(item));
}
async function createExecutionFolder(api, base, projectId, name) {
    const existing = await getCampaignFolderByName(api, base, projectId, name);
    if (existing) {
        console.log(`Reusing existing Squash campaign folder "${name}" (id ${idOf(existing)}).`);
        return existing;
    }
    return call(api, 'POST', join(base, 'campaign-folders'), {
        _type: 'campaign-folder', name,
        parent: { _type: 'project', id: projectId }
    });
}
async function createCampaign(api, base, parentType, parentId, name) {
    const existing = await getCampaignByName(api, base, parentId, name);
    if (existing) {
        console.log(`Reusing existing Squash campaign "${name}" (id ${idOf(existing)}).`);
        return existing;
    }
    return call(api, 'POST', join(base, 'campaigns'), {
        _type: 'campaign', name,
        parent: { _type: parentType, id: parentId }
    });
}
async function createIteration(api, base, campaignId, name) {
    const existing = await getIterationByName(api, base, campaignId, name);
    if (existing) {
        console.log(`Reusing existing Squash iteration "${name}" (id ${idOf(existing)}).`);
        return existing;
    }
    try {
        return await call(api, 'POST', join(base, `campaigns/${campaignId}/iterations`), {
            _type: 'iteration', name,
            parent: { _type: 'campaign', id: campaignId }
        });
    }
    catch (error) {
        // Squash returns HTTP 412 when another run already created the same
        // iteration between our GET and POST (or when the GET response shape did
        // not expose the iteration collection). Re-read the campaign and reuse
        // the existing iteration instead of failing the whole execution upload.
        if (error?.status === 412) {
            const afterConflict = await getIterationByName(api, base, campaignId, name);
            if (afterConflict) {
                console.log(`Squash reported a duplicate iteration; reusing "${name}" (id ${idOf(afterConflict)}).`);
                return afterConflict;
            }
        }
        throw error;
    }
}
async function createSuite(api, base, iterationId, name) {
    const normalized = name.trim().toLowerCase();
    const existingSuites = await getIterationTestSuites(api, base, iterationId);
    const existing = existingSuites.find(suite => String(suite?.name || '').trim().toLowerCase() === normalized);
    if (existing) {
        console.log(`Reusing existing Squash test suite "${name}" (id ${idOf(existing)}).`);
        return existing;
    }
    try {
        // Squash exposes suite creation at the collection endpoint. The
        // /iterations/{id}/test-suites route is a GET relationship, not a POST
        // creation endpoint; trying POST there produces HTTP 405.
        return await call(api, 'POST', join(base, 'test-suites'), {
            _type: 'test-suite', name,
            parent: { _type: 'iteration', id: iterationId }
        });
    }
    catch (error) {
        // Another run may have created the suite between our GET and POST.
        if ([409, 412].includes(error?.status)) {
            const afterConflict = await getIterationTestSuites(api, base, iterationId);
            const after = afterConflict.find(suite => String(suite?.name || '').trim().toLowerCase() === normalized);
            if (after) {
                console.log(`Squash reported a duplicate suite; reusing "${name}" (id ${idOf(after)}).`);
                return after;
            }
        }
        throw error;
    }
}
function testCaseIdFromPlanItem(item) {
    return idOf(item?.referenced_test_case || item?.test_case || item?.['test-case'] || item?.testCase || item?.test_case_id || item?.testCaseId);
}
async function addToIterationPlan(api, base, iterationId, testCaseId) {
    const existingPlan = await getIterationTestPlan(api, base, iterationId);
    const existing = existingPlan.find(item => testCaseIdFromPlanItem(item) === testCaseId);
    if (existing) {
        console.log(`Reusing existing Squash iteration plan item for test case ${testCaseId} (id ${idOf(existing)}).`);
        return existing;
    }
    return call(api, 'POST', join(base, `iterations/${iterationId}/test-plan`), {
        _type: 'test-plan-item',
        test_case: { _type: 'test-case', id: testCaseId }
    });
}
async function removeUnselectedIterationPlanItems(api, base, iterationId, selectedTestCaseIds) {
    const plan = await getIterationTestPlan(api, base, iterationId);
    const removed = [];
    for (const item of plan) {
        const itemId = idOf(item);
        const tcId = testCaseIdFromPlanItem(item);
        if (!itemId || !tcId || selectedTestCaseIds.has(tcId))
            continue;
        // Only clean stale/unselected ITPIs. This does not delete test cases, folders,
        // campaigns, iterations, or suites. If an ITPI has already been executed,
        // Squash may reject the deletion; leave it untouched in that case.
        try {
            await call(api, 'DELETE', join(base, `test-plan-items/${itemId}`));
            removed.push({ id: itemId, testCaseId: tcId });
            console.log(`Removed stale Squash iteration plan item ${itemId} for test case ${tcId} from iteration ${iterationId}.`);
        }
        catch (error) {
            console.warn(`Could not remove stale ITPI ${itemId} for test case ${tcId}; leaving it untouched: HTTP ${error?.status ?? 'unknown'} ${JSON.stringify(error?.body ?? {})}`);
        }
    }
    return removed;
}
async function addToSuite(api, base, suiteId, iterationPlanItemId, testCaseId) {
    if (!iterationPlanItemId) {
        throw new Error(`Squash returned an iteration test-plan item without an id for test case ${testCaseId}`);
    }
    // SquashTM REST API 13.0.7 documents suite membership as a dedicated
    // relationship operation: POST /test-suites/{testSuiteId}/test-plan/{ids}.
    // The {ids} value is the iteration test-plan item id.  Do not PATCH the
    // ITPI itself: that changes ITPI fields but does not attach it to a suite.
    const endpoint = `test-suites/${suiteId}/test-plan/${iterationPlanItemId}`;
    const response = await call(api, 'POST', join(base, endpoint));
    console.log(`Attached Squash test case ${testCaseId} (ITPI ${iterationPlanItemId}) to suite ${suiteId} via POST ${endpoint}.`);
    // The documented endpoint returns the modified suite. Verify the returned
    // suite and the suite test plan so a 2xx/no-op cannot silently pass.
    const returnedSuite = unwrap(response);
    const returnedItems = contentOf(returnedSuite?.test_plan ?? returnedSuite?.testPlan ?? returnedSuite?.['test-plan'] ?? returnedSuite);
    const returnedMatch = returnedItems.find((item) => idOf(item) === iterationPlanItemId ||
        idOf(item?.test_plan_item) === iterationPlanItemId ||
        idOf(item?.iteration_test_plan_item) === iterationPlanItemId ||
        testCaseIdFromPlanItem(item) === testCaseId);
    if (!returnedMatch) {
        const after = await call(api, 'GET', join(base, `test-suites/${suiteId}/test-plan`));
        const afterItems = contentOf(after);
        const verified = afterItems.find((item) => idOf(item) === iterationPlanItemId || testCaseIdFromPlanItem(item) === testCaseId);
        if (!verified) {
            throw new Error(`Squash accepted suite attachment POST for suite ${suiteId}, ITPI ${iterationPlanItemId}, ` +
                `but the item was not present in the suite test plan after verification: ${JSON.stringify(after)}`);
        }
        return verified;
    }
    return returnedMatch;
}
async function createExecution(api, base, planItem) {
    const planItemId = idOf(planItem);
    if (!planItemId)
        throw new Error(`Squash returned a test-plan item without an id: ${JSON.stringify(planItem)}`);
    return firstSuccessful(api, [
        () => call(api, 'POST', join(base, `test-plan-items/${planItemId}/executions`), {
            _type: 'execution', parent: { _type: 'test-plan-item', id: planItemId }
        }),
        () => call(api, 'POST', join(base, `executions`), {
            _type: 'execution', test_plan_item: { _type: 'test-plan-item', id: planItemId }
        })
    ]);
}
async function attachEvidence(base, token, executionId, evidencePaths) {
    const uploaded = [];
    for (const evidencePath of evidencePaths) {
        const resolvedPath = path.resolve(evidencePath);
        if (!fs.existsSync(resolvedPath))
            throw new Error(`Evidence file not found: ${resolvedPath}`);
        const attachmentUrl = join(base, `executions/${executionId}/attachments/`);
        const form = new FormData();
        form.append('files', new Blob([fs.readFileSync(resolvedPath)]), path.basename(resolvedPath));
        const response = await fetch(attachmentUrl, {
            method: 'POST',
            headers: { Accept: 'application/json', Authorization: `Bearer ${token}` },
            body: form
        });
        const text = await response.text();
        let body = {};
        try {
            body = text ? JSON.parse(text) : {};
        }
        catch {
            body = { raw: text };
        }
        console.log(`POST ${attachmentUrl} -> ${response.status}`);
        if (!response.ok) {
            const error = new Error(`POST ${attachmentUrl} failed with HTTP ${response.status}: ${JSON.stringify(body)}`);
            error.status = response.status;
            error.body = body;
            throw error;
        }
        uploaded.push({ path: resolvedPath, response: body });
    }
    return uploaded;
}
async function attachSuiteEvidence(base, token, suiteId, evidencePath) {
    const resolvedPath = path.resolve(evidencePath);
    if (!fs.existsSync(resolvedPath))
        throw new Error(`Suite evidence file not found: ${resolvedPath}`);
    const uploadPath = path.extname(resolvedPath).toLowerCase() === '.html'
        ? resolvedPath.replace(/\.html$/i, '.txt')
        : resolvedPath;
    if (uploadPath !== resolvedPath)
        fs.copyFileSync(resolvedPath, uploadPath);
    const attachmentUrl = join(base, `test-suites/${suiteId}/attachments/`);
    const form = new FormData();
    form.append('files', new Blob([fs.readFileSync(uploadPath)]), path.basename(uploadPath));
    const response = await fetch(attachmentUrl, { method: 'POST', headers: { Accept: 'application/json', Authorization: `Bearer ${token}` }, body: form });
    const text = await response.text();
    let body = {};
    try {
        body = text ? JSON.parse(text) : {};
    }
    catch {
        body = { raw: text };
    }
    console.log(`POST ${attachmentUrl} -> ${response.status}`);
    if (!response.ok)
        throw new Error(`POST ${attachmentUrl} failed with HTTP ${response.status}: ${JSON.stringify(body)}`);
    return { sourcePath: resolvedPath, path: uploadPath, response: body };
}
async function updateExecutionStatus(api, base, executionId, status) {
    if (!status)
        return undefined;
    const normalizedStatus = status.toLowerCase();
    const executionStatus = normalizedStatus === 'failed' ? 'FAILURE'
        : ['passed', 'completed', 'success'].includes(normalizedStatus) ? 'SUCCESS'
            : undefined;
    if (!executionStatus)
        throw new Error(`Unsupported test execution result status for Squash execution ${executionId}: ${status}`);
    return call(api, 'PATCH', join(base, `executions/${executionId}`), { _type: 'execution', execution_status: executionStatus });
}
async function executeSquashTestCaseExecution(config) {
    if (!config.token)
        throw new Error('Squash API token is required.');
    if (!Number.isInteger(config.testCaseFolderId) || config.testCaseFolderId < 1)
        throw new Error('A valid Squash Test Case Folder ID is required.');
    for (const [name, value] of Object.entries({ executionFolderName: config.executionFolderName, campaignName: config.campaignName, iterationName: config.iterationName })) {
        if (!String(value || '').trim())
            throw new Error(`${name} is required.`);
    }
    const base = normalizeApiBase(config.baseUrl);
    const api = await test_1.request.newContext({
        proxy: (0, runtime_env_1.playwrightProxy)(),
        extraHTTPHeaders: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${config.token}`
        }
    });
    try {
        const folder = await getFolder(api, base, config.testCaseFolderId);
        const projectId = idOf(folder?.project || folder?.parentProject || folder?.parent) || Number(folder?.projectId);
        if (!projectId)
            throw new Error(`Could not resolve the Squash project for test case folder ${config.testCaseFolderId}. Folder response: ${JSON.stringify(folder)}`);
        const folderTestCases = await getFolderTestCases(api, base, config.testCaseFolderId);
        if (!folderTestCases.length)
            throw new Error(`No test cases were found in Squash Test Case Folder ${config.testCaseFolderId}.`);
        // Synchronization determines which source test cases belong to this run.
        // Do not use prior PASS/FAIL results as a filter. When explicit IDs/references
        // are supplied by the synchronization stage, execute exactly those cases; this
        // prevents stale/manual cases already present in the folder from being pulled
        // into the iteration and prevents reference-based duplicates from reappearing.
        let testCases = folderTestCases;
        if (Array.isArray(config.testCaseIds) && config.testCaseIds.length) {
            const wanted = new Set(config.testCaseIds.map(Number).filter(x => Number.isFinite(x) && x > 0));
            testCases = folderTestCases.filter(tc => wanted.has(idOf(tc)));
        }
        else if (Array.isArray(config.testCaseReferences) && config.testCaseReferences.length) {
            const wanted = new Set(config.testCaseReferences.map(x => String(x).trim().toUpperCase()).filter(Boolean));
            testCases = folderTestCases.filter(tc => wanted.has(String(tc?.reference || '').trim().toUpperCase()));
        }
        if (!testCases.length)
            throw new Error(`No synchronized Squash test cases were available for execution in Test Case Folder ${config.testCaseFolderId}.`);
        const executionFolder = unwrap(await createExecutionFolder(api, base, projectId, config.executionFolderName.trim()));
        const executionFolderId = idOf(executionFolder);
        if (!executionFolderId)
            throw new Error(`Squash did not return an execution folder ID: ${JSON.stringify(executionFolder)}`);
        const campaign = unwrap(await createCampaign(api, base, 'campaign-folder', executionFolderId, config.campaignName.trim()));
        const campaignId = idOf(campaign);
        if (!campaignId)
            throw new Error(`Squash did not return a campaign ID: ${JSON.stringify(campaign)}`);
        const iteration = unwrap(await createIteration(api, base, campaignId, config.iterationName.trim()));
        const iterationId = idOf(iteration);
        if (!iterationId)
            throw new Error(`Squash did not return an iteration ID: ${JSON.stringify(iteration)}`);
        let suite;
        let suiteId;
        const configuredSuiteName = config.testSuiteName?.trim() || 'Functional';
        suite = unwrap(await createSuite(api, base, iterationId, configuredSuiteName));
        suiteId = idOf(suite);
        if (!suiteId)
            throw new Error(`Squash did not return a test suite ID for ${configuredSuiteName}: ${JSON.stringify(suite)}`);
        // Never delete existing iteration plan items. Existing ITPIs are reusable Squash
        // resources and prior executions/results must not block synchronization or execution.
        const removedStalePlanItems = [];
        const planItems = [];
        const executions = [];
        const evidence = [];
        const evidencePaths = (config.evidencePaths || []).filter(Boolean);
        const executionResults = Array.isArray(config.executionResults) ? config.executionResults : [];
        const normalizeCaseValue = (value) => String(value || '')
            .replace(/^TC-\d+\s*[:|-]?\s*/i, '')
            .trim().toLowerCase().replace(/\s+/g, ' ');
        const usedExecutionResultIndexes = new Set();
        const findExecutionResult = (testCase, index) => {
            if (!executionResults.length)
                return undefined;
            const reference = String(testCase?.reference ?? testCase?.ref ?? '').trim().toUpperCase();
            const title = normalizeCaseValue(testCase?.name ?? testCase?.title ?? testCase?.label);
            const exactId = executionResults.findIndex((result, resultIndex) => {
                if (usedExecutionResultIndexes.has(resultIndex))
                    return false;
                const resultId = String(result?.id ?? result?.key ?? '').trim().toUpperCase();
                return resultId === reference || resultId.endsWith(`::${reference}`);
            });
            if (exactId >= 0) {
                usedExecutionResultIndexes.add(exactId);
                return executionResults[exactId];
            }
            const titleMatch = executionResults.findIndex((result, resultIndex) => {
                if (usedExecutionResultIndexes.has(resultIndex))
                    return false;
                const resultTitle = normalizeCaseValue(result?.title ?? result?.name);
                return !!title && !!resultTitle && (resultTitle === title || resultTitle.startsWith(title) || title.startsWith(resultTitle));
            });
            if (titleMatch >= 0) {
                usedExecutionResultIndexes.add(titleMatch);
                return executionResults[titleMatch];
            }
            // Last-resort positional mapping is only used when no identifying information
            // exists. It never controls which test cases are synchronized; it only maps the
            // already-created execution to a result.
            if (executionResults[index] && !usedExecutionResultIndexes.has(index)) {
                usedExecutionResultIndexes.add(index);
                return executionResults[index];
            }
            return undefined;
        };
        for (const [testCaseIndex, testCase] of testCases.entries()) {
            const testCaseId = idOf(testCase);
            const planItem = unwrap(await addToIterationPlan(api, base, iterationId, testCaseId));
            planItems.push({ testCase, planItem });
            // Functional is the required execution suite. Do not create the execution
            // until Squash confirms that this ITPI is actually visible in that suite.
            if (suiteId) {
                await addToSuite(api, base, suiteId, idOf(planItem), testCaseId);
            }
            const execution = unwrap(await createExecution(api, base, planItem));
            const executionRecord = { testCase, planItem, execution };
            executions.push(executionRecord);
            const executionId = idOf(execution);
            const executionResult = findExecutionResult(testCase, testCaseIndex);
            // Synchronization/execution is never blocked by a previous result. After the
            // real Playwright run has completed, however, copy that actual per-test result
            // onto the newly-created Squash execution so Squash shows SUCCESS/FAILURE
            // instead of leaving every execution in READY.
            if (executionId && executionResult?.status) {
                const updatedExecution = await updateExecutionStatus(api, base, executionId, executionResult.status);
                if (updatedExecution) {
                    executionRecord.execution = unwrap(updatedExecution);
                }
                console.log(`Updated Squash execution ${executionId} for test case ${testCaseId} to ${String(executionResult.status).toUpperCase()}.`);
            }
            if (executionId && evidencePaths.length) {
                evidence.push({ execution: executionRecord.execution, files: await attachEvidence(base, config.token, executionId, evidencePaths) });
            }
        }
        if (suiteId) {
            const finalSuitePlan = await getSuiteTestPlan(api, base, suiteId);
            const expectedIds = new Set(testCases.map(tc => idOf(tc)).filter((x) => Boolean(x)));
            const suiteCaseIds = new Set(finalSuitePlan.map(item => testCaseIdFromPlanItem(item)).filter((x) => Boolean(x)));
            const missing = [...expectedIds].filter(id => !suiteCaseIds.has(id));
            if (missing.length) {
                throw new Error(`Squash suite ${suiteId} (${configuredSuiteName}) is missing synchronized test cases after association: ${missing.join(', ')}.`);
            }
            console.log(`Verified Functional suite ${suiteId} contains all ${expectedIds.size} synchronized test case(s).`);
        }
        if (suiteId && config.suiteEvidencePath)
            evidence.push({ suite, file: await attachSuiteEvidence(base, config.token, suiteId, config.suiteEvidencePath) });
        return { testCaseFolderId: config.testCaseFolderId, projectId, executionFolder, campaign, iteration, suite, testCases, planItems, executions, evidence, removedStalePlanItems };
    }
    finally {
        await api.dispose();
    }
}
if (require.main === module) {
    const [folderIdRaw, executionFolderName, campaignName, iterationName, testSuiteName, evidencePathsRaw, suiteEvidencePath] = process.argv.slice(2);
    executeSquashTestCaseExecution({
        baseUrl: (0, runtime_env_1.squashApiRoot)(),
        token: process.env.SQUASH_BEARER_TOKEN || '',
        testCaseFolderId: Number(folderIdRaw),
        executionFolderName: executionFolderName || '',
        campaignName: campaignName || '',
        iterationName: iterationName || '',
        testSuiteName: testSuiteName || undefined,
        evidencePaths: evidencePathsRaw ? evidencePathsRaw.split(';').filter(Boolean) : [],
        suiteEvidencePath
    }).then(result => {
        console.log(`Created ${result.executions.length} Squash execution(s) from ${result.testCases.length} test case(s).`);
    }).catch(error => {
        console.error(error?.message || error);
        process.exit(1);
    });
}
