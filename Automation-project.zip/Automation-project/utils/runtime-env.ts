/**
 * Central runtime configuration, driven by the single `.env` file in the project root.
 *
 * Every part of the project (Control Center server, Squash utilities, Playwright config,
 * Copilot agent runner, MCP servers) should read its settings through this module so that
 * GitLab, Squash, Playwright MCP, proxy and model settings live in ONE place.
 *
 * Secrets (GitLab token, Squash bearer token) are deliberately NOT handled here: the
 * Control Center keeps them in memory only (entered through the UI).
 */
import fs from 'node:fs';
import path from 'node:path';
import tls from 'node:tls';
import http from 'node:http';

export const PROJECT_ROOT = path.resolve(__dirname, '..');

const DEFAULT_NO_PROXY = ['localhost', '127.0.0.1', '::1'];

let initialised = false;

function first(...names: string[]): string {
  for (const name of names) {
    const value = process.env[name];
    if (value !== undefined && value.trim() !== '') return value.trim();
  }
  return '';
}

export function envBool(name: string, fallback = false): boolean {
  const value = process.env[name];
  if (value === undefined || value.trim() === '') return fallback;
  return /^(1|true|yes|on)$/i.test(value.trim());
}

/** Resolve a path from .env relative to the project root (absolute paths are kept). */
export function resolveFromRoot(p: string): string {
  return path.isAbsolute(p) ? p : path.resolve(PROJECT_ROOT, p);
}

// ---------------------------------------------------------------------------
// .env loading + proxy / certificate normalisation
// ---------------------------------------------------------------------------

export function loadEnvFile(): void {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const dotenv = require('dotenv');
    dotenv.config({ path: path.join(PROJECT_ROOT, '.env'), quiet: true });
  } catch { /* dotenv missing: rely on the real environment */ }
}

/**
 * Make the proxy settings consistent for every tool we spawn:
 *  - HTTP(S)_PROXY / NO_PROXY in both upper and lower case (Node tools, Copilot CLI, git, curl)
 *  - npm_config_* so `npx -y @zereight/mcp-gitlab` / `@playwright/mcp` can download packages
 *  - NODE_EXTRA_CA_CERTS as an absolute path (corporate TLS-inspecting proxies)
 * localhost is always added to NO_PROXY so local Squash / the UI itself never go via the proxy.
 */
export function applyProxyEnv(): void {
  const httpsProxy = first('HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy');
  const httpProxy = first('HTTP_PROXY', 'http_proxy', 'HTTPS_PROXY', 'https_proxy');

  if (httpsProxy) {
    process.env.HTTPS_PROXY = process.env.https_proxy = httpsProxy;
    process.env.npm_config_https_proxy = httpsProxy;
  }
  if (httpProxy) {
    process.env.HTTP_PROXY = process.env.http_proxy = httpProxy;
    process.env.npm_config_proxy = httpProxy;
  }
  const allProxy = first('ALL_PROXY', 'all_proxy');
  if (allProxy) process.env.ALL_PROXY = process.env.all_proxy = allProxy;

  // Only touch NO_PROXY when a proxy is actually configured, so a local-only setup is unchanged.
  if (httpsProxy || httpProxy || allProxy) {
    const existing = first('NO_PROXY', 'no_proxy').split(',').map(s => s.trim()).filter(Boolean);
    const merged = [...new Set([...existing, ...DEFAULT_NO_PROXY])].join(',');
    process.env.NO_PROXY = process.env.no_proxy = merged;
    process.env.npm_config_noproxy = merged;
  }

  const ca = first('NODE_EXTRA_CA_CERTS');
  if (ca) {
    const abs = resolveFromRoot(ca);
    if (fs.existsSync(abs)) {
      process.env.NODE_EXTRA_CA_CERTS = abs;
    } else {
      console.warn(`[env] NODE_EXTRA_CA_CERTS points to a file that does not exist (${abs}); ignoring it.`);
      delete process.env.NODE_EXTRA_CA_CERTS;
    }
  }
}

export function proxyConfigured(): boolean {
  return !!first('HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy', 'ALL_PROXY', 'all_proxy');
}

/**
 * Node's built-in fetch ignores HTTP(S)_PROXY. When a proxy is configured, route the
 * global fetch through it (honouring NO_PROXY). Uses `undici` (declared dependency);
 * falls back to http.setGlobalProxyFromEnv() on Node versions that have it.
 */
function installFetchProxy(): void {
  if (!proxyConfigured()) return;

  // Extra CA bundle for the *current* process (NODE_EXTRA_CA_CERTS is only read at Node start-up).
  let ca: string[] | undefined;
  const caFile = process.env.NODE_EXTRA_CA_CERTS;
  if (caFile && fs.existsSync(caFile)) {
    ca = [...tls.rootCertificates, fs.readFileSync(caFile, 'utf8')];
  }

  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const undici = require('undici');
    const tlsOptions = ca ? { ca } : undefined;
    undici.setGlobalDispatcher(new undici.EnvHttpProxyAgent({
      ...(tlsOptions ? { connect: tlsOptions, requestTls: tlsOptions, proxyTls: tlsOptions } : {})
    }));
    return;
  } catch { /* undici not installed */ }

  const anyHttp = http as any;
  if (typeof anyHttp.setGlobalProxyFromEnv === 'function') {
    anyHttp.setGlobalProxyFromEnv();
    return;
  }
  console.warn('[env] A proxy is configured but neither "undici" nor Node >= 22.21 is available, so API calls made by this process will NOT use the proxy. Run "npm install" to install undici.');
}

/** Load .env, normalise proxy settings, and route fetch through the proxy. Safe to call many times. */
export function initRuntime(): void {
  if (initialised) return;
  initialised = true;
  loadEnvFile();
  applyProxyEnv();
  installFetchProxy();
}

// ---------------------------------------------------------------------------
// GitLab
// ---------------------------------------------------------------------------

export function gitlabApiUrl(): string {
  return (first('GITLAB_API_URL') || 'https://gitlab.com/api/v4').replace(/\/+$/, '');
}

/** Environment passed to the GitLab MCP server (token is added by the caller). */
export function gitlabMcpEnv(): Record<string, string> {
  return {
    GITLAB_API_URL: gitlabApiUrl(),
    GITLAB_READ_ONLY_MODE: first('GITLAB_READ_ONLY_MODE') || 'false',
    USE_GITLAB_WIKI: first('USE_GITLAB_WIKI') || 'true',
    ...(first('GITLAB_PERMISSION_MODE') ? { GITLAB_PERMISSION_MODE: first('GITLAB_PERMISSION_MODE') } : {}),
    ...(envBool('GITLAB_MCP_DEBUG') ? { DEBUG: 'true' } : {})
  };
}

// ---------------------------------------------------------------------------
// Squash TM
// ---------------------------------------------------------------------------

const DEFAULT_SQUASH_API_ROOT = 'http://localhost:8080/squash/api/rest/latest';

/** API root, e.g. http://host:8080/squash/api/rest/latest (a trailing /test-cases is tolerated). */
export function squashApiRoot(): string {
  return (first('SQUASH_BASE_URL') || DEFAULT_SQUASH_API_ROOT).replace(/\/+$/, '').replace(/\/test-cases$/i, '');
}

export function squashTestCasesUrl(): string {
  return `${squashApiRoot()}/test-cases`;
}

// ---------------------------------------------------------------------------
// Playwright (tests, request contexts and Playwright MCP)
// ---------------------------------------------------------------------------

export interface PlaywrightProxy { server: string; bypass?: string; username?: string; password?: string }

/**
 * Proxy for browsers / API contexts launched by Playwright. PLAYWRIGHT_PROXY_SERVER wins;
 * otherwise the general HTTPS_PROXY / HTTP_PROXY is reused. Returns undefined when no proxy is set.
 */
export function playwrightProxy(): PlaywrightProxy | undefined {
  const raw = first('PLAYWRIGHT_PROXY_SERVER', 'HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy');
  if (!raw) return undefined;
  const bypass = (first('PLAYWRIGHT_PROXY_BYPASS', 'NO_PROXY', 'no_proxy') || DEFAULT_NO_PROXY.join(','))
    .split(',').map(s => s.trim()).filter(Boolean).join(',');
  try {
    const url = new URL(raw);
    const username = decodeURIComponent(url.username);
    const password = decodeURIComponent(url.password);
    url.username = '';
    url.password = '';
    return {
      server: url.toString().replace(/\/$/, ''),
      bypass,
      ...(username ? { username, password } : {})
    };
  } catch {
    return { server: raw, bypass };
  }
}

export function playwrightIgnoreHttpsErrors(): boolean {
  return envBool('PLAYWRIGHT_IGNORE_HTTPS_ERRORS');
}

/** Extra command-line flags for `@playwright/mcp` derived from the proxy settings. */
export function playwrightMcpProxyArgs(): string[] {
  const proxy = playwrightProxy();
  const args: string[] = [];
  if (proxy) {
    args.push('--proxy-server', proxy.server);
    if (proxy.bypass) args.push('--proxy-bypass', proxy.bypass);
  }
  if (playwrightIgnoreHttpsErrors()) args.push('--ignore-https-errors');
  return args;
}

// ---------------------------------------------------------------------------
// Copilot CLI model selection
// ---------------------------------------------------------------------------

/**
 * `--model` flag for Copilot CLI. COPILOT_MODEL_<STAGE> overrides COPILOT_MODEL.
 * Empty or "auto" means: do not pass --model and let Copilot CLI choose (its default/auto).
 */
export function copilotModelArgs(stage?: string): string[] {
  const stageKey = stage ? `COPILOT_MODEL_${stage.replace(/[A-Z]/g, m => `_${m}`).toUpperCase()}` : '';
  const model = (stageKey && first(stageKey)) || first('COPILOT_MODEL');
  if (!model || model.toLowerCase() === 'auto') return [];
  return ['--model', model];
}
