"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const runtime_env_1 = require("./runtime-env");
(0, runtime_env_1.initRuntime)(); // loads the root .env, applies proxy settings
const test_1 = require("@playwright/test");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
async function getExistingReferences(api, root, folderId) {
    const response = await api.get(`${root}/test-case-folders/${folderId}/content?page=0&size=2000`);
    if (!response.ok()) {
        throw new Error(`Failed to read existing Squash test cases in folder ${folderId}: HTTP ${response.status()} ${await response.text()}`);
    }
    const body = await response.json();
    const content = Array.isArray(body?._embedded?.content)
        ? body._embedded.content
        : Array.isArray(body?.content) ? body.content : [];
    return new Set(content
        .map((tc) => String(tc?.reference || '').trim().toUpperCase())
        .filter(Boolean));
}
async function uploadSquashTestCases() {
    const args = process.argv.slice(2);
    const jsonFilePath = args[0];
    if (!jsonFilePath) {
        console.error('❌ Error: Please provide the path to the generated JSON payload file.');
        console.log('Usage: npx ts-node utils/upload-squash.ts test-scenarios/squash/testcase_<ISSUE_ID>.json');
        process.exit(1);
    }
    // Pick token from command args OR environment variables (.env file)
    const bearerToken = args[1] || process.env.SQUASH_BEARER_TOKEN || '';
    const baseUrl = (0, runtime_env_1.squashTestCasesUrl)();
    if (!bearerToken) {
        console.error('❌ Error: SQUASH_BEARER_TOKEN is missing in your .env file.');
        process.exit(1);
    }
    const resolvedPath = path.resolve(jsonFilePath);
    if (!fs.existsSync(resolvedPath)) {
        console.error(`❌ Error: JSON payload file not found at path: ${resolvedPath}`);
        process.exit(1);
    }
    const rawData = fs.readFileSync(resolvedPath, 'utf-8');
    const testCases = JSON.parse(rawData);
    console.log(`🚀 Found ${testCases.length} test case(s) in ${path.basename(jsonFilePath)}`);
    console.log(`🌐 Target Endpoint: ${baseUrl}\n`);
    const apiContext = await test_1.request.newContext({
        proxy: (0, runtime_env_1.playwrightProxy)(),
        extraHTTPHeaders: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${bearerToken}`
        }
    });
    const folderIds = [...new Set(testCases
            .map(tc => Number(tc.parent?.id))
            .filter(id => Number.isInteger(id) && id > 0))];
    if (folderIds.length !== 1) {
        throw new Error(`Expected all uploaded test cases to target one Squash Test Case Folder; found ${folderIds.length} folder(s).`);
    }
    const existingReferences = await getExistingReferences(apiContext, baseUrl.replace(/\/+$/, '').replace(/\/test-cases$/i, ''), folderIds[0]);
    let successCount = 0;
    let skippedCount = 0;
    let failureCount = 0;
    for (let i = 0; i < testCases.length; i++) {
        const payload = testCases[i];
        const ref = payload.reference || `Index-${i + 1}`;
        const normalizedRef = String(ref).trim().toUpperCase();
        if (existingReferences.has(normalizedRef)) {
            console.log(`[${i + 1}/${testCases.length}] Keeping existing ${ref}: "${payload.name}" (no delete/recreate).`);
            skippedCount++;
            continue;
        }
        console.log(`[${i + 1}/${testCases.length}] Uploading new ${ref}: "${payload.name}"...`);
        try {
            const response = await apiContext.post(baseUrl, { data: payload });
            if (response.status() === 200 || response.status() === 201) {
                const responseData = await response.json();
                console.log(`  ✅ Successfully created ${ref} (Squash ID: ${responseData.id || 'N/A'})`);
                successCount++;
            }
            else {
                console.error(`  ❌ Failed to upload ${ref}. Status Code: ${response.status()}`);
                console.error(`     Response: ${await response.text()}`);
                failureCount++;
            }
        }
        catch (err) {
            console.error(`  💥 Exception while uploading ${ref}:`, err);
            failureCount++;
        }
    }
    await apiContext.dispose();
    console.log('\n========================================');
    console.log(`📊 Upload Summary: ${successCount} Successful | ${skippedCount} Existing Kept | ${failureCount} Failed`);
    console.log('========================================');
    if (failureCount > 0)
        process.exit(1);
}
uploadSquashTestCases();
