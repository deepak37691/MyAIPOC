"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROJECT_ROOT = void 0;
exports.envBool = envBool;
exports.resolveFromRoot = resolveFromRoot;
exports.loadEnvFile = loadEnvFile;
exports.applyProxyEnv = applyProxyEnv;
exports.proxyConfigured = proxyConfigured;
exports.initRuntime = initRuntime;
exports.gitlabApiUrl = gitlabApiUrl;
exports.gitlabMcpEnv = gitlabMcpEnv;
exports.squashApiRoot = squashApiRoot;
exports.squashTestCasesUrl = squashTestCasesUrl;
exports.playwrightProxy = playwrightProxy;
exports.playwrightIgnoreHttpsErrors = playwrightIgnoreHttpsErrors;
exports.playwrightMcpProxyArgs = playwrightMcpProxyArgs;
exports.copilotModelArgs = copilotModelArgs;
/**
 * Central runtime configuration, driven by the single `.env` file in the project root.
 *
 * Every part of the project (Control Center server, Squash utilities, Playwright config,
 * Copilot agent runner, MCP servers) should read its settings through this module so that
 * GitLab, Squash, Playwright MCP, proxy and model settings live in ONE place.
 *
 * Secrets (GitLab token, Squash bearer token) are deliberately NOT handled here: the
 * Control Center keeps them in memory only (entered through the UI).
 */
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const node_tls_1 = __importDefault(require("node:tls"));
const node_http_1 = __importDefault(require("node:http"));
exports.PROJECT_ROOT = node_path_1.default.resolve(__dirname, '..');
const DEFAULT_NO_PROXY = ['localhost', '127.0.0.1', '::1'];
let initialised = false;
function first(...names) {
    for (const name of names) {
        const value = process.env[name];
        if (value !== undefined && value.trim() !== '')
            return value.trim();
    }
    return '';
}
function envBool(name, fallback = false) {
    const value = process.env[name];
    if (value === undefined || value.trim() === '')
        return fallback;
    return /^(1|true|yes|on)$/i.test(value.trim());
}
/** Resolve a path from .env relative to the project root (absolute paths are kept). */
function resolveFromRoot(p) {
    return node_path_1.default.isAbsolute(p) ? p : node_path_1.default.resolve(exports.PROJECT_ROOT, p);
}
// ---------------------------------------------------------------------------
// .env loading + proxy / certificate normalisation
// ---------------------------------------------------------------------------
function loadEnvFile() {
    try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const dotenv = require('dotenv');
        dotenv.config({ path: node_path_1.default.join(exports.PROJECT_ROOT, '.env'), quiet: true });
    }
    catch { /* dotenv missing: rely on the real environment */ }
}
/**
 * Make the proxy settings consistent for every tool we spawn:
 *  - HTTP(S)_PROXY / NO_PROXY in both upper and lower case (Node tools, Copilot CLI, git, curl)
 *  - npm_config_* so `npx -y @zereight/mcp-gitlab` / `@playwright/mcp` can download packages
 *  - NODE_EXTRA_CA_CERTS as an absolute path (corporate TLS-inspecting proxies)
 * localhost is always added to NO_PROXY so local Squash / the UI itself never go via the proxy.
 */
function applyProxyEnv() {
    const httpsProxy = first('HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy');
    const httpProxy = first('HTTP_PROXY', 'http_proxy', 'HTTPS_PROXY', 'https_proxy');
    if (httpsProxy) {
        process.env.HTTPS_PROXY = process.env.https_proxy = httpsProxy;
        process.env.npm_config_https_proxy = httpsProxy;
    }
    if (httpProxy) {
        process.env.HTTP_PROXY = process.env.http_proxy = httpProxy;
        process.env.npm_config_proxy = httpProxy;
    }
    const allProxy = first('ALL_PROXY', 'all_proxy');
    if (allProxy)
        process.env.ALL_PROXY = process.env.all_proxy = allProxy;
    // Only touch NO_PROXY when a proxy is actually configured, so a local-only setup is unchanged.
    if (httpsProxy || httpProxy || allProxy) {
        const existing = first('NO_PROXY', 'no_proxy').split(',').map(s => s.trim()).filter(Boolean);
        const merged = [...new Set([...existing, ...DEFAULT_NO_PROXY])].join(',');
        process.env.NO_PROXY = process.env.no_proxy = merged;
        process.env.npm_config_noproxy = merged;
    }
    const ca = first('NODE_EXTRA_CA_CERTS');
    if (ca) {
        const abs = resolveFromRoot(ca);
        if (node_fs_1.default.existsSync(abs)) {
            process.env.NODE_EXTRA_CA_CERTS = abs;
        }
        else {
            console.warn(`[env] NODE_EXTRA_CA_CERTS points to a file that does not exist (${abs}); ignoring it.`);
            delete process.env.NODE_EXTRA_CA_CERTS;
        }
    }
}
function proxyConfigured() {
    return !!first('HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy', 'ALL_PROXY', 'all_proxy');
}
/**
 * Node's built-in fetch ignores HTTP(S)_PROXY. When a proxy is configured, route the
 * global fetch through it (honouring NO_PROXY). Uses `undici` (declared dependency);
 * falls back to http.setGlobalProxyFromEnv() on Node versions that have it.
 */
function installFetchProxy() {
    if (!proxyConfigured())
        return;
    // Extra CA bundle for the *current* process (NODE_EXTRA_CA_CERTS is only read at Node start-up).
    let ca;
    const caFile = process.env.NODE_EXTRA_CA_CERTS;
    if (caFile && node_fs_1.default.existsSync(caFile)) {
        ca = [...node_tls_1.default.rootCertificates, node_fs_1.default.readFileSync(caFile, 'utf8')];
    }
    try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const undici = require('undici');
        const tlsOptions = ca ? { ca } : undefined;
        undici.setGlobalDispatcher(new undici.EnvHttpProxyAgent({
            ...(tlsOptions ? { connect: tlsOptions, requestTls: tlsOptions, proxyTls: tlsOptions } : {})
        }));
        return;
    }
    catch { /* undici not installed */ }
    const anyHttp = node_http_1.default;
    if (typeof anyHttp.setGlobalProxyFromEnv === 'function') {
        anyHttp.setGlobalProxyFromEnv();
        return;
    }
    console.warn('[env] A proxy is configured but neither "undici" nor Node >= 22.21 is available, so API calls made by this process will NOT use the proxy. Run "npm install" to install undici.');
}
/** Load .env, normalise proxy settings, and route fetch through the proxy. Safe to call many times. */
function initRuntime() {
    if (initialised)
        return;
    initialised = true;
    loadEnvFile();
    applyProxyEnv();
    installFetchProxy();
}
// ---------------------------------------------------------------------------
// GitLab
// ---------------------------------------------------------------------------
function gitlabApiUrl() {
    return (first('GITLAB_API_URL') || 'https://gitlab.com/api/v4').replace(/\/+$/, '');
}
/** Environment passed to the GitLab MCP server (token is added by the caller). */
function gitlabMcpEnv() {
    return {
        GITLAB_API_URL: gitlabApiUrl(),
        GITLAB_READ_ONLY_MODE: first('GITLAB_READ_ONLY_MODE') || 'false',
        USE_GITLAB_WIKI: first('USE_GITLAB_WIKI') || 'true',
        ...(first('GITLAB_PERMISSION_MODE') ? { GITLAB_PERMISSION_MODE: first('GITLAB_PERMISSION_MODE') } : {}),
        ...(envBool('GITLAB_MCP_DEBUG') ? { DEBUG: 'true' } : {})
    };
}
// ---------------------------------------------------------------------------
// Squash TM
// ---------------------------------------------------------------------------
const DEFAULT_SQUASH_API_ROOT = 'http://localhost:8080/squash/api/rest/latest';
/** API root, e.g. http://host:8080/squash/api/rest/latest (a trailing /test-cases is tolerated). */
function squashApiRoot() {
    return (first('SQUASH_BASE_URL') || DEFAULT_SQUASH_API_ROOT).replace(/\/+$/, '').replace(/\/test-cases$/i, '');
}
function squashTestCasesUrl() {
    return `${squashApiRoot()}/test-cases`;
}
/**
 * Proxy for browsers / API contexts launched by Playwright. PLAYWRIGHT_PROXY_SERVER wins;
 * otherwise the general HTTPS_PROXY / HTTP_PROXY is reused. Returns undefined when no proxy is set.
 */
function playwrightProxy() {
    const raw = first('PLAYWRIGHT_PROXY_SERVER', 'HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy');
    if (!raw)
        return undefined;
    const bypass = (first('PLAYWRIGHT_PROXY_BYPASS', 'NO_PROXY', 'no_proxy') || DEFAULT_NO_PROXY.join(','))
        .split(',').map(s => s.trim()).filter(Boolean).join(',');
    try {
        const url = new URL(raw);
        const username = decodeURIComponent(url.username);
        const password = decodeURIComponent(url.password);
        url.username = '';
        url.password = '';
        return {
            server: url.toString().replace(/\/$/, ''),
            bypass,
            ...(username ? { username, password } : {})
        };
    }
    catch {
        return { server: raw, bypass };
    }
}
function playwrightIgnoreHttpsErrors() {
    return envBool('PLAYWRIGHT_IGNORE_HTTPS_ERRORS');
}
/** Extra command-line flags for `@playwright/mcp` derived from the proxy settings. */
function playwrightMcpProxyArgs() {
    const proxy = playwrightProxy();
    const args = [];
    if (proxy) {
        args.push('--proxy-server', proxy.server);
        if (proxy.bypass)
            args.push('--proxy-bypass', proxy.bypass);
    }
    if (playwrightIgnoreHttpsErrors())
        args.push('--ignore-https-errors');
    return args;
}
// ---------------------------------------------------------------------------
// Copilot CLI model selection
// ---------------------------------------------------------------------------
/**
 * `--model` flag for Copilot CLI. COPILOT_MODEL_<STAGE> overrides COPILOT_MODEL.
 * Empty or "auto" means: do not pass --model and let Copilot CLI choose (its default/auto).
 */
function copilotModelArgs(stage) {
    const stageKey = stage ? `COPILOT_MODEL_${stage.replace(/[A-Z]/g, m => `_${m}`).toUpperCase()}` : '';
    const model = (stageKey && first(stageKey)) || first('COPILOT_MODEL');
    if (!model || model.toLowerCase() === 'auto')
        return [];
    return ['--model', model];
}
