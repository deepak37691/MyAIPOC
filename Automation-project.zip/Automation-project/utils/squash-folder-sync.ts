import { request, APIRequestContext } from '@playwright/test';

export interface SquashFolderSyncOptions {
  baseUrl: string;
  token: string;
  folderId: number;
  replaceFolder?: boolean;
  replacementFolderName?: string;
}

export interface SquashFolderSyncResult {
  folderId: number;
  folderName: string;
  projectId?: number;
  projectName?: string;
  existed: boolean;
  replaced: boolean;
  deletedTestCases: Array<{ id: number; reference?: string; name?: string }>;
}

function apiRoot(baseUrl: string): string {
  return baseUrl.replace(/\/+$/, '').replace(/\/test-cases\/?$/i, '');
}

async function readJson(response: any): Promise<any> {
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

function assertOk(response: any, operation: string, body: any): void {
  if (response.status() < 200 || response.status() >= 300) {
    const detail = typeof body === 'string' ? body : JSON.stringify(body);
    throw new Error(`Squash ${operation} failed (${response.status()}): ${detail.slice(0, 1000)}`);
  }
}

async function getFolder(api: APIRequestContext, root: string, folderId: number): Promise<any> {
  const response = await api.get(`${root}/test-case-folders/${folderId}`);
  const body = await readJson(response);
  assertOk(response, `GET test case folder ${folderId}`, body);
  return body;
}

async function getFolderContents(api: APIRequestContext, root: string, folderId: number): Promise<any[]> {
  const all: any[] = [];
  let url: string | null = `${root}/test-case-folders/${folderId}/content?page=0&size=2000`;

  for (let guard = 0; url && guard < 100; guard++) {
    const response = await api.get(url);
    const body = await readJson(response);
    assertOk(response, `GET test case folder ${folderId} contents`, body);

    const embedded = body?._embedded?.content;
    if (Array.isArray(embedded)) all.push(...embedded);

    const next = body?._links?.next?.href;
    url = typeof next === 'string' && next ? next : null;
    if (url && /^https?:\/\//i.test(url)) {
      // Squash may return an absolute URL. Keep the configured server as the authority
      // and only reuse the API path so local/proxy host differences do not break sync.
      const parsed = new URL(url);
      url = `${root}${parsed.pathname.split('/api/rest/latest').pop() || ''}${parsed.search}`;
      if (!url.startsWith(root)) url = `${root}/test-case-folders/${folderId}/content${parsed.search}`;
    }
  }

  return all;
}

async function deleteTestCases(api: APIRequestContext, root: string, testCases: any[], log?: (message: string) => void) {
  const deletable = testCases
    .filter(tc => Number.isFinite(Number(tc?.id)))
    .map(tc => ({ id: Number(tc.id), reference: tc.reference, name: tc.name }));

  for (const tc of deletable) {
    const response = await api.delete(`${root}/test-cases/${tc.id}`);
    const body = await readJson(response);
    assertOk(response, `DELETE test case ${tc.id}`, body);
    log?.(`Deleted existing Squash test case ${tc.reference || tc.id}: "${tc.name || ''}"`);
  }
  return deletable;
}

/**
 * Validates the configured folder through Squash's REST API.
 *
 * By default the folder is reused. This is intentionally safer than deleting and
 * recreating a folder because Squash documents that deleting a folder deletes its
 * contents as well.
 *
 * When replaceFolder=true, the existing folder is deleted and a new folder with the
 * same name is created under the same project. The returned folderId is the new id.
 */
export async function syncSquashTestCaseFolder(
  options: SquashFolderSyncOptions,
  log?: (message: string) => void
): Promise<SquashFolderSyncResult> {
  const root = apiRoot(options.baseUrl);
  const api = await request.newContext({
    extraHTTPHeaders: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${options.token}`
    }
  });

  try {
    log?.(`Checking Squash Test Case Folder ${options.folderId} with GET /test-case-folders/${options.folderId}...`);
    const folder = await getFolder(api, root, options.folderId);

    const originalFolderId = Number(folder.id);
    const originalName = String(folder.name || `Automation Folder ${originalFolderId}`);
    const projectId = Number(folder.project?.id || folder.parent?.id || 0) || undefined;
    const projectName = folder.project?.name || folder.parent?.name;

    log?.(`Squash folder exists: ${originalFolderId} "${originalName}"${projectId ? ` (project ${projectId})` : ''}.`);

    if (options.replaceFolder) {
      if (!projectId) {
        throw new Error(`Squash folder ${originalFolderId} does not expose a project id; cannot safely recreate it.`);
      }

      log?.(`Replacing Squash folder ${originalFolderId}. DELETE /test-case-folders/${originalFolderId} will also delete its contents.`);
      const deleteResponse = await api.delete(`${root}/test-case-folders/${originalFolderId}`);
      const deleteBody = await readJson(deleteResponse);
      assertOk(deleteResponse, `DELETE test case folder ${originalFolderId}`, deleteBody);

      const newName = options.replacementFolderName?.trim() || originalName;
      const createResponse = await api.post(`${root}/test-case-folders`, {
        data: {
          _type: 'test-case-folder',
          name: newName,
          description: 'Created by Automation Project Squash synchronization.',
          parent: { _type: 'project', id: projectId }
        }
      });
      const created = await readJson(createResponse);
      assertOk(createResponse, 'POST test case folder', created);
      const newId = Number(created.id);
      if (!newId) throw new Error(`Squash created the replacement folder but did not return an id.`);

      log?.(`Created replacement Squash folder ${newId} "${newName}".`);
      return {
        folderId: newId,
        folderName: newName,
        projectId,
        projectName,
        existed: true,
        replaced: true,
        deletedTestCases: []
      };
    }

    // Idempotent mode: keep the folder, but remove only the test cases that this
    // upload is about. The caller can then POST the approved payload without
    // accumulating duplicate references on repeated runs.
    const contents = await getFolderContents(api, root, originalFolderId);
    return {
      folderId: originalFolderId,
      folderName: originalName,
      projectId,
      projectName,
      existed: true,
      replaced: false,
      deletedTestCases: contents.map(tc => ({ id: Number(tc.id), reference: tc.reference, name: tc.name }))
    };
  } finally {
    await api.dispose();
  }
}


export async function getSquashTestCasesByReference(
  options: { baseUrl: string; token: string; folderId: number; references: string[] }
): Promise<Array<{ id: number; reference?: string; name?: string }>> {
  const root = apiRoot(options.baseUrl);
  const wanted = new Set(options.references.map(x => String(x).trim().toUpperCase()).filter(Boolean));
  if (!wanted.size) return [];

  const api = await request.newContext({
    extraHTTPHeaders: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${options.token}`
    }
  });

  try {
    const contents = await getFolderContents(api, root, options.folderId);
    return contents
      .filter(tc => wanted.has(String(tc.reference || '').trim().toUpperCase()))
      .filter(tc => Number.isFinite(Number(tc?.id)))
      .map(tc => ({ id: Number(tc.id), reference: tc.reference, name: tc.name }));
  } finally {
    await api.dispose();
  }
}

export async function removeSquashTestCasesByReference(
  options: { baseUrl: string; token: string; folderId: number; references: string[] },
  log?: (message: string) => void
): Promise<Array<{ id: number; reference?: string; name?: string }>> {
  const root = apiRoot(options.baseUrl);
  const wanted = new Set(options.references.map(x => String(x).trim().toUpperCase()).filter(Boolean));
  if (!wanted.size) return [];

  const api = await request.newContext({
    extraHTTPHeaders: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${options.token}`
    }
  });

  try {
    const contents = await getFolderContents(api, root, options.folderId);
    const matches = contents.filter(tc => wanted.has(String(tc.reference || '').trim().toUpperCase()));
    return await deleteTestCases(api, root, matches, log);
  } finally {
    await api.dispose();
  }
}
