import { expect, type Page } from '@playwright/test';

export class DemoblazePage {
  constructor(
    private readonly page: Page,
    private readonly baseUrl: string,
  ) {}

  async openHomePage(): Promise<void> {
    await this.page.goto(this.baseUrl);
    await expect(this.page).toHaveURL(/demoblaze\.com/);
  }

  async openProduct(productName: string): Promise<void> {
    await this.page.getByRole('link', { name: productName, exact: true }).click();
  }

  async openCart(): Promise<void> {
    await this.page.getByRole('link', { name: /^Cart$/i, exact: true }).click();
  }

  async waitForCartPage(): Promise<void> {
    await expect(this.page).toHaveURL(/\/cart\.html$/);
  }
}
