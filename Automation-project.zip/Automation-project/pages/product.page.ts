import { expect, type Page } from '@playwright/test';

export class ProductPage {
  constructor(private readonly page: Page) {}

  async expectProductVisible(productName: string): Promise<void> {
    await expect(this.page.getByRole('heading', { name: productName, level: 2 })).toBeVisible();
  }

  async addToCartAndAcceptAlert(alertText: string): Promise<void> {
    const dialogPromise = this.page.waitForEvent('dialog');
    await this.page.getByRole('button', { name: 'Add to cart', exact: true }).click();

    const dialog = await dialogPromise;
    expect(dialog.message()).toBe(alertText);
    await dialog.accept();
  }

  async openCart(): Promise<void> {
    await this.page.getByRole('link', { name: /^Cart$/i, exact: true }).click();
  }
}
