import { expect, type Page } from '@playwright/test';

export interface BuyerDetails {
  name: string;
  country: string;
  city: string;
  creditCard: string;
  month: string;
  year: string;
}

export interface ConfirmationData {
  confirmationTitle: string;
  expectedTotal: string;
  currency: string;
}

export class CartPage {
  constructor(private readonly page: Page) {}

  async expectCartContainsProduct(productName: string, expectedPrice: string): Promise<void> {
    const row = this.page.locator('tbody tr').filter({ has: this.page.getByRole('cell', { name: productName, exact: true }) });

    await expect(row).toBeVisible();
    await expect(row).toContainText(productName);
    await expect(row).toContainText(expectedPrice);
  }

  async openPlaceOrderModal(): Promise<void> {
    await this.page.getByRole('button', { name: 'Place Order', exact: true }).click();

    const dialog = this.page.getByRole('dialog').filter({ has: this.page.getByRole('heading', { name: /Place order/i }) });
    await expect(dialog).toBeVisible();
  }

  async completeCheckout(details: BuyerDetails): Promise<void> {
    const modal = this.page.getByRole('dialog').filter({ has: this.page.getByRole('heading', { name: /Place order/i }) });

    await modal.getByRole('textbox', { name: /Name/i }).fill(details.name);
    await modal.getByRole('textbox', { name: /Country/i }).fill(details.country);
    await modal.getByRole('textbox', { name: /City/i }).fill(details.city);
    await modal.getByRole('textbox', { name: /Credit card/i }).fill(details.creditCard);
    await modal.getByRole('textbox', { name: /Month/i }).fill(details.month);
    await modal.getByRole('textbox', { name: /Year/i }).fill(details.year);
  }

  async submitPurchase(): Promise<void> {
    await this.page.getByRole('button', { name: 'Purchase', exact: true }).click();
  }

  async expectConfirmation(data: ConfirmationData): Promise<void> {
    const dialog = this.page.getByRole('dialog').filter({ has: this.page.getByRole('heading', { name: data.confirmationTitle }) });

    await expect(dialog).toBeVisible();

    const confirmationText = await dialog.textContent();
    expect(confirmationText).toBeTruthy();
    expect(confirmationText).toMatch(/Id:\s*\d+/i);
    expect(confirmationText).toContain(data.expectedTotal);
    expect(confirmationText).toContain(data.currency);
  }

  async closeConfirmation(): Promise<void> {
    await this.page.getByRole('button', { name: 'OK', exact: true }).click();
  }
}
