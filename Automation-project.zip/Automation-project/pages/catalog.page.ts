import type { Locator, Page } from '@playwright/test';

export class CatalogPage {
  readonly productNames: Locator;

  constructor(private readonly page: Page) {
    this.productNames = page.locator('#tbodyid').getByRole('link', { name: /.+/ });
  }

  async selectCategory(category: string): Promise<void> {
    const responsePromise = this.page.waitForResponse((response) =>
      response.url().endsWith('/bycat'),
    );
    await this.page.getByRole('link', { name: category, exact: true }).click();

    const response = await responsePromise;
    if (!response.ok()) {
      throw new Error(`Category request failed with status ${response.status()}`);
    }
  }
}
