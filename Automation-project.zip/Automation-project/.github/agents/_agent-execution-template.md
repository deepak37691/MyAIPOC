---
name: _agent-execution-template
description: Standard 5-step execution workflow and workflow variations used by all agents
---

<!--
  WHAT THIS FILE IS
  The universal 5-step workflow every agent follows (parse -> process -> generate -> validate -> report),
  plus the three common workflow variations. NOT an executable agent.

  Status names, gate handling, error formats and the report layout live in _agent-shared-context.md
  and are intentionally NOT repeated here.
-->

# Standard Agent Execution Workflow

Every agent follows the same five steps. Outcome names, gate handling, error formats and the report
layout are defined in [_agent-shared-context.md](./_agent-shared-context.md).

---

## The 5 Steps

### Step 1: PARSE INPUT
- Identify the input file (paths: see shared context) and confirm it exists and is readable
- Extract required parameters (`ISSUE_ID`, `folder_id`, ...)
- Report and abort if the input is missing or malformed

### Step 2: PROCESS WITH BUSINESS LOGIC
- Apply the agent-specific filtering, transformation or analysis rules
- Validate inputs against the agent's constraints
- Generate output incrementally and report progress concisely

### Step 3: GENERATE OUTPUT
- Create or update every required output file; files must be non-empty and well-formed (valid JSON / Markdown)
- Report the file locations

### Step 4: VALIDATE ARTIFACTS
- Re-open each generated file and confirm its structure and format (JSON parse, Markdown sections, TypeScript compile)
- Report the validation result; abort if validation fails

### Step 5: GATE VERIFICATION & REPORTING
- Report completion with a standard outcome
- Pause for user approval or input when the pipeline requires it, stating exactly what the user must decide
- Hand off to the next stage or request a revision

---

## Workflow Variations

### Agents with user pauses (business reviewer, test strategy, test healer, gitlab committer)
1. Parse input  2. Process logic  3. Generate a proposal (not the final artifact)
4. **Pause for user approval**  5. Apply or finalize only the approved result  6. Validate and report

### Conditional agents (test healer, defect reporter)
1. Parse the failure context  2. If there is no failure: report "nothing to do" and stop
3. Otherwise run the diagnosis/report logic  4. Validate the result  5. Report

### Agents with integrations (squash-user, squash-test-case-execution, gitlab-committer, defect-reporter)
1. Parse input  2. Call the external API / tool  3. Validate the response  4. Report success or failure and request a retry if needed

---

## Progress Logging

- Do log: parsed X items, generated Y file, validated Z conditions, file paths, decision points
- Do not log: a screenshot of every interaction, verbose DOM dumps, internal variable state, raw API responses (unless there is an error)

---

## Success Criteria

An agent has completed successfully when:

- the input was parsed without errors and the business logic applied correctly
- the output files exist, are non-empty and pass validation
- the status was reported with a standard outcome and the user/orchestrator knows the next action

---

## See Also

- [_agent-shared-context.md](./_agent-shared-context.md) - pipeline, paths, outcomes, gates, errors, reports
- [_agent-templates.md](./_agent-templates.md) - output templates
- [test-orchestrator-agent.md](./test-orchestrator-agent.md) - master orchestrator workflow
