---
name: _agent-execution-template
description: Standard execution workflow pattern used by all agents
---

# Standard Agent Execution Workflow

This file describes the universal 5-step execution pattern used by all agents in the automation pipeline.

---

## Universal 5-Step Execution Pattern

Every agent follows this identical workflow structure:

### Step 1: PARSE INPUT
**Action**: Identify and validate input

- Identify input file from designated source (see _agent-shared-context.md)
- Validate file exists and is accessible
- Extract required parameters (ISSUE_ID, folder_id, etc.)
- Report and abort if input missing or malformed

**Example**:
```
Agent reads: test-scenarios/scenarios/2.md
Extracted: ISSUE_ID=2, folder_id=1
Status: Input valid, proceeding
```

---

### Step 2: PROCESS WITH BUSINESS LOGIC
**Action**: Apply agent-specific decision rules and validation

- Apply agent-specific filtering, transformation, or analysis rules
- Validate inputs against agent constraints
- Generate output incrementally
- Report progress (concise, no unnecessary details)

**Example** (for test-strategy agent):
```
Processing 25 scenarios from input file...
Filtering: 18 AUTOMATE (E2E), 7 OFFLOAD (Unit/API)
Building decision matrix...
```

---

### Step 3: GENERATE OUTPUT
**Action**: Create or update required output files

- Create/update all required file(s) per agent specification
- Ensure files are non-empty with meaningful content
- Ensure output is well-formed (valid JSON/Markdown)
- Report file locations to user

**Example**:
```
Generated: test-scenarios/strategy/2-strategy-proposal.md (1,200 bytes)
Status: File created successfully
```

---

### Step 4: VALIDATE ARTIFACTS
**Action**: Verify generated files meet specifications

- Open and read each generated file
- Confirm content matches expected structure
- Validate file format (JSON parsing, Markdown structure)
- Report validation results
- Report and abort if validation fails

**Example**:
```
Validating: test-scenarios/strategy/2-strategy-proposal.md
✓ File exists and is readable
✓ Markdown structure valid
✓ Decision matrix contains 25 rows
✓ All required fields present
Validation: PASSED
```

---

### Step 5: GATE VERIFICATION & REPORTING
**Action**: Report outcome and hand off control

- Report completion status using standard decision outcomes (see _agent-shared-context.md)
- Pause for user approval/input if required by pipeline rules
- Specify decision required (what user must choose)
- Hand off to next stage or request revision

**Example**:
```
Status: READY_FOR_APPROVAL

Decision Required: User must approve test case selection via UI.
- Select test cases to automate
- Unselect non-E2E candidates
- Click "Approve" to continue

Next Step: Awaiting user decision in Automation Control Center.
```

---

## Gate Handling Rules (All Agents)

| Scenario | Action | Outcome |
|----------|--------|---------|
| **Input file missing** | Report specific error with path | ABORT |
| **Input ambiguous or invalid** | Pause; ask user for clarification | NEEDS_REVISION |
| **Output validation fails** | Report error with details | ABORT |
| **User revision requested** | Re-run agent with feedback | NEEDS_REVISION |
| **Healing required** (if applicable) | Route to test-healer | NEEDS_HEALING |
| **All validations pass** | Proceed to next stage | READY_FOR_NEXT_STAGE |

---

## Orchestrator Communication Pattern

When handing off to orchestrator or pausing for user decision:

### Required Report Fields

1. **Generated File Locations** (exact paths)
   ```
   Generated:
   - test-scenarios/strategy/2-strategy-proposal.md
   - test-scenarios/squash/testcase_2.json
   ```

2. **Status** (one of standard outcomes)
   ```
   Status: READY_FOR_NEXT_STAGE
   ```

3. **Blockers** (any errors or validation failures)
   ```
   Blockers: None
   ```

4. **Decision Required** (if pausing for user)
   ```
   Decision Required: None (auto-proceeding to next stage)
   ```

### Example Complete Report
```
─────────────────────────────────────
Generated Files:
  - test-scenarios/strategy/2-strategy-proposal.md (1.2 KB)
  - test-scenarios/squash/testcase_2.json (4.5 KB)

Status: READY_FOR_APPROVAL

Validation Results:
  ✓ Files created successfully
  ✓ Markdown structure valid
  ✓ JSON format valid
  ✓ All required fields present

Decision Required: 
  User must review and approve test case selection:
  - 18 test cases recommended for E2E automation
  - 7 test cases recommended for Unit/API testing
  - Approve selection via Automation Control Center UI checkbox

Blockers: None

Next Step: Awaiting user approval
─────────────────────────────────────
```

---

## Error Handling Best Practices

### How to Report Errors
```
Error: [specific description]
File: [path/to/file]
Reason: [why it failed]
Action: [ABORT or NEEDS_REVISION]
Next Step: [what user must do]
```

### Example Error Report
```
Error: Input strategy file not found
File: test-scenarios/strategy/2-strategy.md
Reason: Agent test-strategy was not yet invoked for this issue
Action: ABORT
Next Step: Please run @test-strategy agent before invoking this agent
```

---

## Progress Logging Guidelines

Log concisely in control-center logs:
- ✓ Do log: Parsed X items, generated Y file, validated Z conditions
- ✗ Don't log: Screenshot of every interaction, verbose DOM inspection
- ✓ Do report: File paths, validation results, decision points
- ✗ Don't report: Internal variable states, raw API responses (unless error)

---

## Standard Workflow Variations

### Agents with User Pauses
Some agents pause for user approval:
1. Parse input
2. Process logic
3. Generate proposal (not final)
4. **Pause for user approval**
5. User approves in UI
6. Validate approved output
7. Report completion

### Conditional Agents (Healing)
Some agents run conditionally based on previous results:
1. Parse test results
2. If PASS: Skip to next stage
3. If FAIL: Execute healing logic
4. Validate healed output
5. Re-run tests
6. Report results

### Agents with Integrations
Some agents call external APIs:
1. Parse strategy
2. Call Squash API to upload test cases
3. Validate API response
4. Report success/failure
5. Proceed or request retry

---

## Timing & Timeouts

- **Parse Input**: < 1 second
- **Process Logic**: 1-30 seconds (depends on agent complexity)
- **Generate Output**: < 5 seconds
- **Validate Artifacts**: < 2 seconds
- **Report Status**: < 1 second
- **User Decision Window**: Open-ended (agent waits)

Total execution: Typically 5-60 seconds (excluding user wait time)

---

## Success Criteria

An agent has successfully completed when:

- ✅ Input file parsed without errors
- ✅ Business logic applied correctly
- ✅ Output files created and non-empty
- ✅ Output files pass validation
- ✅ Status reported using standard outcome
- ✅ User/orchestrator notified of next action

---

## See Also

- **[_agent-shared-context.md](./_agent-shared-context.md)** - Standard definitions
- **[_agent-templates.md](./_agent-templates.md)** - Output templates
- **[test-orchestrator-agent.md](./test-orchestrator-agent.md)** - Master orchestrator workflow

