---
name: _agent-templates
description: Reference templates for test data, Page Objects, test specs and Squash JSON produced by the agents
---

<!--
  WHAT THIS FILE IS
  Reference templates for the artifacts the agents generate. NOT an executable agent.
  The DemoBlaze flow is only an ILLUSTRATION of the structure - every locator and value must be
  re-verified against the live application (Playwright MCP) before it is written.

  The templates follow the rules of script-generator-agent.md:
    - test inputs live in test-data/issue-[ISSUE_ID].json, never in the POM or spec
    - Page Objects contain locators and actions only; assertions (expect) live ONLY in the spec
    - roles come from the live accessibility tree (DemoBlaze's "Add to cart" is a link, not a button)
    - native dialogs are handled inside the same action that triggers them
-->

# Standard Output Templates

---

## 1. Test Data JSON

**File**: `test-data/issue-[ISSUE_ID].json`
**Purpose**: Externalize every test input, keyed by scenario ID, so specs and POMs contain no hardcoded values.

```json
{
  "baseUrl": "https://www.demoblaze.com",
  "TC-001": {
    "productName": "Samsung galaxy s6",
    "expectedUrl": "prod.html",
    "expectedPrice": "360",
    "alertText": "Product added"
  },
  "TC-002": {
    "productName": "Nokia lumia 1520",
    "alertText": "Product added",
    "buyer": {
      "name": "John Doe",
      "country": "USA",
      "city": "San Francisco",
      "creditCard": "1234567890123456",
      "month": "12",
      "year": "2030"
    },
    "confirmationTitle": "Thank you for your purchase!"
  }
}
```

**Rules**
- Externalize ALL input parameters; organize by TC ID; use descriptive key names
- Include every field the action methods and assertions need
- Never store real credentials or secrets (use environment variables); only obviously fake demo values

---

## 2. Page Object Model (POM)

**File**: `pages/<PageName>.page.ts`
**Purpose**: Encapsulate locators and actions. Imported by the spec.

```typescript
import { type Locator, type Page } from '@playwright/test';

export interface Buyer {
  name: string;
  country: string;
  city: string;
  creditCard: string;
  month: string;
  year: string;
}

export class DemoblazePage {
  constructor(
    private readonly page: Page,
    private readonly baseUrl: string,
  ) {}

  async openHomePage(): Promise<void> {
    await this.page.goto(this.baseUrl);
  }

  async openProduct(productName: string): Promise<void> {
    await this.page.getByRole('link', { name: productName, exact: true }).click();
  }

  async openCart(): Promise<void> {
    await this.page.getByRole('link', { name: 'Cart', exact: true }).click();
  }
}

export class ProductPage {
  constructor(private readonly page: Page) {}

  heading(productName: string): Locator {
    return this.page.getByRole('heading', { name: productName });
  }

  /** The dialog handler is attached in the same action as the click; the message is returned for the spec to assert. */
  async addToCartAndAcceptAlert(): Promise<string> {
    const [dialog] = await Promise.all([
      this.page.waitForEvent('dialog'),
      this.page.getByRole('link', { name: 'Add to cart' }).click(), // role verified live: this is a link
    ]);
    const message = dialog.message();
    await dialog.accept();
    return message;
  }
}

export class CartPage {
  constructor(private readonly page: Page) {}

  row(productName: string): Locator {
    return this.page.getByRole('row').filter({ hasText: productName });
  }

  async openPlaceOrderModal(): Promise<void> {
    await this.page.getByRole('button', { name: 'Place Order' }).click();
  }

  async fillOrderForm(buyer: Buyer): Promise<void> {
    await this.page.getByLabel('Name:').fill(buyer.name);
    await this.page.getByLabel('Country:').fill(buyer.country);
    await this.page.getByLabel('City:').fill(buyer.city);
    await this.page.getByLabel('Credit card:').fill(buyer.creditCard);
    await this.page.getByLabel('Month:').fill(buyer.month);
    await this.page.getByLabel('Year:').fill(buyer.year);
  }

  async submitPurchase(): Promise<void> {
    await this.page.getByRole('button', { name: 'Purchase' }).click();
  }

  confirmationHeading(title: string): Locator {
    return this.page.getByRole('heading', { name: title });
  }

  async closeConfirmation(): Promise<void> {
    await this.page.getByRole('button', { name: 'OK' }).click();
  }
}
```

**Rules**
- Prefer `getByRole`, `getByLabel`, `getByTestId`, `getByText`, `getByPlaceholder`; avoid CSS (`#id`, `.class`) and XPath
- Methods take typed data objects, never hardcoded values
- Return `Locator`s (or observed values such as a dialog message) so the spec can assert on them
- **NO assertions (`expect`) in a POM** - assertions belong in the spec
- Methods are `async` and return `Promise`; JSDoc is optional but recommended

---

## 3. Test Spec

**File**: `tests/issue-[ISSUE_ID].spec.ts`
**Purpose**: Data-driven scenarios. Imports the POMs and the test data; owns every assertion.

```typescript
import { test, expect } from '@playwright/test';

import issueData from '../test-data/issue-2.json';
import { CartPage, DemoblazePage, ProductPage, type Buyer } from '../pages/demoblaze.page';

const appData = issueData as {
  baseUrl: string;
  'TC-001': { productName: string; expectedUrl: string; expectedPrice: string; alertText: string };
  'TC-002': { productName: string; alertText: string; buyer: Buyer; confirmationTitle: string };
};

test.describe('Issue #2: Demoblaze checkout flow', () => {
  test('TC-001: add a product and verify the cart row and price', async ({ page }) => {
    const home = new DemoblazePage(page, appData.baseUrl);
    const product = new ProductPage(page);
    const cart = new CartPage(page);
    const data = appData['TC-001'];

    await home.openHomePage();
    await home.openProduct(data.productName);
    await expect(page).toHaveURL(new RegExp(data.expectedUrl));
    await expect(product.heading(data.productName)).toBeVisible();

    expect(await product.addToCartAndAcceptAlert()).toContain(data.alertText);

    await home.openCart();
    await expect(page).toHaveURL(/cart\.html$/);
    await expect(cart.row(data.productName)).toContainText(data.expectedPrice);
  });

  test('TC-002: complete checkout with valid purchase details', async ({ page }) => {
    const home = new DemoblazePage(page, appData.baseUrl);
    const product = new ProductPage(page);
    const cart = new CartPage(page);
    const data = appData['TC-002'];

    await home.openHomePage();
    await home.openProduct(data.productName);
    expect(await product.addToCartAndAcceptAlert()).toContain(data.alertText);
    await home.openCart();

    await cart.openPlaceOrderModal();
    await cart.fillOrderForm(data.buyer);
    await cart.submitPurchase();
    await expect(cart.confirmationHeading(data.confirmationTitle)).toBeVisible();
    await cart.closeConfirmation();
  });
});
```

**Rules**
- Import the test data JSON with a type cast; create one POM instance per page
- Group with `test.describe`; one test per scenario named `TC-XXX: scenario description`
- Read data by TC ID and pass the data objects to the POM methods
- **Assertions in the spec only**

---

## 4. Squash Test Case JSON

**File**: `test-scenarios/squash/testcase_[ISSUE_ID].json`
**Purpose**: Squash TM REST payload - a JSON **array** of test-case objects, uploaded by `utils/upload-squash.ts`.
In the Control Center this file is built by code (`utils/sync-approved-squash.ts`) from the approved strategy and scenarios;
the schema below is also what the `@squash-user` agent must produce when it is run manually.

```json
[
  {
    "_type": "test-case",
    "name": "TC-001: Add product to cart",
    "reference": "TC-001",
    "prerequisite": "Application is reachable.",
    "description": "<p>Verify adding a product to the cart shows the correct row and price.</p>",
    "importance": "VERY_HIGH",
    "status": "WORK_IN_PROGRESS",
    "parent": { "_type": "test-case-folder", "id": 1 },
    "steps": [
      {
        "_type": "action-step",
        "action": "<p>Open the home page and click the product link.</p>",
        "expected_result": "<p>The product detail page shows the correct name and price.</p>"
      },
      {
        "_type": "action-step",
        "action": "<p>Click \"Add to cart\" and open the Cart page.</p>",
        "expected_result": "<p>The cart lists the product with the correct price.</p>"
      }
    ]
  }
]
```

**Rules**
- Payload is an array of test-case objects, never a single object
- Required: `_type`, `name`, `reference` (TC ID), `importance`, `status`, `parent` (`test-case-folder` + folder id), `steps`
- `importance` is one of `LOW`, `MEDIUM`, `HIGH`, `VERY_HIGH` (P0 → VERY_HIGH, P1 → HIGH, otherwise MEDIUM)
- `description`, `action` and `expected_result` are HTML (`<p>`, `<ul>`, `<li>`), not Markdown
- The strategy proposal carries a plain `folder_id` field per candidate; it becomes `parent.id` here

---

## Validation Checklist

- ✅ Test data: valid JSON, contains every TC ID and every field the spec reads
- ✅ Page Objects: import Playwright, role-based locators, no assertions
- ✅ Specs: import POMs and test data, one test per TC, assertions present
- ✅ Squash JSON: valid JSON array, all required fields, HTML formatting

---

## See Also

- [_agent-shared-context.md](./_agent-shared-context.md) - paths, outcomes, gates
- [_agent-execution-template.md](./_agent-execution-template.md) - 5-step workflow
- [script-generator-agent.md](./script-generator-agent.md) - detailed generator rules
