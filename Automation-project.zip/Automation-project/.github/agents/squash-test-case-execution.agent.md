---
name: squash-test-case-execution
description: Creates and executes a Squash TM execution plan from every test case in the configured Test Case Folder.
argument-hint: [ISSUE_ID]
---

<!--
  PURPOSE   : Builds the SquashTM execution hierarchy (Execution Folder > Campaign > Iteration > optional Test Suite >
              test plan > executions), sets each execution to SUCCESS/FAILURE from the Playwright result and attaches
              the HTML report as suite evidence.
  PIPELINE  : Stage 7 of 8 - after Test Execution has a terminal result; independent of the Test Healer.
  RUN MODE  : DETERMINISTIC code, not an LLM: utils/execution/upload-squash-execution.ts (stage "squashExecution"
              in the Control Center). This file documents the contract that code must keep.
  INPUT     : Test Case Folder ID, Execution Folder / Campaign / Iteration / optional Suite names (from the UI),
              the Squash token (runtime secret) and the Playwright results.
  OUTPUT    : Squash execution entities + test-scenarios/squash/execution_[ISSUE_ID].json (audit artifact).
-->

# Role: Squash Test Case Execution Agent

Create the SquashTM Executions workspace hierarchy through the REST API. This agent is deterministic and must not use an LLM for API construction.

## Inputs
- Test Case Folder ID from the Automation Control Center UI.
- Execution Folder Name from the UI.
- Campaign Name from the UI.
- Iteration Name from the UI.
- Optional Test Suite Name from the UI.
- Squash API token from the runtime secret.

## Flow
1. Read the Test Case Folder and resolve its owning project.
2. Retrieve all test cases contained by that folder.
3. Create an Execution Folder under the project.
4. Create a Campaign under the execution folder.
5. Create an Iteration under the campaign.
6. If a suite name was supplied, reuse an existing suite with that name under the iteration; otherwise create it with `POST /test-suites`.
7. Add every test case from the configured Test Case Folder to the iteration execution plan, reusing an existing plan item when that test case is already present.
8. If a suite is used, associate only test cases that are not already in the suite plan.
9. Create an execution for every resulting test-plan item.
10. Set each created Squash execution to SUCCESS when the corresponding Playwright test passed, or FAILURE when it failed.
11. Attach the generated Playwright `playwright-report/execution-<SESSION_ID>/index.html` as suite evidence after converting it to a `.txt` file, because Squash suite evidence is stored as text.
12. Persist `test-scenarios/squash/execution_[ISSUE_ID].json` as an audit artifact.

## API contract
The SquashTM documentation confirms campaign creation at `POST /api/rest/latest/campaigns`, iteration creation at `POST /api/rest/latest/campaigns/{campaign_id}/iterations`, and adding cases to an iteration at `POST /api/rest/latest/iterations/{iterationId}/test-plan`. The execution-specific endpoint is implemented through the Squash REST execution API with compatibility fallback in `utils/execution/upload-squash-execution.ts`.

## Safety
- Never create or delete test cases in this agent.
- Never modify or delete the configured Test Case Folder.
- Fail clearly when the folder is empty or the project cannot be resolved.
- Do not mark a Squash execution successful unless its source Playwright result is explicitly passed/success/completed.
- Report evidence conversion and attachment failures instead of silently ignoring them.
- Do not silently fall back to a different folder.
