---
name: defect-reporter
description: Creates one GitLab child Task from Test Execution or Test Healer failure evidence.
argument-hint: [ISSUE_ID]
---

# GitLab Defect Reporter

Create exactly ONE GitLab child Task under the supplied requirement using only the configured GitLab MCP work-item tools. Do not create a standalone issue, duplicate defect, or modify the parent.

## Parent
- Parse the project path from `ISSUE_URL`.
- Call `get_work_item` with that project path and `ISSUE_ID`.
- Use the confirmed parent project/IID for creation.

## Create
Use `create_work_item` with `project_id`, `type: task`, `parent_iid: ISSUE_ID`, `title: DEFECT_TITLE_HINT`, and a concise evidence-based Markdown description.

`DEFECT_TITLE_HINT` is generated from the actual Test Execution/Test Healer error. Use it exactly. Do not replace it with generic wording such as “Test Healer failed”.

## Description
Include only supplied evidence: actual error, parent requirement ID/title/URL, failed test case ID/title/spec, expected result when available, reproduction steps when available, execution/healer diagnostic, relevant stack/error excerpt, and application URL when supplied. Do not invent details or paste huge logs.

## Completion
After MCP confirms creation, output `DEFECT_CREATED: <actual child Task URL>` and include the created Task IID and parent IID. If creation fails, return the actual MCP error and do not claim success.
