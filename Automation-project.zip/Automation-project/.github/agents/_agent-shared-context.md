---
name: _agent-shared-context
description: Shared definitions, file paths, and standard rules for all automation agents
---

# Shared Agent Context & Definitions

This file contains standard definitions and constraints shared across all automation agents.

---

## Standard File Path Patterns

All agents use these consistent conventions for input and output:

### Input Files
- **Test Strategy**: `test-scenarios/strategy/[ISSUE_ID]-strategy.md`
- **Test Scenarios**: `test-scenarios/scenarios/[ISSUE_ID].md`
- **Business Review**: `test-scenarios/business-review/issue-[ISSUE_ID]-business-review.md`
- **Test Results**: `test-results/[ISSUE_ID].json`

### Output Files
- **Squash Test Cases**: `test-scenarios/squash/testcase_[ISSUE_ID].json`
- **Squash Execution**: `test-scenarios/squash/execution_[ISSUE_ID].json`
- **Test Data**: `test-data/<PageName>.json`
- **Page Objects**: `pages/<PageName>.page.ts`
- **Test Specs**: `tests/issue-[ISSUE_ID].spec.ts`

---

## Standard Decision Outcomes

All agents report completion using one of these outcomes:

- **READY_FOR_NEXT_STAGE**: Output is valid; proceed to next stage
- **NEEDS_REVISION**: User must provide feedback or fixes before continuing
- **NEEDS_HEALING**: Route to test-healer agent for diagnosis and repair
- **ABORT**: Stop immediately; report critical blocker preventing progress

---

## Gate Verification Rules

Before proceeding to the next stage, all agents must:

1. **Confirm file existence**: Expected output file exists on disk
2. **Validate format**: File is valid JSON (if JSON) or parseable Markdown
3. **Report blockers**: If files missing or invalid, report specific errors

---

## Standard Parameter Extraction

When parsing agent arguments `[ISSUE_ID or GitLab URL]`:

- **GitLab URL**: Extract numeric ID from URL path
  - Example: `https://gitlab.com/.../issues/2` → `2`
- **Direct ID**: Accept direct issue ID
  - Example: `2` or `issue-2` → `2`
- **Folder ID**: Extract `--folder-id FOLDER_ID` if present
  - Default: `1` if not specified

---

## Common Agent Constraints

All agents must follow these fundamental rules:

### Rule 1: No Assumptions
Never assume missing business logic, inputs, outcomes, acceptance criteria, or error behavior. If not stated or explicitly inferable, flag as missing or ambiguous.

### Rule 2: Flag Subjective Language
Challenge vague terms like "fast", "easy", "intuitive", "responsive", "robust". Demand measurable thresholds or observable behavior.

### Rule 3: Testability First
Confirm that all expectations (inputs, actions, outcomes, error states) are observable and verifiable without guessing.

### Rule 4: Consistency Matters
Flag contradictions, mutually incompatible statements, or inconsistent terminology in requirements.

### Rule 5: Do Not Simulate Approval
Only the user can make gate decisions. Never simulate approval, modify final files prematurely, or bypass user gates.

### Rule 6: Handle Ambiguity
When requirements are ambiguous:
- Pause execution
- Ask user for clarification
- Do NOT guess or invent missing business logic

---

## Upstream/Downstream Agent References

### Full Pipeline Order
1. **business-requirements-reviewer** → reads GitLab issue
2. **test-scenarios** → reads issue, outputs scenarios
3. **test-strategy** → reads scenarios, outputs strategy proposal
4. **script-generator** → reads strategy, outputs code/data
5. **test-healer** → (conditional) reads test results, diagnoses issues
6. **squash-user** → reads strategy, uploads to Squash
7. **squash-test-case-execution** → reads strategy, creates executions
8. **gitlab-committer** → commits files to GitLab

### Key Handoffs
- business-requirements-reviewer → test-scenarios: Approval required
- test-strategy → script-generator: Strategy file must exist
- script-generator → (test-healer OR squash-user): Test results determine path
- squash-user → squash-test-case-execution: Both read from same strategy

---

## Error Handling Patterns

### Input Errors
```
"Error: input file [path] does not exist"
→ Report error and ABORT
→ Do not create placeholder or guess content
```

### Ambiguous Requirements
```
"Ambiguity: requirement does not specify [detail]"
→ Pause execution
→ Ask user: "Please clarify [detail]"
→ Wait for user input before continuing
```

### Validation Failures
```
"Error: output [path] failed validation: [reason]"
→ Report specific failure reason
→ Do not proceed to next stage
→ Return ABORT status
```

### User Revisions
```
"User requested revision: [feedback]"
→ Re-run previous stage with feedback
→ Do not skip steps
→ Report when revision complete
```

---

## Communication Guidelines

When reporting to orchestrator or user:

1. **File Locations**: Always include full paths to generated files
2. **Status**: Use standard decision outcomes above
3. **Blockers**: Describe any errors or validation failures clearly
4. **Decisions Needed**: If pausing, state exactly what user must decide
5. **Progress**: Report progress in control-center logs (concise, no screenshots unless required)

### Example Report
```
Generated files:
  - test-scenarios/strategy/2-strategy-proposal.md

Status: READY_FOR_APPROVAL

Decision Required: User must select test cases via Automation Control Center UI.

Blockers: None

Next Step: Awaiting user checkbox approval from UI.
```

---

## Version & Compatibility

- **Current Version**: 33 (Optimized)
- **Shared Context Version**: 1.0
- **Last Updated**: September 26, 2026
- **Compatible Agents**: All 9 automation agents

See [CHANGELOG.md](../../CHANGELOG.md) for version history.

