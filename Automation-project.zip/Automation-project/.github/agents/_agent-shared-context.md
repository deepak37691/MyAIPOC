---
name: _agent-shared-context
description: Shared definitions, pipeline order, file paths, decision outcomes, gate rules and error/report formats for all automation agents
---

<!--
  WHAT THIS FILE IS
  The single source of truth for everything the agents have in common: pipeline order, file paths,
  decision outcomes, gate rules, parameter parsing, constraints and error/report formats.
  It is NOT an executable agent - each agent links here instead of repeating this content.

  Companion files:  _agent-execution-template.md (5-step workflow)   _agent-templates.md (output templates)

  MAINTENANCE: if you change a path, an outcome name or the pipeline order, change it HERE and in the
  matching code (automation-ui/src/server.ts) - the code is the runtime source of truth for paths.
-->

# Shared Agent Context & Definitions

---

## Pipeline Order & Run Mode

The Automation Control Center runs the stages in this order. "LLM agent" stages are executed through
`automation-ui/agent-runner.js` (GitHub Copilot CLI) using the agent file as instructions; "deterministic"
stages are plain backend code and do not call an LLM.

| # | Agent handle | Run mode in the Control Center | Main output |
| --- | --- | --- | --- |
| 1 | `@business-requirements-reviewer` | LLM agent (issue content is supplied by the backend) | `test-scenarios/business-review/issue-[ISSUE_ID]-business-review.md` |
| 2 | `@create-scenarios` | LLM agent | `test-scenarios/scenarios/[ISSUE_ID].md` |
| 3 | `@test-strategy` | LLM agent writes the proposal; approval and the final file are handled by the backend | `…/strategy/[ISSUE_ID]-strategy-proposal.md`, then `…/strategy/[ISSUE_ID]-strategy.md` |
| 4 | `@squash-user` | Deterministic (`utils/sync-approved-squash.ts`); the agent file is used only for chat/manual runs | `test-scenarios/squash/testcase_[ISSUE_ID].json` |
| 5 | `@script-generator` | LLM agent (Playwright MCP, generate-only) | test data, Page Objects, spec |
| 6 | Test Execution, then `@test-healer` / `@defect-reporter` on failure | Execution = direct Playwright CLI (no agent); healer and defect reporter = LLM agents | `test-results/…`, `playwright-report/…` |
| 7 | `@squash-test-case-execution` | Deterministic (`utils/execution/upload-squash-execution.ts`) | `test-scenarios/squash/execution_[ISSUE_ID].json` |
| 8 | `@gitlab-committer` | Deterministic (git commands in the backend) | branch `test/issue-[ISSUE_ID]-e2e` |

`@test-orchestrator` is the chat-only master agent that drives stages 1-8 in sequence.

### Key handoffs
- business-requirements-reviewer → create-scenarios: explicit user approval required
- test-strategy → squash-user / script-generator: the approved `-strategy.md` must exist (both read the same file)
- script-generator → Test Execution → test-healer: only when the execution reports failures
- test-healer → defect-reporter: only when the approved repair fails
- Test Execution → squash-test-case-execution: any terminal result; the healer is never a prerequisite

---

## Standard File Path Patterns

### Inputs / reviews / strategy
- **Business Review**: `test-scenarios/business-review/issue-[ISSUE_ID]-business-review.md`
- **Test Scenarios**: `test-scenarios/scenarios/[ISSUE_ID].md`
- **Strategy proposal** (agent output): `test-scenarios/strategy/[ISSUE_ID]-strategy-proposal.md`
- **Approved strategy** (written by the backend after UI approval): `test-scenarios/strategy/[ISSUE_ID]-strategy.md`

### Generated automation
- **Test Data**: `test-data/issue-[ISSUE_ID].json`
- **Page Objects**: `pages/<PageName>.page.ts`
- **Test Specs**: `tests/issue-[ISSUE_ID].spec.ts`

### Squash and results
- **Squash Test Cases**: `test-scenarios/squash/testcase_[ISSUE_ID].json`
- **Squash Execution audit**: `test-scenarios/squash/execution_[ISSUE_ID].json`
- **Test Results**: `test-results/[ISSUE_ID].json` (chat flow). The Control Center writes
  `test-results/execution-<SESSION_ID>.json` and `playwright-report/execution-<SESSION_ID>/index.html`.

---

## Standard Decision Outcomes

All agents report completion using one of these outcomes:

- **READY_FOR_NEXT_STAGE**: Output is valid; proceed to the next stage
- **READY_FOR_APPROVAL**: Proposal is valid; the user must approve before the pipeline continues
- **NEEDS_REVISION**: User must provide feedback or fixes before continuing
- **NEEDS_HEALING**: Route to test-healer for diagnosis and repair
- **ABORT**: Stop immediately; report the critical blocker

---

## Gate Verification Rules

Before proceeding to the next stage, every agent must:

1. **Confirm file existence**: the expected output file exists on disk
2. **Validate format**: valid JSON (if JSON) or parseable Markdown
3. **Report blockers**: if files are missing or invalid, report the specific error

| Situation | Action | Outcome |
| --- | --- | --- |
| Input file missing | Report the exact path | ABORT |
| Input ambiguous or invalid | Pause and ask the user | NEEDS_REVISION |
| Output validation fails | Report error with details | ABORT |
| User requests a revision | Re-run the previous stage with the feedback | NEEDS_REVISION |
| Healing required (execution failures) | Route to test-healer | NEEDS_HEALING |
| Proposal ready, user decision needed | Stop and state the decision required | READY_FOR_APPROVAL |
| All validations pass | Proceed | READY_FOR_NEXT_STAGE |

---

## Standard Parameter Extraction

When parsing agent arguments `[ISSUE_ID or GitLab URL]`:

- **GitLab URL**: extract the numeric ID from the URL path (`https://gitlab.com/.../issues/2` → `2`)
- **Direct ID**: accept `2` or `issue-2` → `2`
- **Folder ID**: extract `--folder-id FOLDER_ID` if present (default `1`). This is the Squash Test Case Folder ID.

---

## Common Agent Constraints

### Rule 1: No Assumptions
Never assume missing business logic, inputs, outcomes, acceptance criteria or error behavior. If it is not stated or explicitly inferable, flag it as missing or ambiguous.

### Rule 2: Flag Subjective Language
Challenge vague terms such as "fast", "easy", "intuitive", "responsive", "robust". Demand measurable thresholds or observable behavior.

### Rule 3: Testability First
Confirm that all expectations (inputs, actions, outcomes, error states) are observable and verifiable without guessing.

### Rule 4: Consistency Matters
Flag contradictions, mutually incompatible statements or inconsistent terminology in requirements.

### Rule 5: Do Not Simulate Approval
Only the user can make gate decisions. Never simulate approval, modify final files prematurely or bypass user gates.

### Rule 6: Handle Ambiguity
When requirements are ambiguous: pause, ask the user for clarification, and do NOT guess or invent missing business logic.

---

## Error Handling Patterns

Use this format for every error report:

```
Error: [specific description]
File: [path/to/file]
Reason: [why it failed]
Action: [ABORT or NEEDS_REVISION]
Next Step: [what the user must do]
```

| Error type | Message | Behaviour |
| --- | --- | --- |
| Input error | `Error: input file [path] does not exist` | Report and ABORT; never create placeholders or guess content |
| Ambiguous requirement | `Ambiguity: requirement does not specify [detail]` | Pause, ask `Please clarify [detail]`, wait for the answer |
| Validation failure | `Error: output [path] failed validation: [reason]` | Report the reason, do not proceed, ABORT |
| User revision | `User requested revision: [feedback]` | Re-run the previous stage with the feedback; do not skip steps |

---

## Communication Guidelines

When reporting to the orchestrator or user:

1. **File locations**: always include full paths to generated files
2. **Status**: use the standard decision outcomes above
3. **Blockers**: describe errors or validation failures clearly
4. **Decisions needed**: if pausing, state exactly what the user must decide
5. **Progress**: concise Control Center log lines (parsed X, generated Y, validated Z); no screenshots or raw API responses unless there is an error

### Example report
```
Generated files:
  - test-scenarios/strategy/2-strategy-proposal.md (1.2 KB)

Status: READY_FOR_APPROVAL

Validation:
  ✓ File exists and Markdown structure is valid
  ✓ Decision matrix contains every evaluated scenario

Decision Required: User must select the test cases to automate in the Automation Control Center UI.

Blockers: None
```

---

## Version & Compatibility

- **Project Version**: 33 (Optimized)
- **Last Updated**: October 4, 2026
- **Compatible Agents**: all 10 agents in this folder

See [CHANGELOG.md](../../CHANGELOG.md) for version history.
