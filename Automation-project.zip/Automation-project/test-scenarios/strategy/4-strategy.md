# E2E Test Strategy: Issue #4

- **Issue Reference**: #4
- **Target Folder ID**: 1
- **Generated Date**: 2026-09-27
- **Application Base URL**: https://www.demoblaze.com/
- **Approved for E2E Automation**: 1

## 1. Scope & Automation Decision Matrix

| Scenario ID | Scenario Description | Automation Decision | Tier / Frequency | Justification |
| :--- | :--- | :--- | :--- | :--- |
| **TC-001** | Filter the catalog to laptops and verify only laptop products are shown | **AUTOMATE (E2E)** | Smoke | User selected this case for final E2E automation approval. |

## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)

### Approved Test Cases

| Scenario ID | Test Case | Priority | Decision | Tier / Frequency |
| :--- | :--- | :--- | :--- | :--- |
| **TC-001** | Filter the catalog to laptops and verify only laptop products are shown | P0 | **AUTOMATE (E2E)** | Smoke |

### Candidate 1: TC-001 - Filter the catalog to laptops

| Field | Details |
| :--- | :--- |
| **Reference** | TC-001 |
| **Squash Folder ID** | 1 |
| **Importance (Squash Enum)** | VERY_HIGH |
| **Execution Tier** | Regression |
| **Prerequisite** |  |
| **Description** | Filter the catalog to laptops |

#### Test Steps

| # | Action | Expected Result |
| ---: | :--- | :--- |
| 1 | Navigate to `https://www.demoblaze.com`. | Verify the expected outcome for the action. |
| 2 | Wait for the initial product cards in `#tbodyid` to render. | Verify the expected outcome for the action. |
| 3 | Click the `Laptops` category link. | Verify the expected outcome for the action. |
| 4 | Wait for the category request to complete and for `#tbodyid` to render the laptop results; do not rely on a fixed delay or page navigation. | Verify the expected outcome for the action. |
| 5 | Inspect the visible product cards. | Verify the expected outcome for the action. |

## 3. Environment & Mocking Strategy
- **Base URL**: https://www.demoblaze.com/
- **Mocked Services**: None specified by the scenario artifact.
- **Cleanup Strategy**: Start each test in a fresh browser context and restore the application to a clean state after each scenario.