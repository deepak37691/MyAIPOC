# UI polish update

- Test Healer now says `Preparing the healing proposal for your review...` while the healer is generating a proposal.
- `Applying the approved repair...` is shown only after the healer proposal has been explicitly approved.
- Stage status, preview/action controls, and expand/collapse control are aligned on one consistent header row.
- Execution controls (Workers, Headless, Select all) share the same height, border, typography, and spacing.
- Stage messages are presented as compact supporting text instead of competing with primary controls.
- Mobile layouts keep the same visual hierarchy and allow action controls to wrap cleanly.
# UI spacing and healer timeout update

- Test Healer diagnosis timeout: 10 minutes by default.
- Approved repair timeout: 10 minutes by default.
- Optional environment overrides: `HEALER_DIAGNOSIS_TIMEOUT_MS` and `HEALER_REPAIR_TIMEOUT_MS`.
- Test-case ID and description now use a shared inline layout with consistent spacing in Execution and Test Healer.
- Execution rows, latest-result rows, and healer case rows use consistent horizontal gaps, padding, and typography.
- Section/group spacing was tightened so the test catalog, latest results, and healer content read as one consistent workflow.
