# Test Healer fixes

- Test Healer proposals are shown per test case with an independent **Approve** and **Reject** action.
- Approval applies only the selected test case's proposal.
- After approval, the Control Center runs that test exactly once for healer verification using the selected worker count and headed/headless mode.
- A test case becomes **passed** in the healer UI when healer verification passes.
- Worker count and headed mode are available in Test Healer and can be adjusted before each approval.
- Windows Copilot launching no longer concatenates proposal JSON into `cmd /c`, avoiding `The system cannot find the file specified.` errors caused by shell quoting.
- The existing Test Execution worker/headed options and failure report behavior are preserved.
- The TypeScript UI build passed before packaging.

The supplied `.env` was intentionally not included in this package; configure local secrets again using `.env.example`.
# Test Healer responsiveness fixes

- Diagnosis is now bounded to 60 seconds.
- Approved repair application is bounded to 90 seconds.
- The 5-second heartbeat was reduced to a 10-second status update to keep the activity log readable.
- The healer receives the exact failed-test context from the execution stage and no longer depends on a guessed `test-results/[ISSUE_ID].json` path.
- The healer prompt explicitly avoids broad repository/issue searches and repeated MCP exploration.
- GitLab MCP is not launched for the healer stage; healer work only needs local repository files and Playwright MCP.
- When a proposal is approved, the exact approved proposal is passed to the healer so it does not repeat diagnosis before applying it.
- Approved repair verification remains a single targeted verification pass.


Timeout update: Test Healer diagnosis and approved-repair phases now default to 10 minutes each. Override with HEALER_DIAGNOSIS_TIMEOUT_MS and HEALER_REPAIR_TIMEOUT_MS if needed.
# Agent runtime reliability

- All Copilot-backed stages have a 10-minute safety timeout by default (`AGENT_TIMEOUT_MS=600000`).
- Test Healer keeps separate 10-minute diagnosis/repair timeouts (`HEALER_DIAGNOSIS_TIMEOUT_MS`, `HEALER_REPAIR_TIMEOUT_MS`).
- Set `<STAGE>_AGENT_TIMEOUT_MS` for a stage-specific override, e.g. `SCENARIOS_AGENT_TIMEOUT_MS=600000`.
- The Activity Log emits a diagnostic heartbeat only after 30 seconds without child output; it no longer prints identical messages every 10 seconds.
- The scenario stage fetches the GitLab issue once in the backend and passes the title/description to the agent, avoiding a second GitLab MCP retrieval.
- MCP servers are stage-specific: scenarios/gitlab commit use GitLab MCP; script generation/healer use Playwright MCP; strategy and deterministic stages start no MCP server.
- Copilot auto-update is disabled for non-interactive runs to avoid startup delays.
