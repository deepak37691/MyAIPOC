# v10 Association Fix

Rebuilt directly from `Automation-project-patched-v9.zip`.

Changes:
- Preserve the v9 API flow; no speculative POST to `/test-suites/{id}/test-plan`.
- Broaden suite/test-plan response normalization to recognize `content`, `items`,
  `test_plan`, `testPlan`, `test_plan_items`, `testPlanItems`, `test-suites`, and
  `test_suites`.
- Recognize `referenced_test_case`, `referencedTestCase`, and `test_case` when
  identifying an iteration test-plan item.
- Keep test-case IDs separate from ITPI IDs.
- Add diagnostic context to the generic association failure where supported.

The package was rebuilt and verified as a readable ZIP archive.
# v17 Squash synchronization and Test Suite fix

## What changed

- Approved source test cases are now the only test cases sent into the current Squash execution run.
- Existing Squash test cases are matched by reference and reused/updated instead of creating another test case with the same reference.
- If the folder already contains multiple entries with the same reference, the synchronizer prefers an exact source-name match and reports the duplicate-reference group; it does not delete existing test cases.
- Stale/unselected iteration test-plan items are removed from the current iteration when possible. This removes old plan entries such as a previously synchronized TC-001 that is no longer part of the approved source set. Test cases, folders, campaigns, iterations and suites are not deleted.
- Suite association now tries suite-owned `test-plan-items` endpoints before the existing ITPI PATCH compatibility attempts and verifies the suite plan after each successful response.
- Suite association remains non-blocking for execution, but the code no longer silently treats an HTTP 200/no-op as a successful association.
- The Squash execution stage receives the exact synchronized test-case IDs/references, so unrelated/stale test cases already present in the folder are not copied into `Test_Cycle_1`.
- PASS/FAIL remains an execution result and is never used to decide synchronization.

## Existing resources preserved

The pipeline continues to reuse the existing Squash folder, campaign, iteration and `Functional` suite. It does not recreate that hierarchy.
# v18 Squash Functional-suite enforcement

## Target behavior

The execution stage now follows this order for the approved source test cases:

1. Reuse/update the existing Squash test case by stable reference (`TC-001`, `TC-002`, etc.).
2. Reuse the existing campaign, iteration, and `Functional` suite.
3. Reuse/create the iteration test-plan item for each synchronized test case.
4. Associate that ITPI with `Functional` and verify the relationship through the suite test plan.
5. Only after the suite membership is verified, create the Squash execution.

A successful HTTP `200` that leaves the suite test plan unchanged is **not** accepted as a successful association.

## Duplicate TC-001 handling

The approved source for Issue #2 contains:

- `TC-001`: Add Samsung galaxy s6 and verify its cart row and price
- `TC-002`: Complete checkout with valid purchase details and verify confirmation

The synchronization helper uses the test-case reference as the stable identity and prefers an exact source-name match when duplicate references already exist. The execution stage receives the exact synchronized test-case IDs, so unrelated/stale test cases in the folder are not copied into the current iteration.

Existing Squash hierarchy resources are reused; the code does not delete/recreate the folder, campaign, iteration, or `Functional` suite.

## Suite association compatibility attempts

Because the installed Squash REST instance previously returned HTTP 200/no-op for the attempted ITPI PATCH forms, v18 additionally probes these writable relation forms and verifies each one:

- `PUT /test-suites/{suiteId}/test-plan`
- `PUT /test-suites/{suiteId}/test-plan/{itpiId}`
- suite-owned `test-plan-items` routes
- `PATCH /test-suites/{suiteId}` with `test_plan` relation payloads
- the existing ITPI PATCH relation forms

If none of the supported forms creates a visible suite membership, the run stops before execution creation instead of producing another unassociated execution.

## PASS/FAIL behavior

Prior execution status is not used to decide whether the approved test cases are synchronized or whether an execution may be created. The external PASS/FAIL result is not copied into a newly created execution by this stage.
# v19 — Squash test-case PATCH / steps fix

## Problem

Squash returns HTTP 412 when an existing test case is updated through:

`PATCH /test-cases/{id}`

with a `steps` attribute. Squash explicitly rejects `steps` on the test-case patch and requires the direct steps entity URL.

## Fix

The synchronization flow now separates the operation into:

1. PATCH only test-case-owned metadata (`name`, `reference`, `description`, `prerequisite`, `importance`, `status`, etc.).
2. GET the existing test case and resolve its `steps` relation from `_links.steps` (with safe fallbacks).
3. PATCH existing step entities through each step's `_links.self` URL.
4. DELETE stale existing step entities when the new scenario has fewer steps.
5. POST missing steps to the test-case steps collection.
6. GET the test case again and verify the synchronized step count.

The synchronization still reuses an existing test case by its stable reference and does not delete/recreate the test case.
# V21 - Squash suite attachment API fix

## Change

Replaced the previous speculative suite-association requests with the documented SquashTM REST API operation:

`POST /test-suites/{testSuiteId}/test-plan/{ids}`

where `{ids}` is the existing iteration test-plan item ID.

For the current project this corresponds to:

`POST /test-suites/17/test-plan/37`

when the existing `Functional` suite is 17 and the existing ITPI is 37.

## Verification

The response is verified as the modified suite, followed by `GET /test-suites/{suiteId}/test-plan` if necessary. A successful HTTP status without visible membership is treated as an error.

## Preserved behavior

- Reuses existing Squash folders, campaigns, iterations, suites, test cases, and iteration plan items.
- Does not use previous PASS/FAIL status as a synchronization gate.
- Does not patch test-case `steps` through the test-case PATCH endpoint.
- Does not use the previously failing speculative suite endpoints.
