# Execution / Playwright Report Fixes

## What was verified

The execution stage is a direct Playwright CLI runner. It does **not** invoke an AI/Test Execution agent. The selected generated spec is launched with Node + `@playwright/test/cli`.

The uploaded project currently contains these Page Object files:

- `pages/demoblaze.page.ts`
- `pages/cart.page.ts`
- `pages/product.page.ts`

Therefore, the supplied `tests/issue-2.spec.ts` can legitimately load its `../pages/demoblaze.page` import in this project state.

## Changes

1. Removed the CLI `--reporter=json` override. The override was suppressing the HTML reporter configured in `playwright.config.ts`.
2. Execution now lets the Playwright config generate both:
   - JSON: `test-results/execution-<session>.json`
   - HTML: `playwright-report/execution-<session>/index.html`
3. The UI serves the full interactive Playwright HTML report and its relative assets from `/api/session/<session>/report/execution`.
4. Execution now verifies that `index.html` exists. A successful test run without an HTML report is treated as an execution failure instead of silently showing a non-Playwright preview.
5. Added execution preflight that recursively checks relative local imports from the selected spec. Missing files such as `../pages/demoblaze.page` now fail execution before Playwright starts and populate Test Healer with the impacted selected cases.
6. Execution logs now include the workspace path and exact absolute spec paths, making it clear which project is actually being executed.
7. The UI only enables the Playwright `Open Preview` link when the backend confirms that an HTML report URL exists.
8. Existing rerun behavior remains intact: completed/failed executions can be run again.

## Expected behavior when a Page Object is actually missing

For example, if `pages/demoblaze.page.ts` is absent when execution starts, the event log will show a preflight error similar to:

`Execution preflight found missing local imports: tests/issue-2.spec.ts -> ../pages/demoblaze.page`

The Execution stage becomes `FAILED`, the selected cases are placed in Test Healer as impacted cases, and Open Preview remains available only if Playwright actually produced a report.
# Squash TM synchronization changes

The Squash upload stage now verifies the configured Test Case Folder through the SquashTM REST API before uploading.

## API flow

1. `GET /test-case-folders/{id}` validates the configured folder and obtains its project/name.
2. The folder is reused by default.
3. `GET /test-case-folders/{id}/content?page=0&size=2000` checks the folder contents.
4. Existing test cases are read from the folder and matched by `reference`.
5. Existing matching test cases are kept in place; they are **not deleted or recreated**.
6. Only approved test cases whose references are not already present are uploaded with `POST /test-cases`.

This makes repeated uploads additive and idempotent: existing test cases are preserved and only genuinely new references are added.

## Optional full folder replacement

Set:

```env
SQUASH_REPLACE_FOLDER=true
```

When enabled, the existing folder is deleted with `DELETE /test-case-folders/{id}` and a replacement is created with `POST /test-case-folders`, using the same Squash project and folder name unless `SQUASH_REPLACEMENT_FOLDER_NAME` is set.

Squash's API documentation explicitly states that deleting a test-case folder also deletes its contents, so this mode is intentionally opt-in.

## Files changed

- `automation-ui/src/server.ts`
- `.env.example`

The implementation is based on SquashTM REST API 13.0.7.

## v16 - Synchronize before Squash execution

- `squashExecution` now performs an idempotent source-to-Squash synchronization before creating any Squash execution records.
- Approved test cases are transformed from the scenario artifact and POSTed to the existing Squash Test Case Folder only when their references do not already exist.
- Existing Squash test cases are reused; the flow does not delete/recreate the folder or test cases.
- The standalone `squash` stage uses the same idempotent synchronization helper, so repeated runs do not create duplicate test cases.
- Prior Playwright PASS/FAIL results are not used to decide whether test cases are synchronized or whether Squash executions are created.
- Squash suite association remains non-blocking; execution creation proceeds even if suite membership cannot be written by the installed Squash REST contract.
# UI and Runtime Fixes

- Activity Log **Clear log** now clears the persisted session events on the server, so the next poll does not restore old entries.
- Activity Log entries remain text-selectable and each individual entry has a Copy action.
- The application title is now **Automation QA Control Center** with a non-duplicated header label.
- Script Generation now validates that the generated Playwright spec exists, is non-empty, imports `@playwright/test`, and contains an executable test suite before the stage can be marked completed.
- Empty generated artifacts are reported as a stage failure instead of being treated as successful generation.
- Test Healer diagnosis/repair is time-bounded more tightly and its instructions explicitly prohibit broad repository searches, repeated MCP exploration, regeneration, or repeated healing loops.
- Squash Test Case Execution includes Playwright result -> Squash execution status mapping and suite evidence conversion from `index.html` to `.txt`.
