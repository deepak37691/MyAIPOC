# Deterministic Agent Reruns

## Business Requirements Review
An unchanged GitLab issue is now treated as the same review input. Rerunning the stage reuses the existing review artifact instead of invoking the LLM again. A new generation occurs only when the issue content changes or explicit business-review feedback is supplied.

## Test Scenarios
Scenario generation is keyed to the GitLab issue plus the Business Requirements Review artifact. If that source fingerprint is unchanged, the existing scenario document and IDs are reused.

## Test Strategy
Strategy generation is keyed to the current scenario artifact. If scenarios have not changed, the existing proposal or approved strategy is reused. The strategy agent is not invoked simply because the user clicked Start again.

## Test Script Generation
The generator now has stricter live-DOM evidence rules:
- never assume an element's semantic role;
- verify locator uniqueness from the accessibility tree/DOM;
- use observed modal semantics rather than assuming `role=dialog`;
- handle native dialogs as part of the triggering action;
- validate TypeScript and run Playwright's `--list` check before the stage is marked complete.

The supplied DemoBlaze suite also contained a concrete role mismatch: `Add to cart` was generated as a button locator although the application exposes it as a link. The POM was corrected.

## Test Healer
Healing starts with the supplied failure context and avoids browser exploration when the stack trace already establishes the root cause. Live MCP reconnaissance is limited to one targeted check unless the evidence is genuinely inconclusive. Diagnosis is bounded to 60 seconds by default; applying an approved repair is bounded to 300 seconds.
