import { test, expect } from '@playwright/test';

import issueData from '../test-data/issue-2.json';
import { CartPage } from '../pages/cart.page';
import { DemoblazePage } from '../pages/demoblaze.page';
import { ProductPage } from '../pages/product.page';

const appData = issueData as {
  baseUrl: string;
  'TC-001': {
    productName: string;
    expectedUrl: string;
    expectedPrice: string;
    alertText: string;
  };
  'TC-002': {
    productName: string;
    alertText: string;
    buyer: {
      name: string;
      country: string;
      city: string;
      creditCard: string;
      month: string;
      year: string;
    };
    expectedTotal: string;
    currency: string;
    confirmationTitle: string;
  };
};

test.describe('Issue #2: Demoblaze checkout flow', () => {
  test('TC-001: add Samsung galaxy s6 and verify cart row and price', async ({ page }) => {
    const homePage = new DemoblazePage(page, appData.baseUrl);
    const productPage = new ProductPage(page);
    const cartPage = new CartPage(page);
    const tc001 = appData['TC-001'];

    await homePage.openHomePage();
    await homePage.openProduct(tc001.productName);
    await expect(page).toHaveURL(new RegExp(tc001.expectedUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
    await productPage.expectProductVisible(tc001.productName);
    await productPage.addToCartAndAcceptAlert(tc001.alertText);

    await homePage.openCart();
    await homePage.waitForCartPage();
    await cartPage.expectCartContainsProduct(tc001.productName, tc001.expectedPrice);
  });

  test('TC-002: complete checkout with valid purchase details', async ({ page }) => {
    const homePage = new DemoblazePage(page, appData.baseUrl);
    const productPage = new ProductPage(page);
    const cartPage = new CartPage(page);
    const tc002 = appData['TC-002'];

    await homePage.openHomePage();
    await homePage.openProduct(tc002.productName);
    await productPage.addToCartAndAcceptAlert(tc002.alertText);
    await homePage.openCart();
    await homePage.waitForCartPage();

    await cartPage.openPlaceOrderModal();
    await cartPage.completeCheckout(tc002.buyer);
    await cartPage.submitPurchase();
    await cartPage.expectConfirmation({
      confirmationTitle: tc002.confirmationTitle,
      expectedTotal: tc002.expectedTotal,
      currency: tc002.currency,
    });
    await cartPage.closeConfirmation();

    await expect(page).toHaveURL(/demoblaze\.com\/index\.html$/);
  });
});
