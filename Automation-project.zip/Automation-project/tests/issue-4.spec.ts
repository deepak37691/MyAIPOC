import { expect, test } from '@playwright/test';

import issueData from '../test-data/issue-4.json';
import { CatalogPage } from '../pages/catalog.page';
import { DemoblazePage } from '../pages/demoblaze.page';

test.describe('Issue #4: filter the catalog to laptops', () => {
  test('TC-001: show only laptop products', async ({ page }) => {
    const scenario = issueData['TC-001'];
    const homePage = new DemoblazePage(page, issueData.baseUrl);
    const catalogPage = new CatalogPage(page);

    await homePage.openHomePage();
    await expect(catalogPage.productNames.first()).toBeVisible();

    await catalogPage.selectCategory(scenario.category);
    await expect(catalogPage.productNames).toHaveCount(scenario.expectedProducts.length);
    await expect(catalogPage.productNames).toHaveText(scenario.expectedProducts);
  });
});
