import { expect, test } from '@playwright/test';
import scenarioData from '../test-data/demoblaze.json';
import { DemoblazePage } from '../pages/demoblaze.page';

test.describe('Issue #2 - DemoBlaze cart and checkout', () => {
  test('TC-001 adds Samsung galaxy s6 and verifies its cart row and price', async ({ page }) => {
    const scenario = scenarioData['TC-001'];
    const demoblaze = new DemoblazePage(page);

    await demoblaze.open(scenario.baseUrl);
    await demoblaze.openProduct(scenario.productName);
    await expect.poll(() => {
      const url = new URL(page.url());
      return `${url.pathname}${url.search}`;
    }).toBe(scenario.productPath);
    await expect(page.getByRole('heading', { name: scenario.productName, exact: true })).toBeVisible();

    await expect(await demoblaze.addProductToCart({ productName: scenario.productName }))
      .toBe(scenario.addToCartAlert);

    await demoblaze.openCart();
    const row = demoblaze.productRow(scenario.productName);
    await expect(row).toHaveCount(1);
    await expect(row.getByText(scenario.cartPrice, { exact: true })).toBeVisible();
  });

  test('TC-102 rejects checkout when only Credit Card is missing', async ({ page }) => {
    const scenario = scenarioData['TC-102'];
    const demoblaze = new DemoblazePage(page);

    await demoblaze.open(scenario.baseUrl);
    await demoblaze.openProduct(scenario.productName);
    await expect(await demoblaze.addProductToCart({ productName: scenario.productName }))
      .toBe(scenario.addToCartAlert);
    await demoblaze.openCart();
    await demoblaze.openCheckout();
    await expect(demoblaze.orderModal).toBeVisible();

    await expect(await demoblaze.fillMissingCreditCardCheckout({ customerName: scenario.customerName }))
      .toBe(scenario.missingCreditCardAlert);
    await expect(demoblaze.orderModal).toBeVisible();
  });
});
