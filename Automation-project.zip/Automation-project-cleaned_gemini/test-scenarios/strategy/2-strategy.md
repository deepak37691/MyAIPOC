# E2E Test Strategy Proposal: Issue #2

- **Issue Reference**: [#2](https://gitlab.com/automation-group6313534/Automation-project/-/work_items/2)
- **Target Folder ID**: 1
- **Generated Date**: 2026-09-12
- **Application Base URL**: https://www.demoblaze.com/
- **Total Scenarios Analyzed**: 23
- **Agent Recommended for E2E Automation**: 15

---

- **Approved for E2E Automation**: 2

## 1. Scope & Automation Decision Matrix

| Scenario ID | Scenario Description | Automation Decision | Tier / Frequency | Justification |
| :--- | :--- | :--- | :--- | :--- |

---

| **TC-001** | Add Samsung galaxy s6 and verify its cart row and price | **AUTOMATE (E2E)** | Smoke / PR-Blocking | User selected this case for final E2E automation approval. |
| **TC-102** | Reject checkout when only Credit Card is missing | **AUTOMATE (E2E)** | Unit / API Level | User selected this case for final E2E automation approval. |

## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)

### Approved Test Cases

| Scenario ID | Test Case | Priority | Decision | Tier / Frequency |
| :--- | :--- | :--- | :--- | :--- |
| **TC-001** | Add Samsung galaxy s6 and verify its cart row and price | P0 | **AUTOMATE (E2E)** | Smoke / PR-Blocking |
| **TC-102** | Reject checkout when only Credit Card is missing | P1 | **AUTOMATE (E2E)** | Unit / API Level |

### Candidate 1: TC-001 - Add Samsung galaxy s6 to the cart

| Field | Details |
| :--- | :--- |
| **Reference** | TC-001 |
| **Squash Folder ID** | 1 |
| **Importance (Squash Enum)** | VERY_HIGH |
| **Execution Tier** | Regression |
| **Prerequisite** | **Steps**: 1. Navigate to `https://www.demoblaze.com/`. 2. Click the product card titled `Samsung galaxy s6`. 3. Verify the URL is `/prod.html?idp_=1` and the product title is `Samsung galaxy s6`. 4. Register a dialog handler and click `Add to cart`. 5. Verify the native alert text is exactly `Product added`, then accept it. 6. Click the `Cart` navigation link. **Expected Results**: The cart page loads and contains one row titled `Samsung galaxy s6` with price `360`; the cart is usable and no dialog remains open. |
| **Description** | Add Samsung galaxy s6 to the cart |

#### Test Steps

| # | Action | Expected Result |
| ---: | :--- | :--- |
| 1 | Execute the scenario: Add Samsung galaxy s6 to the cart. | The scenario behaves as specified in the source scenario document. |
### Candidate 2: TC-102 - Reject checkout when only Credit Card is missing

| Field | Details |
| :--- | :--- |
| **Reference** | TC-102 |
| **Squash Folder ID** | 1 |
| **Importance (Squash Enum)** | HIGH |
| **Execution Tier** | Regression |
| **Prerequisite** | **Steps**: 1. Enter Name `Jane Doe` and leave Credit Card empty. 2. Register a dialog handler and click `Purchase`. 3. Accept the validation alert. **Expected Results**: The exact `Please fill out Name and Creditcard.` alert is shown, no order confirmation appears, and the user can correct the form without losing the cart. |
| **Description** | Reject checkout when only Credit Card is missing |

#### Test Steps

| # | Action | Expected Result |
| ---: | :--- | :--- |
| 1 | Execute the scenario: Reject checkout when only Credit Card is missing. | The scenario behaves as specified in the source scenario document. |

## 3. Environment & Mocking Strategy

- **Base URL**: `https://www.demoblaze.com/`
- **Mocked Services**: None. Do not mock the DemoBlaze catalog, cart, or checkout for these functional scenarios; observe network activity only when diagnosing duplicate submissions.
- **Browser dialog handling**: Register a `dialog` listener before clicking `Add to cart` or `Purchase`, assert the message, and accept or dismiss every captured dialog.
- **Test isolation**: Prefer a fresh browser context for each scenario, with no open modal or dialog. Use a known empty cart before add-flow tests.
- **Cleanup Strategy**: After successful purchase, click confirmation `OK`; after rejected or cancelled flows, close the modal and leave the cart in a known state. Accept or dismiss all captured dialogs before teardown.
