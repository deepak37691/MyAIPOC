# E2E Test Strategy & Execution Plan: Issue #3

- **Issue Reference**: #3
- **Target Folder ID**: 1
- **Generated Date**: 2026-09-12
- **Application Base URL**: https://www.demoblaze.com/
- **Total Scenarios Analyzed**: 29
- **Approved for E2E Automation**: 5

## 1. Scope & Automation Decision Matrix

| Scenario ID | Scenario Description | Automation Decision | Tier / Frequency | Justification |
| :--- | :--- | :--- | :--- | :--- |
| **TC-001** | Submit the acceptance-criteria contact message and accept the success alert | **AUTOMATE (E2E)** | Smoke / PR-Blocking | Primary business flow and explicit acceptance criterion. |
| **TC-002** | Close a populated modal with the Close button without submitting | **AUTOMATE (E2E)** | Smoke / PR-Blocking | Explicit supported dismissal path; protects against accidental submission and blocked UI. |
| **TC-003** | Close a populated modal with the header X control without submitting | **AUTOMATE (E2E)** | Smoke / PR-Blocking | Explicit alternate dismissal path; validates modal cleanup from a distinct control. |
| **TC-100** | Submit with all contact fields empty | **AUTOMATE (E2E)** | Nightly Regression | Critical failure path; prevents misleading success for missing required data. |
| **TC-404** | Rapidly click Send message more than once | **AUTOMATE (E2E)** | Nightly Regression | Protects against duplicate support submissions, duplicate alerts, and inconsistent modal state. |

## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)

### Candidate 1: TC-001 - Submit the acceptance-criteria contact message

| Field | Details |
| :--- | :--- |
| **Reference** | TC-001 |
| **Squash Folder ID** | 1 |
| **Importance (Squash Enum)** | VERY_HIGH |
| **Execution Tier** | Smoke / PR-Blocking |
| **Prerequisite** | DemoBlaze is reachable at https://www.demoblaze.com/; the browser has no blocking alert or previously open modal; the user is on the home page and authentication is not required. |
| **Description** | `Verify that a visitor can open the Contact modal, submit the required valid values, receive the exact success alert, and return to a usable home page.` |

#### Test Steps

| # | Action | Expected Result |
| ---: | :--- | :--- |
| 1 | `Navigate to https://www.demoblaze.com/ and click the Contact navigation link.` | `The New message modal is visible with Contact Email, Contact Name, and Message controls.` |
| 2 | `Enter qa.engineer@example.com in Contact Email, Jane Doe in Contact Name, and Inquiry regarding order delivery times. in Message.` | `All three values are present in their respective controls.` |
| 3 | `Register a browser dialog handler and click Send message.` | `Exactly one native alert appears with text Thanks for the message!!.` |
| 4 | `Accept the success alert.` | `The modal and backdrop close automatically, and the home page remains usable without an uncaught page error.` |

### Candidate 2: TC-002 - Close a populated modal with the Close button

| Field | Details |
| :--- | :--- |
| **Reference** | TC-002 |
| **Squash Folder ID** | 1 |
| **Importance (Squash Enum)** | VERY_HIGH |
| **Execution Tier** | Smoke / PR-Blocking |
| **Prerequisite** | DemoBlaze is reachable and the browser has no active dialog. |
| **Description** | `Verify that a visitor can dismiss a populated Contact modal using the footer Close button without submitting the message.` |

#### Test Steps

| # | Action | Expected Result |
| ---: | :--- | :--- |
| 1 | `Open Contact and enter valid email, name, and message values.` | `The modal is visible and all values are populated.` |
| 2 | `Click the footer Close button and wait for the transition to finish.` | `The modal and backdrop are hidden and the home page view is restored.` |
| 3 | `Monitor browser dialogs and contact submission activity during dismissal.` | `No alert or contact submission occurs; the home page remains interactive.` |

### Candidate 3: TC-003 - Close a populated modal with the header X control

| Field | Details |
| :--- | :--- |
| **Reference** | TC-003 |
| **Squash Folder ID** | 1 |
| **Importance (Squash Enum)** | VERY_HIGH |
| **Execution Tier** | Smoke / PR-Blocking |
| **Prerequisite** | DemoBlaze is reachable and the browser has no active dialog. |
| **Description** | `Verify that the alternate supported header Close control dismisses populated contact data without sending it or leaving a blocked backdrop.` |

#### Test Steps

| # | Action | Expected Result |
| ---: | :--- | :--- |
| 1 | `Open Contact and fill all three fields with valid data.` | `The New message modal is visible with the entered values.` |
| 2 | `Click the header control with accessible label Close.` | `The modal closes through the X control and no browser alert appears.` |
| 3 | `Inspect the page after the modal transition.` | `No submission occurs, no overlay or backdrop blocks the page, and the home page is usable.` |

### Candidate 4: TC-100 - Submit with all fields empty

| Field | Details |
| :--- | :--- |
| **Reference** | TC-100 |
| **Squash Folder ID** | 1 |
| **Importance (Squash Enum)** | HIGH |
| **Execution Tier** | Nightly Regression |
| **Prerequisite** | DemoBlaze is reachable and the Contact modal is open with all fields empty. |
| **Description** | `Verify that a completely empty contact form cannot create a support submission or display a misleading success confirmation.` |

#### Test Steps

| # | Action | Expected Result |
| ---: | :--- | :--- |
| 1 | `Leave Contact Email, Contact Name, and Message empty and click Send message.` | `No support submission or success alert is produced.` |
| 2 | `Inspect validation state, focus, and modal visibility.` | `A clear actionable validation indication is shown or focus moves to the first invalid field, and the modal remains available for correction.` |

### Candidate 5: TC-404 - Rapidly click Send message more than once

| Field | Details |
| :--- | :--- |
| **Reference** | TC-404 |
| **Squash Folder ID** | 1 |
| **Importance (Squash Enum)** | HIGH |
| **Execution Tier** | Nightly Regression |
| **Prerequisite** | DemoBlaze is reachable; the Contact modal contains valid values; the dialog handler is registered before clicking. |
| **Description** | `Verify that repeated rapid clicks do not create duplicate contact submissions, alerts, or modal transitions.` |

#### Test Steps

| # | Action | Expected Result |
| ---: | :--- | :--- |
| 1 | `Click Send message twice rapidly while capturing dialogs and relevant submission requests.` | `At most one contact submission is attempted and at most one success alert is generated; subsequent clicks are ignored or debounced.` |
| 2 | `Accept the first valid success alert and inspect the final page state.` | `The modal closes once, no duplicate alert appears, and no stale backdrop remains.` |

## 3. Environment & Mocking Strategy

- **Base URL**: https://www.demoblaze.com/
- **Mocked Services**: None for the smoke path. For TC-404, observe contact submission requests and browser dialogs; do not mock the success alert. If the implementation exposes a request suitable for interception, use `page.route()` only to count or control duplicate-attempt behavior.
- **Cleanup Strategy**: Start each test in a fresh browser context with no active dialog, navigate to the base URL, and ensure any open modal is dismissed or the page is reloaded after the test. Accept or dismiss all captured dialogs before teardown so no blocking alert leaks into the next test.
