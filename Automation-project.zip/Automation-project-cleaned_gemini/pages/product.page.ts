import { expect, Locator, Page } from '@playwright/test';

export interface ProductData {
  productName: string;
  productPath: string;
  addedDialogMessage: string;
}

export class ProductPage {
  readonly page: Page;
  readonly productLink: Locator;
  readonly productTitle: Locator;
  readonly addToCartLink: Locator;

  constructor(page: Page, data: ProductData) {
    this.page = page;
    this.productLink = page.getByRole('link', { name: data.productName, exact: true });
    this.productTitle = page.getByRole('heading', { name: data.productName, exact: true });
    this.addToCartLink = page.getByRole('link', { name: 'Add to cart', exact: true });
  }

  async openFromCatalog(data: ProductData, appUrl: string): Promise<void> {
    await this.page.goto(new URL('', appUrl).toString());
    await expect(this.productLink).toHaveCount(1);
    await this.productLink.click();
    await expect(this.page).toHaveURL(new URL(data.productPath, appUrl).toString());
    await expect(this.productTitle).toHaveCount(1);
    await expect(this.productTitle).toBeVisible();
  }

  async addToCart(): Promise<void> {
    await expect(this.addToCartLink).toHaveCount(1);
    await this.addToCartLink.click();
  }
}
