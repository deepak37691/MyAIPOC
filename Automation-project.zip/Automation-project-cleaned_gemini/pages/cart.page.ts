import { expect, Locator, Page } from '@playwright/test';

export interface CartData {
  productName: string;
  productPrice: string;
}

export interface CheckoutData {
  customerName: string;
}

export class CartPage {
  readonly page: Page;
  readonly cartLink: Locator;
  readonly placeOrderButton: Locator;
  readonly orderDialog: Locator;
  readonly customerNameField: Locator;
  readonly purchaseButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.cartLink = page.getByRole('link', { name: 'Cart', exact: true });
    this.placeOrderButton = page.getByRole('button', { name: 'Place Order', exact: true });
    this.orderDialog = page.getByRole('dialog');
    this.customerNameField = this.orderDialog.getByRole('textbox', { name: /Name:/ });
    this.purchaseButton = this.orderDialog.getByRole('button', { name: 'urchase', exact: true });
  }

  async open(data: { cartPath: string }, appUrl: string): Promise<void> {
    await this.page.goto(new URL(data.cartPath, appUrl).toString());
    await expect(this.page).toHaveURL(new URL(data.cartPath, appUrl).toString());
  }

  async openFromNavigation(data: { cartPath: string }, appUrl: string): Promise<void> {
    await expect(this.cartLink).toHaveCount(1);
    await this.cartLink.click();
    await expect(this.page).toHaveURL(new URL(data.cartPath, appUrl).toString());
  }

  async verifyProductRow(data: CartData): Promise<void> {
    const productRow = this.page
      .getByRole('row')
      .filter({ has: this.page.getByRole('cell', { name: data.productName, exact: true }) });
    await expect(productRow).toHaveCount(1, { timeout: 15000 });
    await expect(productRow.getByRole('cell', { name: data.productPrice, exact: true })).toHaveCount(1);
  }

  async openOrderDialog(): Promise<void> {
    await expect(this.placeOrderButton).toHaveCount(1);
    await this.placeOrderButton.click();
    await expect(this.orderDialog).toBeVisible();
  }

  async submitCheckout(data: CheckoutData): Promise<void> {
    await this.customerNameField.fill(data.customerName);
    await this.purchaseButton.click();
  }
}
