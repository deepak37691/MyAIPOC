import { Locator, Page } from '@playwright/test';

export interface AddToCartData {
  productName: string;
}

export interface CheckoutData {
  customerName: string;
}

export class DemoblazePage {
  readonly page: Page;
  readonly cartLink: Locator;
  readonly placeOrderButton: Locator;
  readonly orderModal: Locator;
  readonly purchaseButton: Locator;
  readonly customerNameField: Locator;

  constructor(page: Page) {
    this.page = page;
    this.cartLink = page.getByRole('link', { name: 'Cart', exact: true });
    this.placeOrderButton = page.getByRole('button', { name: 'Place Order', exact: true });
    this.orderModal = page.getByRole('dialog').filter({ has: page.getByRole('button', { name: 'Purchase', exact: true }) });
    this.purchaseButton = this.orderModal.getByRole('button', { name: 'Purchase', exact: true });
    this.customerNameField = page.getByLabel('Name:', { exact: true });
  }

  async open(url: string): Promise<void> {
    await this.page.goto(url);
  }

  async openProduct(productName: string): Promise<void> {
    await this.page.getByRole('link', { name: productName, exact: true }).click();
  }

  async addProductToCart(data: AddToCartData): Promise<string> {
    await this.page.getByRole('heading', { name: data.productName, exact: true }).waitFor();
    const dialogPromise = this.page.waitForEvent('dialog');
    const clickPromise = this.page.getByRole('link', { name: 'Add to cart', exact: true }).click();
    const dialog = await dialogPromise;
    const message = dialog.message();
    await dialog.accept();
    await clickPromise;
    return message;
  }

  async openCart(): Promise<void> {
    await this.cartLink.click();
    await this.page.waitForURL(/\/cart\.html$/);
  }

  productRow(productName: string): Locator {
    return this.page.getByRole('row').filter({ hasText: productName });
  }

  async openCheckout(): Promise<void> {
    await this.placeOrderButton.click();
    await this.purchaseButton.waitFor();
  }

  async fillMissingCreditCardCheckout(data: CheckoutData): Promise<string> {
    await this.customerNameField.fill(data.customerName);
    const dialogPromise = this.page.waitForEvent('dialog');
    const clickPromise = this.purchaseButton.click({ force: true });
    const dialog = await dialogPromise;
    const message = dialog.message();
    await dialog.accept();
    await clickPromise;
    return message;
  }
}
