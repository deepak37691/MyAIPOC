import 'dotenv/config';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, ChildProcess, ChildProcessWithoutNullStreams } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { URL } from 'node:url';
import { execFileSync, execFile } from 'node:child_process';

const ROOT = path.resolve(__dirname, '..', '..');
const UI_ROOT = path.resolve(__dirname, '..', 'public');
const STATE_DIR = path.join(ROOT, '.automation-ui');
const STATE_FILE = path.join(STATE_DIR, 'session.json');
const PORT = Number(process.env.UI_PORT || 4173);

type Status = 'locked'|'ready'|'running'|'waiting_for_approval'|'completed'|'failed'|'not_required';
type StageName = 'scenarios'|'strategy'|'squash'|'scriptGeneration'|'execution'|'healer'|'gitlabCommit';
interface Stage { status: Status; startedAt?: string; completedAt?: string; message?: string; output?: unknown; error?: string; }
interface Session { id: string; issueUrl: string; issueId: string; folderId: number; appUrl?: string; createdAt: string; updatedAt: string; mcp: { gitlab: boolean; playwright: boolean }; stages: Record<StageName, Stage>; events: { at:string; type:string; stage?:string; message:string }[]; }

const sessions = new Map<string, Session>();
const mcp: Record<'gitlab'|'playwright', ChildProcessWithoutNullStreams | undefined> = { gitlab: undefined, playwright: undefined };
const approvalLocks = new Set<string>();
const activeRuns = new Map<string, { child: ChildProcess; stopRequested: boolean }>();
// Secrets are intentionally kept only in process memory. They are never returned by an API
// endpoint and are never written to the session/state file or .env by this UI.
const runtimeSecrets: { gitlabToken?: string; squashToken?: string } = {};

function secretStatus() { return { gitlabConfigured: !!runtimeSecrets.gitlabToken, squashConfigured: !!runtimeSecrets.squashToken }; }
function sanitizedEnv() { const env={...process.env}; delete env.GITLAB_PERSONAL_ACCESS_TOKEN; delete env.SQUASH_BEARER_TOKEN; return env; }

function ensureState() { fs.mkdirSync(STATE_DIR, { recursive: true }); }
function save(s: Session) { ensureState(); s.updatedAt = new Date().toISOString(); fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 2)); }
function addEvent(s: Session, type: string, message: string, stage?: string) { s.events.push({ at:new Date().toISOString(), type, stage, message }); s.events = s.events.slice(-200); save(s); }
function stage(s: Session, name: StageName, patch: Partial<Stage>) { s.stages[name] = { ...s.stages[name], ...patch }; save(s); }
function initStages(): Record<StageName, Stage> { return {
  scenarios:{status:'ready'}, strategy:{status:'ready'}, squash:{status:'ready'}, scriptGeneration:{status:'ready'}, execution:{status:'ready'}, healer:{status:'ready'}, gitlabCommit:{status:'ready'}
}; }
function unlockAfter(_s:Session, _name:StageName) { /* stages are intentionally independent */ }

function issueIdFromUrl(input: string): string {
  const m = input.match(/(?:\/(?:issues|work_items)\/)(\d+)(?:[/?#]|$)/i); if (m) return m[1];
  if (/^\d+$/.test(input.trim())) return input.trim();
  throw new Error('GitLab issue URL must contain /issues/<number> or /work_items/<number>, or provide a numeric issue ID.');
}
function json(res:http.ServerResponse, code:number, body:unknown) { const data=JSON.stringify(body); res.writeHead(code, {'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)}); res.end(data); }
function escapeHtml(value:string) { return value.replace(/[&<>"']/g, character=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character] || character)); }
function markdownToHtml(markdown:string) {
  const esc = escapeHtml;
  const lines = markdown.replace(/\r/g,'').split('\n');
  const out:string[]=[];
  let inUl=false;
  let inOl=false;
  let inCode=false;
  let code:string[]=[];
  let table:string[][]|null=null;

  const closeLists=()=>{
    if(inUl){out.push('</ul>');inUl=false;}
    if(inOl){out.push('</ol>');inOl=false;}
  };

  // The strategy markdown intentionally contains a small amount of inline HTML
  // (mainly <p> wrappers inside candidate descriptions/steps). Escape arbitrary
  // HTML first, then restore only the harmless presentation tags we support.
  const inlineMarkdown=(value:string)=>{
    let html=esc(value)
      .replace(/`([^`]+)`/g,'<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>')
      .replace(/__([^_]+)__/g,'<strong>$1</strong>')
      .replace(/\*([^*]+)\*/g,'<em>$1</em>')
      .replace(/_([^_]+)_/g,'<em>$1</em>')
      .replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    html=html
      .replace(/&lt;(\/?(?:p|br|strong|em|code))\s*&gt;/gi,'<$1>')
      .replace(/&lt;(br)\s*\/&gt;/gi,'<$1>');
    return html;
  };

  const parseTableRow=(line:string)=>line.trim().replace(/^\|/,'').replace(/\|$/,'').split(/(?<!\\)\|/).map(c=>c.replace(/\\\|/g,'|').trim());
  const isTableSeparator=(line:string)=>/^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(line);

  const flushTable=()=>{
    if(!table)return;
    const rows=table;
    table=null;
    if(!rows.length)return;
    const header=rows[0];
    const body=rows.slice(1);
    out.push(
      '<div class="md-table-wrap"><table class="md-table"><thead><tr>'+
      header.map(c=>`<th>${inlineMarkdown(c)}</th>`).join('')+
      '</tr></thead><tbody>'+
      (body.length ? body.map(r=>{
        const cells=header.map((_,i)=>`<td>${inlineMarkdown(r[i]||'')}</td>`);
        return `<tr>${cells.join('')}</tr>`;
      }).join('') : `<tr><td colspan="${header.length}" class="empty">No records</td></tr>`) +
      '</tbody></table></div>'
    );
  };

  for(let i=0;i<lines.length;i++){
    const line=lines[i];
    if(line.trim().startsWith('```')){
      flushTable();
      closeLists();
      if(inCode){
        out.push('<pre><code>'+esc(code.join('\n'))+'</code></pre>');
        code=[];
        inCode=false;
      } else {
        inCode=true;
      }
      continue;
    }
    if(inCode){code.push(line);continue;}

    if(/^\s*\|.*(?:\|.*)?$/.test(line) && i+1<lines.length && isTableSeparator(lines[i+1])){
      flushTable();
      table=[parseTableRow(line)];
      i++;
      continue;
    }
    if(table && /^\s*\|/.test(line)){
      table.push(parseTableRow(line));
      continue;
    }

    if(!line.trim()){
      flushTable();
      closeLists();
      continue;
    }

    const h=line.match(/^\s*(#{1,6})\s+(.+)$/);
    if(h){
      flushTable();
      closeLists();
      const level=h[1].length;
      out.push(`<h${level}>${inlineMarkdown(h[2])}</h${level}>`);
      continue;
    }

    const ul=line.match(/^\s*[-*+]\s+(.+)$/);
    if(ul){
      flushTable();
      if(inOl){out.push('</ol>');inOl=false;}
      if(!inUl){out.push('<ul>');inUl=true;}
      out.push(`<li>${inlineMarkdown(ul[1])}</li>`);
      continue;
    }

    const ol=line.match(/^\s*\d+[.)]\s+(.+)$/);
    if(ol){
      flushTable();
      if(inUl){out.push('</ul>');inUl=false;}
      if(!inOl){out.push('<ol>');inOl=true;}
      out.push(`<li>${inlineMarkdown(ol[1])}</li>`);
      continue;
    }

    flushTable();
    closeLists();
    out.push(`<p>${inlineMarkdown(line)}</p>`);
  }

  flushTable();
  closeLists();
  if(inCode)out.push('<pre><code>'+esc(code.join('\n'))+'</code></pre>');
  return out.join('');
}

function artifactPreview(res:http.ServerResponse, requested:string) {
  const relative=path.normalize(requested).replace(/^([.][.][\\/])+/, '');
  const full=path.resolve(ROOT,relative);
  if((full !== ROOT && !full.startsWith(`${ROOT}${path.sep}`)) || !fs.existsSync(full) || !fs.statSync(full).isFile()) return json(res,404,{error:'Artifact not found'});
  const content=fs.readFileSync(full,'utf8');
  const title=path.basename(full);
  const ext=path.extname(full).toLowerCase();
  if(ext==='.md' || ext==='.markdown') return reportHtml(res,title,`Complete document • ${relative}`,[],`<article class="markdown-document">${markdownToHtml(content)}</article>`);
  if(ext==='.json'){ try { const data=JSON.parse(content); return reportHtml(res,title,`Complete JSON artifact • ${relative}`,[{title:'Artifact',columns:['Path','Value'],rows:flattenObject(data).map(([k,v])=>[k,v])}]); } catch {} }
  const rows=content.split(/\r?\n/).map((line,i)=>[i+1,line]); return reportHtml(res,title,`Complete file • ${relative}`,[{title:'File contents',columns:['Line','Content'],rows}]);
}
function flattenObject(value:any,prefix=''):Array<[string,string]> { if(value===null||value===undefined)return [[prefix,'']]; if(typeof value!=='object')return [[prefix,String(value)]]; if(Array.isArray(value)){return value.flatMap((v,i)=>flattenObject(v,prefix?`${prefix}[${i}]`:`[${i}]`));} return Object.entries(value).flatMap(([k,v])=>flattenObject(v,prefix?`${prefix}.${k}`:k)); }
function reportContentType(file:string) {
  const ext=path.extname(file).toLowerCase();
  return ({'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.woff':'font/woff','.woff2':'font/woff2'} as Record<string,string>)[ext] || 'application/octet-stream';
}
function serveReportFile(res:http.ServerResponse,baseDir:string,relative:string) {
  const base=path.resolve(baseDir); const target=path.resolve(base,relative);
  if(target!==base && !target.startsWith(`${base}${path.sep}`)) return json(res,403,{error:'Invalid report path'});
  if(!fs.existsSync(target) || !fs.statSync(target).isFile()) return json(res,404,{error:'Report asset not found'});
  const data=fs.readFileSync(target);
  res.writeHead(200,{'Content-Type':reportContentType(target),'Content-Length':data.length,'Cache-Control':'no-cache'});
  res.end(data);
}
function executionReportDir(s:Session) { return path.join(ROOT,'playwright-report',`execution-${s.id}`); }
function hasExecutionReport(s:Session) { return fs.existsSync(path.join(executionReportDir(s),'index.html')); }

function reportHtml(res:http.ServerResponse,title:string,subtitle:string,tables:{title:string,columns:string[],rows:(string|number)[][]}[],contentHtml='') {
  const esc=(v:unknown)=>escapeHtml(String(v ?? ''));
  const body=(contentHtml ? contentHtml : tables.map(t=>`<section class="report-section"><h2>${esc(t.title)}</h2><div class="table-wrap"><table><thead><tr>${t.columns.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${t.rows.length?t.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${t.columns.length}" class="empty">No records</td></tr>`}</tbody></table></div></section>`).join(''));
  const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>body{margin:0;background:#f4f6f8;color:#172033;font:14px/1.6 Segoe UI,Arial,sans-serif}.top{background:#172033;color:#fff;padding:26px 5vw;box-shadow:0 2px 10px rgba(0,0,0,.08)}.top strong{display:block;font-size:22px;letter-spacing:-.01em}.top small{display:block;margin-top:4px;opacity:.72}.wrap{max-width:1280px;margin:24px auto;padding:0 20px}.report-section,.markdown-document{background:#fff;border:1px solid #dfe4ea;border-radius:12px;margin:0 0 18px;overflow:hidden;box-shadow:0 1px 2px rgba(15,23,42,.03)}.report-section h2{font-size:15px;margin:0;padding:15px 18px;border-bottom:1px solid #e4e8ed;background:#fbfcfd}.table-wrap,.md-table-wrap{width:100%;overflow-x:auto}.table-wrap table,.md-table{width:100%;border-collapse:separate;border-spacing:0}.table-wrap th,.table-wrap td,.md-table th,.md-table td{text-align:left;padding:11px 14px;border-bottom:1px solid #edf0f4;vertical-align:top}.table-wrap th,.md-table th{background:#f7f9fb;color:#4b5563;font-size:11px;text-transform:uppercase;letter-spacing:.055em;white-space:nowrap}.table-wrap tr:last-child td,.md-table tr:last-child td{border-bottom:0}.markdown-document{padding:30px}.markdown-document h1,.markdown-document h2,.markdown-document h3,.markdown-document h4{color:#172033;margin:24px 0 11px}.markdown-document h1{font-size:26px;margin-top:0}.markdown-document h2{font-size:20px;border-bottom:1px solid #e4e7ec;padding-bottom:8px}.markdown-document h3{font-size:17px;padding-top:8px}.markdown-document h4{font-size:15px}.markdown-document p{margin:9px 0}.markdown-document ul,.markdown-document ol{padding-left:28px}.markdown-document li{margin:5px 0}.markdown-document code{background:#eef1f5;padding:2px 5px;border-radius:4px;font-size:.92em}.markdown-document pre{background:#111827;color:#e5e7eb;padding:15px;border-radius:8px;overflow:auto}.md-table{margin:12px 0 22px;min-width:760px}.md-table th{background:#eef2f7}.md-table td:first-child{font-weight:500}.markdown-document .md-table-wrap{border:1px solid #e4e8ed;border-radius:8px}.markdown-document a{color:#2457c5}.markdown-document strong{font-weight:650}.empty{color:#7a8496;text-align:center;padding:24px}</style></head><body><header class="top"><strong>${esc(title)}</strong><small>${esc(subtitle)}</small></header><main class="wrap">${body}</main></body></html>`;
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Length':Buffer.byteLength(html)}); res.end(html);
}
function stageReport(res:http.ServerResponse,s:Session,n:StageName){
  const st=s.stages[n];
  // Once Playwright has executed, use its interactive HTML report as the canonical
  // preview for Test Case/Scenario work, Script Generation, and Execution.
  // Failed executions also have a valid Playwright report and must remain previewable.
  if(['scenarios','squash','scriptGeneration','execution'].includes(n) && hasExecutionReport(s)) {
    return serveReportFile(res,executionReportDir(s),'index.html');
  }
  if(st.status!=='completed') return json(res,409,{error:'Preview is available after the stage is completed and a report has been produced.'});
  const out:any=st.output||{}; const tables:{title:string,columns:string[],rows:(string|number)[][]}[]=[];
  if(n==='scenarios' && out.artifact?.relativePath) return artifactPreview(res,out.artifact.relativePath);
  if(n==='strategy' && out.artifact?.relativePath) return artifactPreview(res,out.artifact.relativePath);
  if(n==='squash' && out.payload?.relativePath) return artifactPreview(res,out.payload.relativePath);
  if(n==='scriptGeneration'){const arts=out.artifacts||{}; const refs=[['Test Data',arts.testData?.relativePath],['Spec',arts.spec?.relativePath],...(arts.pages||[]).map((p:any)=>['Page Object',p.relativePath])].filter((x:any)=>x[1]); const sections=refs.map(([label,rel]:any)=>{const full=path.resolve(ROOT,rel); if(!fs.existsSync(full)) return ''; const content=fs.readFileSync(full,'utf8'); const ext=path.extname(full).toLowerCase(); if(ext==='.md') return `<section class=\"report-section\"><h2>${escapeHtml(label)} • ${escapeHtml(rel)}</h2><div class=\"markdown-document\">${markdownToHtml(content)}</div></section>`; return `<section class=\"report-section\"><h2>${escapeHtml(label)} • ${escapeHtml(rel)}</h2><pre class=\"source-code\"><code>${escapeHtml(content)}</code></pre></section>`; }).join(''); return reportHtml(res,`script-generation report`,`Complete generated files • Issue #${s.issueId}`,[],sections||'<section class=\"report-section\"><h2>Generated artifacts</h2><p>No generated files found.</p></section>');}
  if(n==='execution'){const results=out.report?.suites?.flatMap((suite:any)=>suite.specs?.flatMap((sp:any)=>sp.tests?.map((t:any)=>[sp.title,t.projectName||'',t.status||t.results?.at(-1)?.status||'',t.results?.at(-1)?.duration||''])||[])||[])||[]; tables.push({title:'Execution Results',columns:['Test','Project','Status','Duration (ms)'],rows:results}); if(out.report) tables.push({title:'Complete Playwright Report Data',columns:['Field','Value'],rows:flattenObject(out.report).map(([k,v])=>[k,v])});}
  else if(n==='healer')tables.push({title:'Test Healer',columns:['Status','Message'],rows:[[st.status,st.message||'']]});
  else if(n==='gitlabCommit')tables.push({title:'GitLab Commit',columns:['Field','Value'],rows:[['Repository',out.repositoryPath||''],['Branch',out.branch||''],['Commit',out.commit||''],['Git status',out.gitStatus||'']]});
  if(!tables.length)tables.push({title:'Stage Details',columns:['Field','Value'],rows:flattenObject(out).map(([k,v])=>[k,v])});
  return reportHtml(res,`${n} report`,`Complete stage details • Issue #${s.issueId}`,tables);
}

function readBody(req:http.IncomingMessage):Promise<any> { return new Promise((resolve,reject)=>{let b=''; req.on('data',c=>b+=c); req.on('end',()=>{try{resolve(b?JSON.parse(b):{})}catch(e){reject(e)}});}); }
function killProcessTree(child:ChildProcess) {
  try {
    if (process.platform === 'win32' && child.pid) {
      execFile('taskkill',['/PID',String(child.pid),'/T','/F'],{windowsHide:true},()=>{});
    } else {
      child.kill('SIGTERM');
      setTimeout(()=>{ try { child.kill('SIGKILL'); } catch {} },1500).unref();
    }
  } catch {}
}

function shellCommand(template:string, vars:Record<string,string>, onOutput:(text:string, stream:'stdout'|'stderr')=>void, cb:(err:Error|null,out:string)=>void, runKey?:string) {
  let command=template; for(const [k,v] of Object.entries(vars)) command=command.replaceAll(`{{${k}}}`, JSON.stringify(v));
  const child=execFile(process.platform==='win32'?'cmd.exe':'/bin/sh', process.platform==='win32'?['/d','/s','/c',command]:['-lc',command], {cwd:ROOT, env:{...sanitizedEnv(),...vars}}, (err,stdout,stderr)=>{
    if(runKey) activeRuns.delete(runKey);
    cb(err, `${stdout || ''}${stderr ? `\n${stderr}`:''}`.trim());
  });
  if(runKey) activeRuns.set(runKey,{child,stopRequested:false});
  child.stdout?.on('data', data=>onOutput(String(data), 'stdout'));
  child.stderr?.on('data', data=>onOutput(String(data), 'stderr'));
}
function runConfiguredAgent(stageName:StageName, s:Session, extra:Record<string,string> = {}):Promise<string> {
  const key = `AGENT_COMMAND_${stageName.replace(/[A-Z]/g,m=>`_${m}`).toUpperCase()}`;
  const command = process.env[key] || process.env.AGENT_RUNNER_COMMAND;
  if (!command) return Promise.reject(new Error(`No agent runner configured for ${stageName}. Set AGENT_RUNNER_COMMAND=node ./automation-ui/agent-runner.js in .env, or configure ${key}. The command receives ISSUE_ID, ISSUE_URL, FOLDER_ID, APP_URL and STAGE.`));
  addEvent(s,'stage.progress',`Launching ${stageName} agent...`,stageName);
  const startedAt=Date.now();
  const healerTimeoutMs = stageName==='healer' ? (extra.APPROVAL==='approved' ? Number(process.env.HEALER_REPAIR_TIMEOUT_MS || 600000) : Number(process.env.HEALER_DIAGNOSIS_TIMEOUT_MS || 600000)) : 0;
  return new Promise((resolve,reject)=>{
    let settled=false;
    const heartbeat=setInterval(()=>addEvent(s,'stage.progress',`${stageName} agent is still working...`,stageName),10000);
    const timeout=healerTimeoutMs ? setTimeout(()=>{
      if(settled) return;
      const runKey=`${s.id}:${stageName}`;
      const active=activeRuns.get(runKey);
      if(active){ active.stopRequested=true; killProcessTree(active.child); }
      settled=true;
      clearInterval(heartbeat);
      activeRuns.delete(runKey);
      const phase=extra.APPROVAL==='approved'?'approved repair':'diagnosis';
      addEvent(s,'stage.progress',`Test Healer ${phase} timed out after ${Math.round(healerTimeoutMs/1000)}s and was stopped.`,stageName);
      reject(new Error(`Test Healer ${phase} timed out after ${Math.round(healerTimeoutMs/1000)} seconds.`));
    },healerTimeoutMs):undefined;
    shellCommand(command,{ISSUE_ID:s.issueId,ISSUE_URL:s.issueUrl,FOLDER_ID:String(s.folderId),APP_URL:s.appUrl||'',STAGE:stageName,GITLAB_PERSONAL_ACCESS_TOKEN:runtimeSecrets.gitlabToken||'',...extra},(text,stream)=>{
      text.split(/\r?\n/).map(line=>line.trim()).filter(Boolean).forEach(line=>addEvent(s,'stage.log',`${stream === 'stderr' ? '[stderr] ' : ''}${line}`,stageName));
    },(err,out)=>{
      if(settled) return;
      settled=true;
      if(timeout) clearTimeout(timeout);
      clearInterval(heartbeat);
      const runKey=`${s.id}:${stageName}`;
      const wasStopped=activeRuns.get(runKey)?.stopRequested;
      activeRuns.delete(runKey);
      if(wasStopped) { reject(new Error(`Stage ${stageName} stopped by user.`)); return; }
      const combined=String(out||'');
      const quotaFailure=/(?:exceeded|exceeding) (?:your|the) (?:monthly )?quota|monthly quota|rate.?limit|usage limit|AI Credits 0/i.test(combined);
      if(err || quotaFailure) {
        addEvent(s,'stage.progress',`${stageName} agent exited with an error after ${Math.round((Date.now()-startedAt)/1000)}s.`,stageName);
        reject(new Error(combined || err?.message || `${stageName} agent failed.`));
      } else {
        addEvent(s,'stage.progress',`${stageName} agent completed in ${Math.round((Date.now()-startedAt)/1000)}s; collecting artifacts...`,stageName);
        resolve(out);
      }
    },`${s.id}:${stageName}`);
  });
}
function findArtifact(s:Session, candidates:string[]):string|undefined { for(const rel of candidates){const p=path.join(ROOT,rel); if(fs.existsSync(p)) return rel;} return undefined; }
function artifactDetails(rel:string|undefined) { return rel ? { repositoryPath:rel, relativePath:rel, localPath:path.resolve(ROOT,rel) } : undefined; }
function stripMd(value:string) { return value.replace(/[*_`]/g,'').trim(); }
function extractHealerProposal(raw:string):string {
  const clean=String(raw||'').replace(/\x1b\[[0-?]*[ -\/]*[@-~]/g,'').replace(/\r/g,'').trim();
  if(!clean) return '';
  const headings=[
    '### Diagnostic & Self-Healing Observation Report',
    '## Diagnostic & Self-Healing Observation Report',
    '# Diagnostic & Self-Healing Observation Report',
    'Diagnostic & Self-Healing Observation Report'
  ];
  for(const heading of headings){
    const idx=clean.toLowerCase().indexOf(heading.toLowerCase());
    if(idx>=0) return clean.slice(idx).trim();
  }
  const proposalIdx=clean.toLowerCase().lastIndexOf('observation & proposal report');
  if(proposalIdx>=0) return clean.slice(Math.max(0, proposalIdx-20)).trim();
  // Some Copilot versions do not preserve the requested heading. In that case,
  // keep the complete agent response visible rather than hiding a useful proposal.
  return clean;
}
function parsePipeRow(line:string):string[]|undefined {
  if(!/^\s*\|/.test(line)) return undefined;
  return line.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(stripMd);
}
async function fetchGitLabIssueForScenarioFallback(s:Session):Promise<{title:string,description:string}|undefined> {
  const token=runtimeSecrets.gitlabToken || process.env.GITLAB_PERSONAL_ACCESS_TOKEN || '';
  const base=(process.env.GITLAB_API_URL || 'https://gitlab.com/api/v4').replace(/\/$/,'');
  try {
    const issueUrl=new URL(s.issueUrl);
    const marker=issueUrl.pathname.match(/^(.*)\/(?:issues|work_items)\/(\d+)\/?$/i);
    if(!marker) return undefined;
    const projectPath=decodeURIComponent(marker[1].replace(/^\//,''));
    const apiUrl=`${base}/projects/${encodeURIComponent(projectPath)}/issues/${encodeURIComponent(s.issueId)}`;
    const headers:Record<string,string>={'Accept':'application/json'};
    if(token) headers['PRIVATE-TOKEN']=token;
    const response=await fetch(apiUrl,{headers});
    if(!response.ok) return undefined;
    const data:any=await response.json();
    return {title:String(data.title||`Issue #${s.issueId}`),description:String(data.description||'')};
  } catch { return undefined; }
}

function extractFallbackCriteria(description:string):string[] {
  const lines=description.replace(/\r/g,'').split('\n').map(x=>x.trim()).filter(Boolean);
  const criteria:string[]=[];
  let inAcceptance=false;
  for(const line of lines){
    if(/^#{1,6}\s*(acceptance criteria|acceptance|ac)\b/i.test(line)){inAcceptance=true;continue;}
    if(inAcceptance && /^#{1,6}\s+/.test(line)){inAcceptance=false;continue;}
    if(inAcceptance){
      const value=line.replace(/^[-*+]\s+/, '').replace(/^\[[ xX]\]\s+/, '').replace(/^\d+[.)]\s+/, '').trim();
      if(value && !/^[-_*]{3,}$/.test(value)) criteria.push(value);
    }
  }
  if(!criteria.length){
    for(const line of lines){
      const value=line.replace(/^[-*+]\s+/, '').replace(/^\[[ xX]\]\s+/, '').replace(/^\d+[.)]\s+/, '').trim();
      if(/^(given|when|then)\b/i.test(value) || /^the (user|system|application)\b/i.test(value)) criteria.push(value);
      if(criteria.length>=8) break;
    }
  }
  return [...new Set(criteria)].slice(0,8);
}

async function buildFallbackScenarioArtifact(s:Session, reason:string):Promise<string> {
  const dir=path.join(ROOT,'test-scenarios','scenarios'); fs.mkdirSync(dir,{recursive:true});
  const rel=`test-scenarios/scenarios/${s.issueId}.md`;
  const file=path.join(ROOT,rel);
  const issue=await fetchGitLabIssueForScenarioFallback(s);
  const title=issue?.title || `Functional E2E scenarios for issue #${s.issueId}`;
  const criteria=extractFallbackCriteria(issue?.description || '');
  const primary=criteria.length ? criteria : [`Validate the primary user workflow described by GitLab issue #${s.issueId}.`];
  const happy=primary.slice(0,Math.min(primary.length,6));
  const rows:any[]=[];
  happy.forEach((criterion,i)=>rows.push({id:`TC-${String(i+1).padStart(3,'0')}`,category:'Happy Path',summary:criterion,priority:i===0?'P0':'P1',suggestedLayer:'E2E'}));
  rows.push({id:'TC-100',category:'Negative',summary:'Verify the application handles invalid or rejected input for the affected workflow.',priority:'P1',suggestedLayer:'E2E'});
  rows.push({id:'TC-400',category:'Edge Case',summary:'Verify the affected workflow handles boundary, repeated, or unexpected user actions without an unhandled error.',priority:'P2',suggestedLayer:'E2E'});
  const detail=rows.map((r:any)=>[
    `### ${r.id}: ${r.summary}`,
    `- **Category**: ${r.category}`,
    `- **Priority**: ${r.priority}`,
    `- **Preconditions**: Application is available and the relevant issue workflow can be reached.`,
    `- **Steps**:`,
    `  1. Navigate to the affected workflow described by issue #${s.issueId}.`,
    `  2. ${r.category==='Negative'?'Provide an invalid, missing, or rejected input and submit the workflow.':r.category==='Edge Case'?'Perform the boundary, repeated, or unexpected action relevant to the workflow.':`Perform the user action required by the scenario: ${r.summary}`}`,
    `  3. Observe the resulting UI and application state.`,
    `- **Expected Results**: The application behaves according to the requirement, provides the appropriate UI feedback, and does not produce an unhandled error.`
  ].join('\n'));
  const content=[
    `# E2E Test Scenarios: ${title}`,'',
    `- **Issue Reference**: #${s.issueId}`,
    `- **Generated Date**: ${new Date().toISOString().slice(0,10)}`,
    `- **Generation Mode**: Deterministic fallback (AI agent unavailable)`,
    `- **Fallback Reason**: ${reason.replace(/\r?\n/g,' ')}`,'',
    '## 1. Scenario Summary Matrix','',
    '| Scenario ID | Category | Summary Description | Priority | Suggested Layer |',
    '| :--- | :--- | :--- | :--- | :--- |',
    ...rows.map((r:any)=>`| **${r.id}** | ${r.category} | ${r.summary.replace(/\|/g,'\\|')} | ${r.priority} | ${r.suggestedLayer} |`),
    '', '## 2. Detailed Test Scenarios','', ...detail.flatMap(x=>[x,''])
  ].join('\n');
  fs.writeFileSync(file,content,'utf8');
  return rel;
}

function parseScenarios(s:Session) {
  const rel=findArtifact(s,[`test-scenarios/scenarios/issue-${s.issueId}.md`,`test-scenarios/scenarios/issue-${s.issueId}-e2e-scenarios.md`,`test-scenarios/scenarios/${s.issueId}.md`]);
  if(!rel) return undefined;
  const text=fs.readFileSync(path.join(ROOT,rel),'utf8').replace(/\r/g,'');
  const rows:any[]=[];
  for(const line of text.split('\n')) {
    const cells=parsePipeRow(line);
    if(!cells || !/^TC-\d+$/i.test(cells[0]||'')) continue;
    if(/scenario id/i.test(cells[0])) continue;
    rows.push({id:cells[0].toUpperCase(),category:cells[1]||'',summary:cells[2]||'',priority:cells[3]||'',suggestedLayer:cells[4]||''});
  }
  const unique=rows.filter((row,index,self)=>self.findIndex(x=>x.id===row.id)===index);
  return {artifact:rel,count:unique.length,scenarios:unique};
}
function strategyProposalRel(s:Session):string|undefined {
  return findArtifact(s,[
    `test-scenarios/strategy/${s.issueId}-strategy-proposal.md`,
    `test-scenarios/strategy/${s.issueId}-strategy.md`
  ]);
}
function finalStrategyRel(s:Session):string { return `test-scenarios/strategy/${s.issueId}-strategy.md`; }
function parseStrategy(s:Session, preferred?:string) {
  const rel=preferred || strategyProposalRel(s);
  if(!rel)return undefined;
  const text=fs.readFileSync(path.join(ROOT,rel),'utf8').replace(/\r/g,'');
  const decisions=new Map<string,{description:string,decision:string,tier:string,justification?:string}>();
  for(const line of text.split('\n')) {
    const cells=parsePipeRow(line);
    if(!cells || !/^TC-\d+$/i.test(cells[0]||'')) continue;
    const decision=cells[2]||'';
    if(!/^(AUTOMATE|OFFLOAD)\b/i.test(decision)) continue;
    decisions.set(cells[0].toUpperCase(),{id:cells[0].toUpperCase(),description:cells[1]||'',decision,tier:cells[3]||'',justification:cells[4]||''} as any);
  }
  // The scenario artifact is the authoritative list for the UI. The strategy proposal
  // only supplies the agent recommendation. This guarantees that OFFLOAD rows are
  // still visible and selectable even when the agent emits a lean/partial matrix.
  const all=parseScenarios(s)?.scenarios||[];
  const candidateIds=[...text.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)].map(m=>m[1].toUpperCase());
  const sourceRows=all.length ? all : [...decisions.entries()].map(([id,row])=>({id,category:'',summary:row.description,priority:'',suggestedLayer:''}));
  const strategies=sourceRows.map((scenario:any)=>{
    const id=String(scenario.id).toUpperCase();
    const row=decisions.get(id);
    const recommended=!!row ? /^AUTOMATE\b/i.test(row.decision) : candidateIds.includes(id);
    return {
      id,
      description:row?.description || scenario.summary || id,
      decision:row?.decision || (recommended?'AUTOMATE (E2E)':'OFFLOAD (Unit/API/Omit)'),
      tier:row?.tier || scenario.suggestedLayer || (recommended?'Regression':'Unit / API'),
      justification:row?.justification || (recommended?'Recommended by Test Strategy Agent.':'Not initially recommended for E2E; available for user override.')
    };
  });
  return {artifact:rel,strategies};
}
function prepareStrategyProposal(s:Session) {
  const dir=path.join(ROOT,'test-scenarios','strategy'); fs.mkdirSync(dir,{recursive:true});
  // Keep the last approved strategy intact while a new proposal is being generated.
  // If the external strategy agent is unavailable (for example because its monthly
  // quota is exhausted), it can be used as the recommendation source for the local
  // deterministic fallback instead of leaving the UI with no test cases to review.
  try{fs.unlinkSync(path.join(dir,`${s.issueId}-strategy-proposal.md`));}catch{}
}
function captureStrategyProposal(s:Session):string {
  const dir=path.join(ROOT,'test-scenarios','strategy');
  const proposal=path.join(dir,`${s.issueId}-strategy-proposal.md`);
  if(fs.existsSync(proposal)) return `test-scenarios/strategy/${s.issueId}-strategy-proposal.md`;
  const legacy=path.join(dir,`${s.issueId}-strategy.md`);
  if(fs.existsSync(legacy)) { fs.copyFileSync(legacy,proposal); try{fs.unlinkSync(legacy);}catch{}; return `test-scenarios/strategy/${s.issueId}-strategy-proposal.md`; }
  throw new Error(`Strategy agent completed but no strategy proposal was created for issue #${s.issueId}.`);
}
function extractApplicationUrl(s:Session):string {
  const parsed=parseScenarios(s);
  if(!parsed?.artifact) return s.appUrl || '';
  const text=fs.readFileSync(path.join(ROOT,parsed.artifact),'utf8');
  const match=text.match(/^-\s*\*\*Application URL\*\*:\s*(.+)$/mi);
  return (match?.[1] || s.appUrl || '').trim().replace(/[`]/g,'');
}

function buildFallbackStrategyProposal(s:Session):string {
  const parsed=parseScenarios(s);
  if(!parsed?.scenarios?.length) throw new Error(`Cannot create strategy fallback because no scenarios were found for issue #${s.issueId}.`);
  const dir=path.join(ROOT,'test-scenarios','strategy');
  fs.mkdirSync(dir,{recursive:true});
  const proposalRel=`test-scenarios/strategy/${s.issueId}-strategy-proposal.md`;
  const proposalFile=path.join(ROOT,proposalRel);

  // Prefer the last approved strategy as the agent recommendation when available.
  // This preserves the user's previously reviewed risk-based selection during a
  // temporary agent/quota outage.
  const priorFile=path.join(ROOT,finalStrategyRel(s));
  const priorText=fs.existsSync(priorFile)?fs.readFileSync(priorFile,'utf8').replace(/\r/g,''):'';
  const priorRecommended=new Set<string>([...priorText.matchAll(/^\|\s*(?:\*\*)?(TC-\d+)\b.*?\|\s*\*\*AUTOMATE(?: \(E2E\))?\*\*/gmi)].map(m=>m[1].toUpperCase()));

  // If there is no prior recommendation, use a conservative local risk rule:
  // P0/P1 scenarios are initially checked; P2 scenarios remain visible but unchecked.
  const recommended=(scenario:any)=>priorRecommended.size?priorRecommended.has(scenario.id.toUpperCase()):/P[01]/i.test(scenario.priority||'');
  const rows=parsed.scenarios.map((scenario:any)=>{
    const automate=recommended(scenario);
    const tier=automate ? (/P0/i.test(scenario.priority)?'Smoke / PR-Blocking':'Nightly Regression') : 'Unit / API';
    const justification=automate
      ? (priorRecommended.size ? 'Carried forward from the previously approved strategy recommendation; review and change the checkbox as needed.' : 'Deterministic fallback recommendation for a high-priority scenario; review and change the checkbox as needed.')
      : 'Visible for review but not initially recommended for E2E automation; review and change the checkbox as needed.';
    return `| **${scenario.id}** | ${scenario.summary} | **${automate?'AUTOMATE (E2E)':'OFFLOAD (Unit/API/Omit)'}** | ${tier} | ${justification} |`;
  });
  const candidates=parsed.scenarios.filter(recommended).map((scenario:any,i:number)=>buildCandidateBlock(s,scenario.id,i+1)).join('\n\n');
  const generatedDate=new Date().toISOString().slice(0,10);
  const content=[
    `# E2E Test Strategy Proposal: Issue #${s.issueId}`,
    '',
    `- **Issue Reference**: #${s.issueId}`,
    `- **Target Folder ID**: ${s.folderId}`,
    `- **Generated Date**: ${generatedDate}`,
    `- **Application Base URL**: ${extractApplicationUrl(s)}`,
    `- **Total Scenarios Analyzed**: ${parsed.scenarios.length}`,
    `- **Agent Recommended for E2E Automation**: ${parsed.scenarios.filter(recommended).length}`,
    '',
    '## 1. Scope & Automation Decision Matrix',
    '',
    '| Scenario ID | Scenario Description | Automation Decision | Tier / Frequency | Justification |',
    '| :--- | :--- | :--- | :--- | :--- |',
    ...rows,
    '',
    '## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)',
    '',
    '### Initially Recommended Test Cases',
    '',
    buildApprovedCasesTable(s, parsed.scenarios.filter(recommended).map((scenario:any)=>scenario.id)),
    '',
    candidates || '_No scenarios were initially recommended. Select one or more checkboxes in the UI before approval._',
    '',
    '## 3. Environment & Mocking Strategy',
    `- **Base URL**: ${extractApplicationUrl(s)}`,
    '- **Mocked Services**: None specified by the scenario artifact.',
    '- **Cleanup Strategy**: Start each test in a fresh browser context and restore the application to a clean state after each scenario.'
  ].join('\n');
  fs.writeFileSync(proposalFile,content,'utf8');
  return proposalRel;
}

function scenarioDetail(s:Session, id:string) {
  const parsed=parseScenarios(s);
  if(!parsed?.artifact)return undefined;
  const text=fs.readFileSync(path.join(ROOT,parsed.artifact),'utf8').replace(/\r/g,'');
  const lines=text.split('\n');
  const idx=lines.findIndex(line=>new RegExp(`^###\\s+${id}\\b`, 'i').test(line));
  if(idx<0)return undefined;
  const end=lines.findIndex((line,i)=>i>idx && (/^###\s+TC-\d+/i.test(line)||/^##\s+\d+\./.test(line)));
  const block=lines.slice(idx,end<0?lines.length:end);
  const heading=block[0].match(/^###\s+(TC-\d+)\s*:\s*(.*)$/i);
  const title=heading?.[2]?.trim() || id;
  const preIdx=block.findIndex(line=>/^[-*]\s+\*\*Preconditions\*\*:/i.test(line));
  const stepsIdx=block.findIndex(line=>/^[-*]\s+\*\*Steps\*\s*:/i.test(line));
  const expectedIdx=block.findIndex(line=>/^[-*]\s+\*\*Expected Results\*\s*:/i.test(line));
  const pre=preIdx>=0 ? block.slice(preIdx+1, Math.max(stepsIdx>=0?stepsIdx:block.length,preIdx+1)).map(x=>x.replace(/^\s*[-*]\s*/,'').trim()).filter(Boolean).join(' ') : 'Environment and application are available for the scenario.';
  const priority=parsed.scenarios.find(x=>x.id.toUpperCase()===id.toUpperCase())?.priority || 'P2';
  const importance=/P0/i.test(priority)?'VERY_HIGH':/P1/i.test(priority)?'HIGH':'MEDIUM';
  const steps:any[]=[];
  if(stepsIdx>=0){
    const stepLines=block.slice(stepsIdx+1,expectedIdx>=0?expectedIdx:block.length);
    for(let i=0;i<stepLines.length;i++){
      const m=stepLines[i].match(/^\s*\d+[.)]\s+(.*)$/);
      if(!m)continue;
      let action=m[1].replace(/\*\*/g,'').trim();
      let expected='Verify the expected outcome for the action.';
      const next=stepLines.slice(i+1).find(x=>/^\s*[-*]\s+\*\*Expected Result\*\*:/i.test(x));
      if(next) expected=next.replace(/^\s*[-*]\s+\*\*Expected Result\*\*:\s*/i,'').replace(/\*\*/g,'').trim();
      steps.push({action,expected});
    }
  }
  if(!steps.length)steps.push({action:`Execute the scenario: ${title}.`,expected:'The scenario behaves as specified in the source scenario document.'});
  return {title,priority,importance,prerequisite:pre,steps};
}

function buildCandidateBlock(s:Session,id:string,index:number,existing?:string) {
  if(existing && /\|\s*#\s*\|\s*Action\s*\|\s*Expected Result\s*\|/i.test(existing)) return existing.replace(/^###\s+Candidate\s+\d+/i,`### Candidate ${index}`);
  const detail=scenarioDetail(s,id);
  if(!detail) throw new Error(`Selected test case ${id} was not found in the scenario artifact.`);
  const escCell=(value:string)=>String(value||'').replace(/\|/g,'\\|').replace(/\r?\n/g,'<br>');
  return [
    `### Candidate ${index}: ${id} - ${detail.title}`,
    '',
    '| Field | Details |',
    '| :--- | :--- |',
    `| **Reference** | ${escCell(id)} |`,
    `| **Squash Folder ID** | ${escCell(String(s.folderId))} |`,
    `| **Importance (Squash Enum)** | ${escCell(detail.importance)} |`,
    `| **Execution Tier** | Regression |`,
    `| **Prerequisite** | ${escCell(detail.prerequisite)} |`,
    `| **Description** | ${escCell(detail.title)} |`,
    '',
    '#### Test Steps',
    '',
    '| # | Action | Expected Result |',
    '| ---: | :--- | :--- |',
    ...detail.steps.map((step:any,i:number)=>`| ${i+1} | ${escCell(step.action)} | ${escCell(step.expected)} |`)
  ].join('\n');
}

function buildApprovedCasesTable(s:Session, ids:string[], proposalRows?:Map<string,string>) {
  const all=parseScenarios(s)?.scenarios||[];
  const rows=ids.map(id=>{
    const scenario=all.find(x=>x.id.toUpperCase()===id.toUpperCase());
    const original=proposalRows?.get(id);
    const parsed=original ? parsePipeRow(original) : undefined;
    const title=parsed?.[1] || scenario?.summary || id;
    const priority=scenario?.priority || 'P2';
    const tier=parsed?.[3] || (/P0/i.test(priority)?'Smoke / PR-Blocking':/P1/i.test(priority)?'Nightly Regression':'Regression');
    return `| **${id}** | ${title} | ${priority} | **AUTOMATE (E2E)** | ${tier} |`;
  });
  return [
    '| Scenario ID | Test Case | Priority | Decision | Tier / Frequency |',
    '| :--- | :--- | :--- | :--- | :--- |',
    ...rows
  ].join('\n');
}

function rewriteApprovedStrategy(s:Session, includedIds:string[], proposalRel:string) {
  if(!proposalRel) throw new Error(`Strategy proposal not found for issue #${s.issueId}.`);
  const selected=[...new Set(includedIds.map(x=>String(x).trim().toUpperCase()).filter(Boolean))];
  if(!selected.length) throw new Error('Select at least one test case before approving the strategy.');
  if(selected.some(id=>!/^TC-\d+$/i.test(id))) throw new Error('Invalid test case selection.');
  const sourceFile=path.join(ROOT,proposalRel); const outputRel=finalStrategyRel(s); const outputFile=path.join(ROOT,outputRel);
  const source=fs.readFileSync(sourceFile,'utf8').replace(/\r/g,''); const lines=source.split('\n'); const selectedSet=new Set(selected);
  const matrixStart=lines.findIndex(x=>/^##\s+1\.\s+Scope\s*&\s*Automation\s+Decision\s+Matrix/i.test(x));
  const section2Start=lines.findIndex(x=>/^##\s+2\.\s+Selected\s+E2E\s+Scenarios/i.test(x));
  const section3Start=lines.findIndex((x,i)=>i>Math.max(matrixStart,section2Start) && /^##\s+3\./.test(x));
  if(matrixStart<0 || section2Start<0) throw new Error('Strategy proposal does not contain the expected decision matrix sections.');

  const proposalRows=new Map<string,string>();
  for(const line of lines.slice(matrixStart,section2Start)){
    const cells=parsePipeRow(line);
    if(cells && /^TC-\d+$/i.test(cells[0]||'') && /^(AUTOMATE|OFFLOAD)\b/i.test(cells[2]||'')) proposalRows.set(cells[0].toUpperCase(),line);
  }
  const all=parseScenarios(s)?.scenarios||[];
  const matrixRows=selected.map(id=>{
    const original=proposalRows.get(id);
    if(original){
      const cells=parsePipeRow(original)!;
      cells[2]='AUTOMATE (E2E)';
      cells[4]=`User selected this case for final E2E automation approval.`;
      return `| **${id}** | ${cells[1]} | **${cells[2]}** | ${cells[3]||'Regression'} | ${cells[4]} |`;
    }
    const scenario=all.find(x=>x.id.toUpperCase()===id);
    if(!scenario) throw new Error(`Selected test case ${id} is not present in the scenario artifact.`);
    return `| **${id}** | ${scenario.summary} | **AUTOMATE (E2E)** | Regression | User selected this case for final E2E automation approval. |`;
  });
  const header=lines.slice(matrixStart,section2Start).filter(line=>!(/^\s*\|\s*\*\*TC-\d+\*\*/i.test(line)) && !/^\s*\|\s*TC-\d+/i.test(line));
  const filteredMatrix=[...header.filter(line=>!/^\s*\|\s*:?[-]+/i.test(line)),...matrixRows];
  // Keep the table header/separator and replace every old decision row with exactly the selected rows.
  const matrixPrefix=lines.slice(matrixStart,section2Start).filter(line=>{
    if(/^\s*\|\s*(?:\*\*)?TC-\d+/i.test(line))return false;
    if(/\*\*Approved for E2E Automation\*\*/i.test(line))return false;
    return true;
  });
  const metadata=lines.slice(0,matrixStart).map(line=>/\*\*Approved for E2E Automation\*\*/i.test(line)?line.replace(/(\*\*Approved for E2E Automation\*\*\s*:\s*)\d+/i,`$1${selected.length}`):line);
  const approvedCount=metadata.some(line=>/\*\*Approved for E2E Automation\*\*/i.test(line))?metadata:metadata.concat(`- **Approved for E2E Automation**: ${selected.length}`);
  const finalMatrix=[...matrixPrefix,...matrixRows];

  const candidateStart=section2Start+1;
  const candidateEnd=section3Start>=0?section3Start:lines.length;
  const candidateMap=new Map<string,string>(); let currentId:string|undefined; let current:string[]=[];
  const flush=()=>{if(currentId)candidateMap.set(currentId,current.join('\n').trim());current=[];currentId=undefined;};
  for(const line of lines.slice(candidateStart,candidateEnd)){
    const h=line.match(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/i);
    if(h){flush();currentId=h[1].toUpperCase();current=[line];continue;}
    if(currentId)current.push(line);
  }
  flush();
  const candidateBlocks=selected.map((id,i)=>buildCandidateBlock(s,id,i+1,candidateMap.get(id)));
  const after=section3Start>=0?lines.slice(section3Start):[];
  const result=[...approvedCount, '', ...finalMatrix, '', '## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)', '', '### Approved Test Cases', '', buildApprovedCasesTable(s, selected, proposalRows), '', ...candidateBlocks, '', ...after]
    .join('\n').replace(/\n{4,}/g,'\n\n\n');
  fs.mkdirSync(path.dirname(outputFile),{recursive:true}); const tempFile=`${outputFile}.approval-${process.pid}-${Date.now()}.tmp`; fs.writeFileSync(tempFile,result,'utf8'); fs.renameSync(tempFile,outputFile);
  return {relativePath:outputRel,localPath:path.resolve(ROOT,outputRel),selectedCount:selected.length};
}

function validateApprovedStrategy(s:Session, rel:string, selectedIds:string[]) {
  const text=fs.readFileSync(path.join(ROOT,rel),'utf8');
  const selected=[...new Set(selectedIds.map(x=>x.toUpperCase()))].sort();
  const lines=text.replace(/\r/g,'').split('\n');
  // Validate the decision matrix only. The final strategy also contains an
  // Approved Test Cases table, which intentionally repeats the same TC IDs.
  // Scanning the entire document therefore falsely reports duplicates.
  const matrixStart=lines.findIndex(x=>/^##\s+1\.\s+Scope\s*&\s*Automation\s+Decision\s+Matrix/i.test(x));
  const section2Start=lines.findIndex((x,i)=>i>matrixStart && /^##\s+2\.\s+Selected\s+E2E\s+Scenarios/i.test(x));
  if(matrixStart<0 || section2Start<0) throw new Error('Approved strategy is missing the decision matrix section.');
  const matrixText=lines.slice(matrixStart,section2Start).join('\n');
  // IDs can legitimately occur more than once in the generated Markdown (for example
  // a matrix row plus a repeated presentation row). Approval is based on the unique
  // test-case IDs, not raw occurrence counts. Never compare the whole document with a
  // global TC-* regex.
  // Parse only actual Decision Matrix rows. A TC ID may also occur in
  // explanatory text or repeated presentation tables; those occurrences must
  // never affect approval validation. De-duplicate IDs defensively.
  const matrixIds=[...new Set([...matrixText.matchAll(/^\|\s*(?:\*\*)?(TC-\d+)(?:\*\*)?\s*\|/gmi)].map(m=>m[1].toUpperCase()))].sort();
  const candidateEnd=lines.findIndex((x,i)=>i>section2Start && /^##\s+3\./.test(x));
  const candidateText=lines.slice(section2Start,candidateEnd>=0?candidateEnd:lines.length).join('\n');
  const candidateIds=[...new Set([...candidateText.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)].map(m=>m[1].toUpperCase()))].sort();
  const sameIds=(a:string[],b:string[])=>a.length===b.length && a.every((id,i)=>id===b[i]);
  if(!sameIds(matrixIds,selected)) throw new Error(`Approved strategy matrix mismatch. Expected only: ${selected.join(', ')}; found: ${matrixIds.join(', ')}.`);
  if(!sameIds(candidateIds,selected)) throw new Error(`Approved strategy candidate mismatch. Expected only: ${selected.join(', ')}; found: ${candidateIds.join(', ')}.`);
  const countMatch=text.match(/\*\*Approved for E2E Automation\*\*\s*:\s*(\d+)/i);
  if(!countMatch || Number(countMatch[1])!==selected.length) throw new Error(`Approved strategy count mismatch. Expected ${selected.length}.`);
}

function parseGeneratedTests(s:Session) {
  const rel=findArtifact(s,[`tests/issue-${s.issueId}.spec.ts`]);
  if(!rel) return [];
  const text=fs.readFileSync(path.join(ROOT,rel),'utf8');
  const cases:any[]=[];
  // Only parse real executable test()/it() declarations. test.describe() is a suite.
  // Support single/double/backtick strings and multiline formatting emitted by generators.
  const re=/(?:^|[\s;])(?:test|it)\s*\(\s*([\'"`])([\s\S]*?)\1\s*,/gm; let m:any;
  while((m=re.exec(text))) {
    const title=String(m[2]||'').trim();
    if(!title || title.startsWith('(')) continue;
    const idMatch=title.match(/\b(TC-\d+)\b/i);
    if(!idMatch) continue;
    const id=idMatch[1].toUpperCase();
    if(cases.some(x=>x.id===id)) continue;
    cases.push({id,title});
  }
  return cases;
}

function generatedExecutionCases(s:Session) {
  const generated=parseGeneratedTests(s);
  const dataRel=findArtifact(s,[`test-data/issue-${s.issueId}.json`]);
  let data:any={};
  if(dataRel){ try { data=JSON.parse(fs.readFileSync(path.join(ROOT,dataRel),'utf8')); } catch {} }
  const dataCases:any[]=[];
  if(Array.isArray(data)) {
    for(const item of data) {
      const id=String(item?.id || item?.reference || '').toUpperCase();
      if(/^TC-\d+$/.test(id)) dataCases.push({id,title:item?.title || item?.name || id});
    }
  } else if(data && typeof data==='object') {
    for(const [key,item] of Object.entries(data)) {
      const id=String((item as any)?.id || key).toUpperCase();
      if(/^TC-\d+$/.test(id)) dataCases.push({id,title:(item as any)?.title || (item as any)?.name || id});
    }
  }
  const merged=[...generated,...dataCases];
  return merged.filter((item:any,index:number,arr:any[])=>arr.findIndex(x=>x.id===item.id)===index)
    .map((item:any)=>({id:item.id,title:String(item.title||item.id).trim() || item.id}));
}

function executionCases(s:Session) {
  const generated=generatedExecutionCases(s);
  const approved=approvedExecutionCases(s);
  const allowed:Map<string,any>|undefined = approved.length ? new Map<string,any>(approved.map((x:any)=>[String(x.id).toUpperCase(),x] as [string,any])) : undefined;
  if(generated.length) {
    return generated.map((item:any)=>({id:item.id,title:item.title || allowed?.get(item.id)?.title || item.id}));
  }
  return approved.map((item:any)=>({id:String(item.id).toUpperCase(),title:String(item.title||item.id).trim() || item.id}));
}

function projectExecutionCatalog() {
  const testsDir=path.join(ROOT,'tests');
  const catalog:any[]=[];
  if(!fs.existsSync(testsDir)) return catalog;
  const walk=(dir:string)=>{
    for(const entry of fs.readdirSync(dir,{withFileTypes:true})) {
      const full=path.join(dir,entry.name);
      if(entry.isDirectory()) walk(full);
      else if(entry.isFile() && /\.spec\.(?:ts|tsx|js|jsx|mjs|cjs)$/i.test(entry.name)) {
        const rel=path.relative(ROOT,full).replace(/\\/g,'/');
        const issueMatch=entry.name.match(/^issue-(\d+)\.spec\./i);
        if(!issueMatch) continue;
        const issueId=issueMatch[1];
        const text=fs.readFileSync(full,'utf8');
        const re=/(?:^|[\s;])(?:test|it)\s*\(\s*([\'"`])([\s\S]*?)\1\s*,/gm;
        let m:any;
        while((m=re.exec(text))) {
          const title=String(m[2]||'').trim();
          const idMatch=title.match(/\b(TC-\d+)\b/i);
          if(!idMatch) continue;
          const id=idMatch[1].toUpperCase();
          const key=`${issueId}::${id}`;
          if(catalog.some(x=>x.key===key)) continue;
          catalog.push({key,issueId,id,title,spec:rel});
        }
      }
    }
  };
  walk(testsDir);
  return catalog.sort((a,b)=>Number(a.issueId)-Number(b.issueId) || a.id.localeCompare(b.id));
}

function executionCatalogForSession(s:Session) {
  const catalog=projectExecutionCatalog();
  return catalog.length ? catalog : executionCases(s).map((x:any)=>({key:`${s.issueId}::${x.id}`,issueId:s.issueId,id:x.id,title:x.title,spec:`tests/issue-${s.issueId}.spec.ts`}));
}

function approvedExecutionCases(s:Session) {
  const strategyOutput:any=s.stages.strategy.output || {};
  const included=Array.isArray(strategyOutput.includedTestCases)
    ? [...new Set(strategyOutput.includedTestCases.map((x:any)=>String(x).trim().toUpperCase()).filter(Boolean))]
    : [];
  const all:any[] = strategyOutput?.proposal?.strategies || strategyOutput?.strategies || [];
  if(included.length) return (included as string[]).map((id:string)=>{
    const row=all.find((x:any)=>String(x.id).toUpperCase()===id);
    return {id, title:row?.description || id};
  });
  if(all.length) return all.filter((x:any)=>/^AUTOMATE\b/i.test(String(x.decision||'')))
    .map((x:any)=>({id:String(x.id).toUpperCase(),title:x.description||x.id}));

  // Backfill selection from the final approved strategy artifact for sessions created
  // by older UI builds that did not persist includedTestCases in stage output.
  const rel=findArtifact(s,[finalStrategyRel(s),`test-scenarios/strategy/${s.issueId}-strategy-proposal.md`]);
  if(!rel) return [];
  try {
    const text=fs.readFileSync(path.join(ROOT,rel),'utf8').replace(/\r/g,'');
    const ids=[...text.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)].map(m=>m[1].toUpperCase());
    if(ids.length) return [...new Set(ids)].map(id=>({id,title:id}));
    return [...new Set([...text.matchAll(/^\|\s*(?:\*\*)?(TC-\d+)(?:\*\*)?\s*\|.*?\|\s*\*\*AUTOMATE(?: \(E2E\))?\*\*/gmi)].map(m=>m[1].toUpperCase()))]
      .map(id=>({id,title:id}));
  } catch { return []; }
}

function requireStage(s:Session,n:StageName){ if(!['ready','completed','failed','waiting_for_approval'].includes(s.stages[n].status)) throw new Error(`Stage ${n} is not ready. Current status: ${s.stages[n].status}`); }

async function startMcp(kind:'gitlab'|'playwright') {
  if(kind==='gitlab' && !runtimeSecrets.gitlabToken) throw new Error('GitLab MCP token is not configured. Enter it in the UI first.');
  if(mcp[kind] && !mcp[kind]!.killed) return;
  const isGitlab=kind==='gitlab';
  // Windows exposes npm's npx shim as npx.cmd. Spawning plain `npx` from Node can fail with ENOENT.
  const defaultCommand = process.platform==='win32' ? 'npx.cmd' : 'npx';
  const command=process.env[isGitlab?'GITLAB_MCP_COMMAND':'PLAYWRIGHT_MCP_COMMAND'] || defaultCommand;
  const args=(process.env[isGitlab?'GITLAB_MCP_ARGS':'PLAYWRIGHT_MCP_ARGS'] || (isGitlab?'-y @zereight/mcp-gitlab':'-y @playwright/mcp@latest --headless')).match(/(?:[^\s"]+|"[^"]*")+/g) || [];
  const env=sanitizedEnv();
  // Runtime UI secret wins and is not persisted. Do not fall back to .env token values.
  if(isGitlab){ env.GITLAB_PERSONAL_ACCESS_TOKEN=runtimeSecrets.gitlabToken!; env.GITLAB_API_URL=env.GITLAB_API_URL||'https://gitlab.com/api/v4'; env.GITLAB_READ_ONLY_MODE=env.GITLAB_READ_ONLY_MODE||'false'; }
  // Windows can return EINVAL when Node tries to spawn the npm .cmd shim directly
  // in some environments. Run the shim through cmd.exe instead; stdio is still
  // passed through unchanged so MCP's stdio transport continues to work.
  let child: ChildProcessWithoutNullStreams;
  if (process.platform === 'win32') {
    const comspec = process.env.ComSpec || process.env.COMSPEC || 'cmd.exe';
    const commandLine = [command, ...args].map(a => /[\s"&|<>^]/.test(a) ? `\"${a.replace(/\"/g, '\\"')}\"` : a).join(' ');
    child = spawn(comspec, ['/d', '/s', '/c', commandLine], { cwd: ROOT, env, stdio: 'pipe', windowsHide: true });
  } else {
    child = spawn(command, args, { cwd: ROOT, env, stdio: 'pipe' });
  }
  mcp[kind]=child;
  child.stderr.on('data',d=>console.error(`[${kind}] ${d}`));
  child.on('error',err=>console.error(`[${kind}] process error: ${err.message}`));
  child.on('exit',()=>{mcp[kind]=undefined;});
}
function stopMcp(kind:'gitlab'|'playwright'){if(mcp[kind]){mcp[kind]!.kill();mcp[kind]=undefined;}}
function mcpStatus(){return {gitlab:!!mcp.gitlab&&!mcp.gitlab.killed,playwright:!!mcp.playwright&&!mcp.playwright.killed};}

async function handle(req:http.IncomingMessage,res:http.ServerResponse){
  const u=new URL(req.url||'/',`http://${req.headers.host}`); const p=u.pathname;
  try {
    if(req.method==='GET' && p==='/api/health') return json(res,200,{ok:true,mcp:mcpStatus()});
    if(req.method==='GET' && p==='/api/artifact'){const requested=u.searchParams.get('path'); if(!requested)return json(res,400,{error:'Artifact path is required'}); return artifactPreview(res,requested);}
    const rp=p.match(/^\/api\/session\/([^/]+)\/report\/([^/]+)(?:\/(.*))?$/); if(req.method==='GET'&&rp){const rs=sessions.get(rp[1]); if(!rs)return json(res,404,{error:'Session not found'}); const rn=rp[2] as StageName; if(!(rn in rs.stages))return json(res,404,{error:'Unknown stage'}); if(rp[3] && rn==='execution' && hasExecutionReport(rs)) return serveReportFile(res,executionReportDir(rs),rp[3]); return stageReport(res,rs,rn);}
    if(req.method==='GET' && p==='/api/mcp/status') return json(res,200,mcpStatus());
    if(req.method==='POST' && p==='/api/secrets'){const b=await readBody(req); if(typeof b.gitlabToken==='string' && b.gitlabToken.trim()) runtimeSecrets.gitlabToken=b.gitlabToken.trim(); if(typeof b.squashToken==='string' && b.squashToken.trim()) runtimeSecrets.squashToken=b.squashToken.trim(); return json(res,200,secretStatus());}
    if(req.method==='POST' && p==='/api/secrets/clear'){runtimeSecrets.gitlabToken=undefined; runtimeSecrets.squashToken=undefined; stopMcp('gitlab'); return json(res,200,secretStatus());}
    if(req.method==='GET' && p==='/api/secrets/status') return json(res,200,secretStatus());
    if(req.method==='POST' && p==='/api/mcp/start'){const b=await readBody(req); const kinds=b.kind==='all'?['gitlab','playwright']:[b.kind]; for(const k of kinds) await startMcp(k); return json(res,200,mcpStatus());}
    if(req.method==='POST' && p==='/api/mcp/stop'){const b=await readBody(req); const kinds=b.kind==='all'?['gitlab','playwright']:[b.kind]; for(const k of kinds) stopMcp(k); return json(res,200,mcpStatus());}
    if(req.method==='POST' && p==='/api/session'){const b=await readBody(req); const issueId=issueIdFromUrl(b.issueUrl||''); const s:Session={id:randomUUID(),issueUrl:b.issueUrl,issueId,folderId:Number(b.folderId||1),appUrl:b.appUrl,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),mcp:mcpStatus(),stages:initStages(),events:[]}; sessions.set(s.id,s); addEvent(s,'session.created',`Session created for issue #${issueId}`); return json(res,201,s);}
    const sm=p.match(/^\/api\/session\/([^/]+)$/); if(req.method==='GET'&&sm){const s=sessions.get(sm[1]); if(!s)return json(res,404,{error:'Session not found'}); s.mcp=mcpStatus(); const catalog=executionCatalogForSession(s); const execOut:any=s.stages.execution.output||{}; if(JSON.stringify(execOut.catalog||[])!==JSON.stringify(catalog)){ stage(s,'execution',{output:{...execOut,catalog}}); } if(s.stages.scriptGeneration.status==='completed'){ const currentCases=executionCases(s); const out:any=s.stages.scriptGeneration.output||{}; if(JSON.stringify(out.executionCases||[])!==JSON.stringify(currentCases)){ stage(s,'scriptGeneration',{output:{...out,executionCases:currentCases}}); } } return json(res,200,s);}
    const stopMatch=p.match(/^\/api\/session\/([^/]+)\/stage\/([^/]+)\/stop$/);
    if(req.method==='POST'&&stopMatch){
      const s=sessions.get(stopMatch[1]); if(!s)return json(res,404,{error:'Session not found'});
      const n=stopMatch[2] as StageName; if(!(n in s.stages))return json(res,400,{error:'Unknown stage'});
      const key=`${s.id}:${n}`; const active=activeRuns.get(key);
      if(s.stages[n].status!=='running' && !active) return json(res,400,{error:`Stage is ${s.stages[n].status}; nothing is running.`});
      if(active){ active.stopRequested=true; killProcessTree(active.child); }
      stage(s,n,{status:'ready',completedAt:new Date().toISOString(),message:'Stopped by user.',error:undefined});
      addEvent(s,'stage.stopped','Stopped by user.',n);
      if(n==='healer') stage(s,n,{status:'ready',message:'Stopped by user. Review the queued cases and run Healer again when ready.'});
      return json(res,200,s);
    }
    const am=p.match(/^\/api\/session\/([^/]+)\/stage\/([^/]+)\/start$/); if(req.method==='POST'&&am){const s=sessions.get(am[1]); if(!s)return json(res,404,{error:'Session not found'}); const n=am[2] as StageName; if(!(n in s.stages))return json(res,400,{error:'Unknown stage'}); requireStage(s,n); const b=await readBody(req); if(b.appUrl)s.appUrl=b.appUrl; stage(s,n,{status:'running',startedAt:new Date().toISOString(),message:n==='healer'?'Preparing the healing proposal for review...':'Started'}); addEvent(s,'stage.started',`Started ${n}`,n);
      try {
        let output:any='';
        if(n==='scenarios'){
          let fallbackReason='';
          try { output=await runConfiguredAgent(n,s); }
          catch(e:any) {
            fallbackReason=e?.message || 'The scenarios agent did not complete.';
            addEvent(s,'stage.progress',`Scenarios agent unavailable; creating a local reviewable scenario artifact instead. Reason: ${fallbackReason}`,n);
          }
          let parsed=parseScenarios(s);
          if(!parsed?.scenarios?.length){
            const rel=await buildFallbackScenarioArtifact(s,fallbackReason || 'The scenarios agent completed without creating a parseable scenario artifact.');
            parsed=parseScenarios(s);
            addEvent(s,'artifact.created',`Scenario description: ${path.resolve(ROOT,rel)}`,n);
          }
          if(!parsed?.scenarios?.length) throw new Error(`Scenario artifact could not be created for issue #${s.issueId}.`);
          if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s);
          const artifact=artifactDetails(parsed.artifact);
          const message=fallbackReason
            ? `Scenario description created at ${artifact!.localPath}. The scenarios agent was unavailable, so a deterministic reviewable fallback was created.`
            : `Scenario description created at ${artifact!.localPath}`;
          stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{...parsed,artifact,raw:output,fallback:!!fallbackReason,fallbackReason},message});
          if(artifact && !fallbackReason)addEvent(s,'artifact.created',`Scenario description: ${artifact.localPath}`,n);
          unlockAfter(s,n);
        }
        else if(n==='strategy'){
          prepareStrategyProposal(s);
          let output='';
          let fallbackReason='';
          try {
            output=await runConfiguredAgent(n,s);
          } catch(e:any) {
            fallbackReason=e?.message || 'The strategy agent did not complete.';
            addEvent(s,'stage.progress',`Strategy agent unavailable; creating a local reviewable proposal instead. Reason: ${fallbackReason}`,n);
          }
          let proposalRel:string;
          try {
            proposalRel=captureStrategyProposal(s);
          } catch(e:any) {
            if(!fallbackReason) fallbackReason=e?.message || 'The strategy proposal was not created.';
            proposalRel=buildFallbackStrategyProposal(s);
          }
          let proposal=parseStrategy(s,proposalRel);
          if(!proposal?.strategies?.length) {
            fallbackReason=fallbackReason || 'The generated strategy proposal contained no decision-matrix rows.';
            proposalRel=buildFallbackStrategyProposal(s);
            proposal=parseStrategy(s,proposalRel);
          }
          const artifact=artifactDetails(proposalRel);
          if(!proposal?.strategies?.length) throw new Error('Strategy proposal could not be created from the scenario artifact.');
          if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s);
          const message=fallbackReason
            ? `Strategy proposal created at ${artifact!.localPath}. The strategy agent was unavailable, so a deterministic reviewable fallback was created. Review the selection before approval.`
            : `Strategy proposal created at ${artifact!.localPath}. Review the selection before approval.`;
          stage(s,n,{status:'waiting_for_approval',output:{proposal,artifact,proposalArtifact:artifact,raw:output,fallback:!!fallbackReason,fallbackReason},message});
          addEvent(s,'artifact.created',`Strategy proposal: ${artifact!.localPath}`,n);
        } else if(n==='squash'){
          // Squash conversion/upload is deterministic and must not depend on Copilot.
          // A Copilot quota/rate-limit error must never block uploading an already
          // approved strategy to Squash TM.
          const strategyRel=findArtifact(s,[finalStrategyRel(s)]);
          if(!strategyRel) throw new Error(`Approved strategy file ${finalStrategyRel(s)} was not found. Approve Test Strategy before running Squash.`);
          const token=runtimeSecrets.squashToken;
          const base=process.env.SQUASH_BASE_URL || 'http://localhost:8080/squash/api/rest/latest/test-cases';
          if(!token) throw new Error('Squash token is not configured. Enter it in the UI first.');
          addEvent(s,'stage.progress','Building Squash TM payload locally from the approved strategy (no Copilot agent required).',n);
          const strategyText=fs.readFileSync(path.join(ROOT,strategyRel),'utf8');
          const selectedIds=[...strategyText.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/gmi)].map(m=>m[1].toUpperCase());
          if(!selectedIds.length) throw new Error('The approved strategy contains no approved Candidate test cases.');
          const payload=selectedIds.map((id)=>{
            const detail=scenarioDetail(s,id);
            if(!detail) throw new Error(`Selected test case ${id} was not found in the scenario artifact.`);
            const html=(value:string)=>`<p>${escapeHtml(String(value||'')).replace(/\n/g,'<br>')}</p>`;
            return {
              _type:'test-case', name:`${id}: ${detail.title}`, reference:id,
              prerequisite:detail.prerequisite, description:html(detail.title), importance:detail.importance,
              status:'WORK_IN_PROGRESS', parent:{_type:'test-case-folder',id:s.folderId || 1},
              steps:detail.steps.map((step:any)=>({_type:'action-step',action:html(step.action),expected_result:html(step.expected)}))
            };
          });
          const squashDir=path.join(ROOT,'test-scenarios','squash'); fs.mkdirSync(squashDir,{recursive:true});
          const rel=`test-scenarios/squash/testcase_${s.issueId}.json`; const file=path.join(ROOT,rel);
          fs.writeFileSync(file,JSON.stringify(payload,null,2),'utf8');
          const artifact=artifactDetails(rel);
          addEvent(s,'artifact.created',`Squash payload created from approved strategy: ${artifact!.localPath}`,n);
          addEvent(s,'stage.progress',`Uploading ${payload.length} approved test case(s) to Squash TM...`,n);
          const {request}=require('@playwright/test'); const api=await request.newContext({extraHTTPHeaders:{Accept:'application/json','Content-Type':'application/json',Authorization:`Bearer ${token}`}});
          const results=[];
          try {
            for(const tc of payload){ const r=await api.post(base,{data:tc}); results.push({reference:tc.reference,status:r.status(),body:await r.text()}); }
          } finally { await api.dispose(); }
          const failed=results.filter((x:any)=>x.status<200||x.status>=300);
          if(failed.length) throw new Error(`${failed.length} Squash upload(s) failed.`);
          if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s);
          stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{payload:artifact,uploaded:results.length,results,sourceStrategy:artifactDetails(strategyRel)},message:`Uploaded ${results.length} approved test cases from ${artifact!.localPath}`});
          unlockAfter(s,n);
        }
        else if(n==='scriptGeneration'){ output=await runConfiguredAgent(n,s,{APP_URL:s.appUrl||''}); if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s); const testData=artifactDetails(findArtifact(s,[`test-data/issue-${s.issueId}.json`])); const spec=artifactDetails(findArtifact(s,[`tests/issue-${s.issueId}.spec.ts`])); const pages=fs.existsSync(path.join(ROOT,'pages'))?fs.readdirSync(path.join(ROOT,'pages')).filter(x=>x.endsWith('.page.ts')).map(x=>artifactDetails(path.join('pages',x))):[]; const executionList=executionCases(s); stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{raw:output,artifacts:{testData,spec,pages},testCases:parseGeneratedTests(s),executionCases:executionList},message:`Generated artifacts in ${path.resolve(ROOT,'test-data')} and ${path.resolve(ROOT,'tests')}`}); [testData,spec,...pages].filter(Boolean).forEach((artifact:any)=>addEvent(s,'artifact.created',`Generated artifact: ${artifact.localPath}`,n)); addEvent(s,'stage.progress',`Execution selector prepared with ${executionList.length} approved test case(s).`,n); unlockAfter(s,n); }
        else if(n==='execution'){
          const catalog=executionCatalogForSession(s);
          const selectedKeys=Array.isArray(b.testCases)?[...new Set<string>(b.testCases.filter((x:any)=>typeof x==='string'&&x.trim()).map((x:string)=>x.trim()))]:[];
          if(!selectedKeys.length) throw new Error('Select at least one test case before starting execution.');
          const selected=catalog.filter((tc:any)=>selectedKeys.includes(tc.key));
          const unknown=selectedKeys.filter((key:string)=>!catalog.some((tc:any)=>tc.key===key));
          if(unknown.length) throw new Error(`Selected test case(s) are not present in the project execution catalog: ${unknown.join(', ')}`);
          const specSet=[...new Set(selected.map((x:any)=>x.spec))] as string[];
          if(!specSet.length) throw new Error('No executable Playwright spec was found for the selected test case(s).');
          const workerCount=Number(b.workers);
          if(!Number.isInteger(workerCount) || workerCount<1 || workerCount>128) throw new Error('Workers must be a whole number between 1 and 128.');
          const headless=b.headless!==false;
          const selectedIds=selected.map((x:any)=>x.key);
          const selectedTitles=selected.map((x:any)=>x.title);
          const previousResults:any[] = Array.isArray((s.stages.execution.output as any)?.executionCaseResults) ? (s.stages.execution.output as any).executionCaseResults : [];
          const previousRun=previousResults.length>0;
          const executionCaseStatuses=catalog.map((x:any)=>({key:x.key,id:x.id,title:x.title,spec:x.spec,status:selectedIds.includes(x.key)?'running':(previousRun?'not_run':'not_started')}));
          stage(s,n,{output:{...(s.stages[n].output as any||{}),catalog,selectedTestCases:selectedIds,selectedTestTitles:selectedTitles,executionCaseStatuses,workers:workerCount,headless}});
          addEvent(s,'stage.progress',`Running ${selected.length} selected project test case(s) in ${b.headless===false?'headed':'headless'} mode across ${specSet.length} spec file(s)${b.workers?` using ${b.workers} worker(s)`:''}...`,n);
          // Validate the exact files that Playwright is about to execute before
          // starting the browser. This prevents a stale/partial generated suite from
          // being mistaken for a valid execution and makes missing POM imports visible
          // in the Execution stage and Test Healer.
          const resolveSourceImport=(fromFile:string, specifier:string):string|undefined=>{
            if(!specifier.startsWith('.')) return undefined;
            const base=path.resolve(path.dirname(fromFile),specifier);
            const candidates=[base,...['.ts','.tsx','.js','.jsx','.mjs','.cjs','.json'].map(ext=>base+ext),...['index.ts','index.tsx','index.js','index.jsx','index.mjs','index.cjs','index.json'].map(name=>path.join(base,name))];
            return candidates.find(file=>fs.existsSync(file)&&fs.statSync(file).isFile());
          };
          const findMissingImports=(entryFiles:string[])=>{
            const missing:string[]=[]; const visited=new Set<string>(); const importRe=/(?:import\s+(?:[^'\"]+?\s+from\s+)?|export\s+(?:[^'\"]+?\s+from\s+)?|require\s*\(\s*|import\s*\(\s*)(['\"])([^'\"]+)\1/g;
            const walk=(file:string)=>{
              const abs=path.resolve(ROOT,file); if(visited.has(abs)||!fs.existsSync(abs)||!fs.statSync(abs).isFile()) return; visited.add(abs);
              let text=''; try{text=fs.readFileSync(abs,'utf8')}catch{return;}
              let m:any; while((m=importRe.exec(text))){ const specifier=String(m[2]||''); if(!specifier.startsWith('.')) continue; const resolved=resolveSourceImport(abs,specifier); if(!resolved){ missing.push(`${path.relative(ROOT,abs).replace(/\\/g,'/')} -> ${specifier}`); } else { walk(resolved); } }
            };
            entryFiles.forEach(walk);
            return [...new Set(missing)];
          };
          const missingImports=findMissingImports(specSet);
          addEvent(s,'stage.progress',`Execution workspace: ${path.resolve(ROOT)}`,n);
          addEvent(s,'stage.progress',`Playwright spec file(s): ${specSet.map(x=>path.resolve(ROOT,x)).join(', ')}`,n);
          if(missingImports.length){
            const detail=missingImports.join('; ');
            addEvent(s,'backend.error',`Execution preflight found missing local imports: ${detail}`,n);
            const impacted=selected.map((x:any)=>({id:x.id,title:x.title,key:x.key,spec:x.spec,error:`Missing generated/local dependency: ${detail}`}));
            const impactedStatuses=catalog.map((x:any)=>({key:x.key,id:x.id,title:x.title,spec:x.spec,status:selectedIds.includes(x.key)?'failed':(previousRun?'not_run':'not_started')}));
            stage(s,n,{status:'failed',completedAt:new Date().toISOString(),output:{catalog,selectedTestCases:selectedIds,selectedTestTitles:selectedTitles,specs:specSet,preflight:{missingImports},executionCaseResults:impacted,executionCaseStatuses:impactedStatuses,failedTestCases:impacted},message:`Execution failed before Playwright could run: ${missingImports.length} local dependency import(s) are missing.`,error:`Missing local dependency: ${detail}`});
            stage(s,'healer',{status:'ready',output:{failedTestCases:impacted},message:`${impacted.length} selected test case(s) are impacted by missing local dependencies.`});
            stage(s,'gitlabCommit',{status:'ready'});
            addEvent(s,'stage.progress',`Test Healer queue prepared with ${impacted.length} impacted test case(s).`,'healer');
            return json(res,200,s);
          }
          let output=''; let executionExitCode=0; let executionSignal=''; let executionProcessError=''; await new Promise<void>((resolve)=>{
            const env=sanitizedEnv();
            fs.mkdirSync(path.join(ROOT,'test-results'),{recursive:true});
            fs.mkdirSync(path.join(ROOT,'playwright-report',`execution-${s.id}`),{recursive:true});
            env.PW_JSON_REPORT_FILE=path.join(ROOT,'test-results',`execution-${s.id}.json`);
            env.PW_HTML_REPORT_DIR=path.join(ROOT,'playwright-report',`execution-${s.id}`);
            env.PLAYWRIGHT_HTML_OPEN='never';
            // Do not pass --reporter=json here. CLI --reporter overrides the reporters
            // configured in playwright.config.ts and was the reason the HTML report was
            // silently not produced. The config writes both HTML and JSON reporters.
            // Never route the Playwright test command through cmd.exe/npx on Windows.
            const playwrightCli=require.resolve('@playwright/test/cli');
            const playwrightArgs=['test',...specSet];
            if(Number.isFinite(workerCount) && workerCount>0) playwrightArgs.push('--workers',String(workerCount));
            if(!headless) playwrightArgs.push('--headed');
            if(selected.length){
              const patterns=selected.map((x:any)=>String(x.id).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'));
              playwrightArgs.push('--grep',`(?:${[...new Set(patterns)].join('|')})`);
            }
            addEvent(s,'backend.stdout',`Playwright argv: ${JSON.stringify([process.execPath,playwrightCli,...playwrightArgs])}`,n);
            const child=spawn(process.execPath,[playwrightCli,...playwrightArgs],{cwd:ROOT,env,stdio:'pipe',windowsHide:process.platform==='win32'});
            const executionRunKey=`${s.id}:${n}`;
            activeRuns.set(executionRunKey,{child,stopRequested:false});
            let stdout=''; let stderr='';
            child.stdout.on('data',data=>{const text=String(data); stdout+=text; text.split(/\r?\n/).filter(Boolean).forEach((line:string)=>addEvent(s,'backend.stdout',line,n));});
            child.stderr.on('data',data=>{const text=String(data); stderr+=text; text.split(/\r?\n/).filter(Boolean).forEach((line:string)=>addEvent(s,'backend.stderr',line,n));});
            child.on('error',(err:any)=>{const run=activeRuns.get(executionRunKey); const stopped=!!run?.stopRequested; activeRuns.delete(executionRunKey); if(!stopped){executionProcessError=err.message; addEvent(s,'backend.error',`Playwright process error: ${err.message}`,n);} output=`${stdout}\n${stderr}`.trim(); resolve();});
            child.on('close',(code,signal)=>{const run=activeRuns.get(executionRunKey); const stopped=!!run?.stopRequested; activeRuns.delete(executionRunKey); executionExitCode=typeof code==='number'?code:1; executionSignal=signal||''; output=`${stdout}\n${stderr}`.trim(); if(stopped){executionExitCode=1; executionSignal='SIGSTOP'; addEvent(s,'stage.stopped','Playwright execution stopped by user.',n);} else if(executionExitCode!==0) addEvent(s,'backend.error',`Playwright process exited with code ${executionExitCode}${executionSignal?` (${executionSignal})`:''}.`,n); resolve();});
          });
          if(s.stages.execution.status==='ready' && s.stages.execution.message==='Stopped by user.') { addEvent(s,'stage.progress','Execution stopped before results were collected.',n); return json(res,200,s); }
          if(executionProcessError) throw new Error(`Playwright process could not be started: ${executionProcessError}`);
          let parsed:any={raw:output};
          const resultFile=path.join(ROOT,'test-results',`execution-${s.id}.json`);
          if(fs.existsSync(resultFile)){try{parsed=JSON.parse(fs.readFileSync(resultFile,'utf8'));}catch{}}
          const resultArtifact=artifactDetails(fs.existsSync(resultFile)?path.join('test-results',`execution-${s.id}.json`):undefined);
          const htmlReportPath=path.join(ROOT,'playwright-report',`execution-${s.id}`,'index.html');
          const htmlReportExists=fs.existsSync(htmlReportPath) && fs.statSync(htmlReportPath).isFile();
          if(!htmlReportExists){
            addEvent(s,'backend.error',`Playwright HTML report was not generated at ${htmlReportPath}.`,n);
            executionExitCode=executionExitCode===0 ? 1 : executionExitCode;
          } else {
            addEvent(s,'artifact.created',`Playwright HTML report: ${htmlReportPath}`,n);
          }
          const reportText=JSON.stringify(parsed);
          const reportHasFailedTests=/\"status\":\"failed\"/.test(reportText);
          const reportHasErrors=Array.isArray(parsed?.errors) && parsed.errors.length>0;
          const failed=reportHasFailedTests || reportHasErrors || executionExitCode!==0;
          if(executionExitCode!==0) addEvent(s,'backend.error',`Playwright execution failed with exit code ${executionExitCode}${executionSignal?` (${executionSignal})`:''}.`,n);

          // Build the healer queue from actual Playwright results. A module/import
          // failure can happen before Playwright collects any tests, leaving suites
          // empty. Those selected cases are still impacted and must be visible to
          // Test Healer.
          const reportCaseStatuses=new Map<string,any>();
          const collectReportCases=(suites:any[])=>{
            for(const suite of suites||[]) {
              for(const sp of suite?.specs||[]) {
                const idMatch=String(sp?.title||'').match(/\b(TC-\d+)\b/i);
                const id=idMatch?.[1]?.toUpperCase();
                const tests=Array.isArray(sp?.tests)?sp.tests:[];
                const failedTest=tests.find((t:any)=>String(t?.status||'').toLowerCase()==='unexpected' || String(t?.results?.at?.(-1)?.status||'').toLowerCase()==='failed');
                const allErrors:any[]=[];
                for(const test of tests){
                  for(const result of (Array.isArray(test?.results)?test.results:[])){
                    const resultErrors=Array.isArray(result?.errors)?result.errors:[];
                    for(const err of resultErrors){
                      if(err?.message || err?.stack) allErrors.push({message:String(err?.message||''),stack:String(err?.stack||''),location:err?.location});
                    }
                    if(result?.error?.message || result?.error?.stack) allErrors.push({message:String(result.error.message||''),stack:String(result.error.stack||''),location:result.error.location});
                  }
                }
                const detailParts=allErrors.map((e:any)=>[e.message,e.stack && e.stack!==e.message?e.stack:'',e.location?.file?`Location: ${e.location.file}:${e.location.line||''}:${e.location.column||''}`:''].filter(Boolean).join('\n')).filter(Boolean);
                const errorDetail=detailParts.join('\n\n');
                if(id) reportCaseStatuses.set(id,{failed:!!failedTest || sp?.ok===false,title:String(sp?.title||id),error:errorDetail,errorDetails:allErrors});
                if(Array.isArray(sp?.suites)) collectReportCases(sp.suites);
              }
              if(Array.isArray(suite?.suites)) collectReportCases(suite.suites);
            }
          };
          collectReportCases(parsed?.suites||[]);
          const primaryIssue=selected[0]?.issueId || s.issueId;
          const executionCaseResults=selected.filter((x:any)=>x.issueId===primaryIssue).map((x:any)=>{
            const result=reportCaseStatuses.get(String(x.id).toUpperCase());
            return {id:x.id,title:x.title,key:x.key,spec:x.spec,status:result?.failed?'failed':'passed',error:result?.error||'',errorDetails:result?.errorDetails||[]};
          });
          let failedTestCases=executionCaseResults.filter((x:any)=>x.status==='failed');
          // If execution failed before per-test results existed, every selected
          // case is an impacted case for this run (for example missing POM import).
          if(failed && !failedTestCases.length) {
            const errorMessage=reportHasErrors ? String(parsed?.errors?.[0]?.message||'Playwright failed before test execution.') : 'Playwright execution failed before a per-test result was produced.';
            failedTestCases=selected.filter((x:any)=>x.issueId===primaryIssue).map((x:any)=>({id:x.id,title:x.title,key:x.key,spec:x.spec,status:'failed',error:errorMessage,errorDetails:[{message:errorMessage,stack:'',location:undefined}] }));
            executionCaseResults.splice(0,executionCaseResults.length,...failedTestCases);
            addEvent(s,'stage.progress',`Test Healer queue prepared with ${failedTestCases.length} impacted test case(s).`,'healer');
          }
          const completedCaseStatuses=catalog.map((x:any)=>{
            const result=executionCaseResults.find((r:any)=>r.key===x.key);
            return {key:x.key,id:x.id,title:x.title,spec:x.spec,status:result?(result.status==='failed'?'failed':'completed'):(selectedIds.includes(x.key)?'failed':((previousRun||executionCaseResults.length)?'not_run':'not_started'))};
          });
          stage(s,n,{status:failed?'failed':'completed',completedAt:new Date().toISOString(),output:{catalog,selectedTestCases:selectedIds,selectedTestTitles:selectedTitles,specs:specSet,workers:workerCount,headless,result:resultArtifact,report:parsed,reportPath:htmlReportPath,reportUrl:htmlReportExists?`/api/session/${s.id}/report/execution`:undefined,resultUrl:`/api/session/${s.id}/report/execution`,executionCaseResults,executionCaseStatuses:completedCaseStatuses,failedTestCases},message:`Test execution ${failed?'failed':'completed'}${selected.length?` for ${selected.length} selected project test case(s)`:''}.`,error:failed?(reportHasErrors?String(parsed?.errors?.[0]?.message||'Playwright execution failed.'):htmlReportExists?'Test failures detected; Test Healer is ready with the impacted test cases.':'Playwright HTML report was not generated.'):undefined});
          if(resultArtifact)addEvent(s,'artifact.created',`Test results: ${resultArtifact.localPath}`,n);
          stage(s,'healer',{status:failed && failedTestCases.length?'ready':'not_required',output:{failedTestCases},message:failed && failedTestCases.length?`${failedTestCases.length} impacted test case(s) are ready for healing.`:'No failed test cases; Test Healer is not required.'});
          stage(s,'gitlabCommit',{status:'ready'});
        }
        else if(n==='healer'){
          const failedTestCases=Array.isArray((s.stages.healer.output as any)?.failedTestCases)?(s.stages.healer.output as any).failedTestCases:[];
          if(!failedTestCases.length) throw new Error('No failed test cases are available for Test Healer. Run Test Execution and select at least one failing or impacted test case.');
          const failedContext=failedTestCases.map((x:any)=>`${x.id} | ${x.title} | ${x.spec}${x.error?` | ${x.error}`:''}`).join('\n');
          output=await runConfiguredAgent(n,s,{FAILED_TEST_CASES:failedContext});
          if(s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.') return json(res,200,s);
          const proposalMarkdown=extractHealerProposal(output);
          if(!proposalMarkdown){
            stage(s,n,{status:'failed',output:{raw:output,failedTestCases},message:'Healer agent completed but did not return a reviewable healing proposal.',error:'No healing proposal was returned by the healer agent.'});
            throw new Error('Healer agent completed but did not return a reviewable healing proposal.');
          }
          const proposalHtml=markdownToHtml(proposalMarkdown);
          stage(s,n,{status:'waiting_for_approval',output:{raw:output,failedTestCases,proposal:proposalMarkdown,proposalMarkdown,proposalHtml},message:'Healing proposal generated. Review the proposal below before approving the repair.'});
          addEvent(s,'stage.progress','Healing proposal captured and displayed for approval review.','healer');
        }
        else if(n==='gitlabCommit'){ const result=execFileSync(process.platform==='win32'?'git.cmd':'git',['status','--short'],{cwd:ROOT,encoding:'utf8'}); const repositoryPath=path.resolve(ROOT); addEvent(s,'stage.progress',`Preparing commit from ${repositoryPath}...`,n); stage(s,n,{status:'waiting_for_approval',output:{repositoryPath,gitStatus:result,branch:`test/issue-${s.issueId}-e2e`,commitMessage:`test(e2e): add automated E2E test suite and POM for issue #${s.issueId}`},message:`Review changes in ${repositoryPath} before approval.`}); }
        addEvent(s,'stage.waiting_or_completed',`Finished ${n}`,n); return json(res,200,s);
      } catch(e:any){
        if(String(e?.message||'').includes('stopped by user') || (s.stages[n].status==='ready' && s.stages[n].message==='Stopped by user.')) {
          stage(s,n,{status:'ready',message:'Stopped by user.',error:undefined,completedAt:new Date().toISOString()});
          addEvent(s,'stage.stopped','Stage stopped by user; no failure recorded.',n);
          return json(res,200,s);
        }
        stage(s,n,{status:'failed',error:e.message,message:`Failed: ${e.message}`,completedAt:new Date().toISOString()}); addEvent(s,'stage.failed',e.message,n); return json(res,500,{error:e.message,session:s});
      }
    }
    const approval=p.match(/^\/api\/session\/([^/]+)\/stage\/([^/]+)\/(approve|reject)$/); if(req.method==='POST'&&approval){const s=sessions.get(approval[1]); if(!s)return json(res,404,{error:'Session not found'}); const n=approval[2] as StageName; const action=approval[3]; if(!['strategy','healer','gitlabCommit'].includes(n))return json(res,400,{error:'Stage has no approval endpoint'}); if(s.stages[n].status!=='waiting_for_approval')return json(res,400,{error:`Stage is ${s.stages[n].status}`}); const body=await readBody(req); const includedIds:string[]=Array.isArray(body.includedTestCases)?[...new Set<string>(body.includedTestCases.filter((x:any)=>typeof x==='string'&&x.trim()).map((x:string)=>x.trim()))]:[]; const included=includedIds.join(', ');
      if(action==='reject'){stage(s,n,{status:'ready',message:'Rejected; ready to run again'}); addEvent(s,'approval.rejected',`Rejected ${n}`,n); return json(res,200,s);}
      const approvalKey=`${s.id}:${n}`; if(approvalLocks.has(approvalKey)) return json(res,409,{error:'Approval is already being processed.'}); approvalLocks.add(approvalKey);
      try { if(n==='strategy'){
          const proposalRel=String((s.stages.strategy.output as any)?.proposalArtifact?.relativePath || strategyProposalRel(s) || '');
          if(!proposalRel || !fs.existsSync(path.join(ROOT,proposalRel))) throw new Error('Strategy proposal is missing. Re-run Test Strategy before approving.');
          const proposal=parseStrategy(s,proposalRel);
          const available=new Set((proposal?.strategies||[]).map((x:any)=>String(x.id).toUpperCase()));
          const invalid=includedIds.filter((id:string)=>!available.has(id.toUpperCase()));
          if(invalid.length) throw new Error(`Selected test case(s) are not present in the strategy proposal: ${invalid.join(', ')}`);
          addEvent(s,'stage.progress',`Applying UI-approved selection (${includedIds.length} case(s)); strategy agent will NOT be rerun...`,n);
          const approved=rewriteApprovedStrategy(s,includedIds,proposalRel);
          validateApprovedStrategy(s,approved.relativePath,includedIds);
          // Remove the proposal after the final artifact passes validation so downstream
          // agents cannot accidentally consume the pre-approval recommendation.
          try { fs.unlinkSync(path.join(ROOT,proposalRel)); } catch {}
          const parsed=parseStrategy(s,approved.relativePath);
          const artifact=artifactDetails(approved.relativePath);
          stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{proposal:parsed,artifact,includedTestCases:includedIds},message:`Approved strategy contains exactly ${includedIds.length} selected test case(s): ${artifact!.localPath}`});
          addEvent(s,'strategy.selection',`UI-approved test cases: ${includedIds.join(', ')}`,n);
          addEvent(s,'artifact.updated',`Final strategy written from UI selection only: ${artifact!.localPath}`,n);
          unlockAfter(s,n);
        }
        else if(n==='healer'){
          const prior:any=s.stages.healer.output||{};
          const approvedAt=new Date().toISOString();
          const proposalForApproval=String(prior.proposalMarkdown||prior.proposal||'').trim();
          // Approval is a user decision; keep that state visible immediately while the
          // healer agent applies the approved proposal in the background. The exact proposal
          // is passed to the agent so approval does not trigger a second diagnosis/search loop.
          stage(s,n,{status:'running',startedAt:approvedAt,output:{...prior,approvalStatus:'approved',proposalStatus:'approved',approvedAt},message:'Approved by user. Test Healer is applying the approved repair.'});
          addEvent(s,'approval.approved','Healing proposal approved by user. Test Healer is applying the approved repair.','healer');
          void (async()=>{
            try {
              const out=await runConfiguredAgent('healer',s,{APPROVAL:'approved',HEALING_PROPOSAL:JSON.stringify(proposalForApproval)});
              stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{...prior,raw:out,approvalStatus:'approved',proposalStatus:'approved',approvedAt},message:'Approved by user. Healing changes were applied. Re-run Test Execution to verify.'});
              stage(s,'execution',{status:'ready',message:'Ready to run again after healer approval.'});
              addEvent(s,'stage.completed','Test Healer completed the approved repair.','healer');
            } catch(e:any) {
              stage(s,n,{status:'failed',completedAt:new Date().toISOString(),output:{...prior,approvalStatus:'approved',proposalStatus:'approved',approvedAt},message:`Approval was accepted, but applying the healing repair failed: ${e?.message||'Unknown error'}`,error:e?.message||'Healing repair failed.'});
              addEvent(s,'stage.failed',`Approved healing repair failed: ${e?.message||'Unknown error'}`,'healer');
            } finally { approvalLocks.delete(approvalKey); }
          })();
          return json(res,202,s);
        }
        else { const branch=`test/issue-${s.issueId}-e2e`; const commit=`test(e2e): add automated E2E test suite and POM for issue #${s.issueId}`; addEvent(s,'stage.progress',`Creating branch ${branch}...`,n); execFileSync('git',['checkout','-B',branch],{cwd:ROOT,stdio:'pipe'}); addEvent(s,'stage.progress','Staging generated artifacts...',n); execFileSync('git',['add','test-scenarios','test-data','pages','tests','.github/agents'],{cwd:ROOT,stdio:'pipe'}); addEvent(s,'stage.progress','Creating commit and pushing to origin...',n); execFileSync('git',['commit','-m',commit],{cwd:ROOT,stdio:'pipe'}); execFileSync('git',['push','-u','origin',branch],{cwd:ROOT,stdio:'pipe'}); stage(s,n,{status:'completed',completedAt:new Date().toISOString(),output:{repositoryPath:path.resolve(ROOT),branch,commit},message:`Committed and pushed from ${path.resolve(ROOT)}.`}); }
        addEvent(s,'approval.approved',`Approved ${n}`,n); return json(res,200,s);
      }catch(e:any){stage(s,n,{status:'failed',error:e.message}); addEvent(s,'stage.failed',e.message,n); return json(res,500,{error:e.message,session:s});}
      finally { approvalLocks.delete(approvalKey); }
    }
    if(req.method==='GET'){let file=p==='/'?'/index.html':p; const fp=path.join(UI_ROOT,path.normalize(file)); if(!fp.startsWith(UI_ROOT))return json(res,403,{error:'Forbidden'}); if(fs.existsSync(fp)&&fs.statSync(fp).isFile()){const ext=path.extname(fp); const ct=ext==='.html'?'text/html':ext==='.js'?'text/javascript':ext==='.css'?'text/css':'application/octet-stream';res.writeHead(200,{'Content-Type':ct});return res.end(fs.readFileSync(fp));}}
    json(res,404,{error:'Not found'});
  }catch(e:any){json(res,500,{error:e.message||'Internal server error'});}
}

ensureState();
const server=http.createServer(handle); server.listen(PORT,()=>console.log(`Automation Control Center v16: http://localhost:${PORT}`));
process.on('SIGINT',()=>{stopMcp('gitlab');stopMcp('playwright');server.close(()=>process.exit(0));});
