import fs from 'node:fs';
import path from 'node:path';

export interface ScenarioFallbackContext {
  issueId: string;
  issueUrl?: string;
  appUrl?: string;
}

export function buildFallbackScenarios(context: ScenarioFallbackContext, root = path.resolve(__dirname, '..', '..')): string {
  const dir = path.join(root, 'test-scenarios', 'scenarios');
  fs.mkdirSync(dir, { recursive: true });

  const rel = `test-scenarios/scenarios/issue-${context.issueId}.md`;
  const file = path.join(root, rel);
  const cases = [
    ['TC-001', 'Core Workflow', `Verify the primary user journey tied to issue #${context.issueId} can be reached and completed successfully from the configured application URL.`, 'P1', 'Smoke / PR-Blocking'],
    ['TC-002', 'Error/Validation', `Exercise the expected validation or error path so the issue’s failure mode is visible and recoverable for the user.`, 'P2', 'Nightly Regression'],
    ['TC-003', 'Regression Confidence', `Confirm a refresh/retry or alternate route leaves the application in a consistent state without duplicating user-visible side effects.`, 'P2', 'Nightly Regression']
  ];

  const rows = cases.map(([id, category, summary, priority, layer]) => `| **${id}** | ${category} | ${summary} | ${priority} | ${layer} |`);

  const lines = [
    `# E2E Test Scenarios: Issue #${context.issueId}`,
    '',
    `- **Issue Reference**: #${context.issueId}`,
    `- **Issue URL**: ${context.issueUrl || 'Not provided'}`,
    `- **Application Base URL**: ${context.appUrl || 'Not provided'}`,
    `- **Generated Date**: ${new Date().toISOString().slice(0, 10)}`,
    `- **Agent Status**: The scenario generation agent or Copilot runtime was unavailable; this deterministic fallback artifact was created locally instead.`,
    '',
    '| Scenario ID | Category | Scenario Description | Priority | Suggested Layer |',
    '| --- | --- | --- | --- | --- |',
    ...rows,
    '',
    '## Notes',
    '',
    '- Review and refine these scenario rows in the UI before approving the strategy.',
    '- These records are designed to keep downstream stages such as Strategy, Squash TM upload, and Playwright spec generation moving even when the external AI service is quota-limited.'
  ];

  fs.writeFileSync(file, lines.join('\n'), 'utf8');
  return rel;
}
