const { spawn } = require('node:child_process');

const agents = {
  scenarios: 'create-scenarios',
  strategy: 'test-strategy',
  squash: 'squash-user',
  scriptGeneration: 'script-generator',
  healer: 'test-healer'
};
const instructionFiles = {
  scenarios: '.github/agents/test-scenarios-agent.md',
  strategy: '.github/agents/test-strategy-agent.md',
  squash: '.github/agents/squash-user.agent.md',
  scriptGeneration: '.github/agents/script-generator-agent.md',
  healer: '.github/agents/test-healer-agent.md'
};

const stage = process.env.STAGE;
const agent = agents[stage];
if (!agent) {
  process.stderr.write(`Unsupported agent stage: ${stage || '(missing)'}\n`);
  process.exit(2);
}

if (stage === 'strategy' && process.env.APPROVAL === 'approved') {
  process.stdout.write('Strategy approval is handled by the UI/backend; strategy agent is not rerun.\n');
  process.exit(0);
}

const issue = process.env.ISSUE_URL || process.env.ISSUE_ID;
const proposal = process.env.HEALING_PROPOSAL || '';
const approval = process.env.APPROVAL === 'approved'
  ? ` Approval has been granted. Apply ONLY the exact approved healing proposal supplied below; do not perform a second diagnosis or invent additional changes. Verify the repair once and then stop.\nAPPROVED HEALING PROPOSAL:\n${proposal || '(proposal text unavailable)'}`
  : '';
const selectedCases = process.env.INCLUDED_TEST_CASES || '';
const failedTestCases = process.env.FAILED_TEST_CASES || '';
const healerInstruction = stage === 'healer'
  ? ` The backend has already identified the failed or impacted test cases below. Treat this list as authoritative. Do NOT spend time searching for test-results/[ISSUE_ID].json if it is absent, do NOT search unrelated issue IDs, and do NOT broad-scan the repository. Start with the referenced spec/page object and the supplied stack trace. Use Playwright MCP only when live DOM evidence is needed. Keep the diagnosis to one focused pass and return a concise reviewable proposal.\nFAILED TEST CASE CONTEXT:\n${failedTestCases || '(none)'}`
  : '';
const selectionInstruction = stage === 'strategy' && process.env.APPROVAL === 'approved'
  ? ` The user has explicitly approved this final E2E selection: ${selectedCases || '(none)'}. Treat this list as authoritative: only these IDs may be AUTOMATE (E2E) in the final strategy; every other evaluated scenario must remain OFFLOAD/not selected. The final approved document must contain only the user-selected test cases; do not restore or re-add unchecked test cases.`
  : '';
const generationGuard = stage === 'scriptGeneration'
  ? ' This is the Script Generation stage only: generate and validate test-data, POMs, and the Playwright spec. DO NOT run any Playwright test command, do not use --headed, and do not open a visible browser. Test Execution will run the generated spec later. Keep progress concise so the control-center logs remain useful.'
  : '';
const prompt = `Follow the instructions in @${instructionFiles[stage]} and perform the ${agent} stage for GitLab issue ${issue}. The issue ID is ${process.env.ISSUE_ID}. The application URL is ${process.env.APP_URL || '(not provided)'}. The Squash folder ID is ${process.env.FOLDER_ID || '1'}.${approval}${selectionInstruction}${healerInstruction}${generationGuard} Complete the stage and create the artifacts required by those instructions.`;
const mcpServers = {
  ...(stage === 'healer' ? {} : {
    'GitLab-MCP': {
      type: 'stdio',
      command: process.platform === 'win32' ? 'npx.cmd' : 'npx',
      args: ['-y', '@zereight/mcp-gitlab'],
      env: {
        GITLAB_PERSONAL_ACCESS_TOKEN: '${GITLAB_PERSONAL_ACCESS_TOKEN}',
        GITLAB_API_URL: process.env.GITLAB_API_URL || 'https://gitlab.com/api/v4',
        GITLAB_READ_ONLY_MODE: 'false',
        USE_GITLAB_WIKI: 'true'
      }
    }
  }),
  'Playwright-MCP': {
    type: 'stdio',
    command: process.platform === 'win32' ? 'npx.cmd' : 'npx',
    args: ['-y', '@playwright/mcp@latest', '--headless']
  }
};
const mcpConfig = JSON.stringify({ mcpServers });

const command = process.env.COPILOT_COMMAND || (process.platform === 'win32' ? 'copilot.cmd' : 'copilot');
const args = ['--prompt', prompt, '--allow-all', '--no-ask-user', '--stream=on', '--additional-mcp-config', mcpConfig];
const spawnCommand = process.platform === 'win32' ? (process.env.ComSpec || 'cmd.exe') : command;
const spawnArgs = process.platform === 'win32' ? ['/d', '/s', '/c', command, ...args] : args;
const childEnv = { ...process.env, ...(stage === 'scriptGeneration' ? { GENERATE_ONLY: '1', HEADLESS: '1' } : {}) };
const child = spawn(spawnCommand, spawnArgs, { cwd: process.cwd(), env: childEnv, stdio: ['ignore', 'pipe', 'pipe'] });
child.stdout.on('data', data => process.stdout.write(data));
child.stderr.on('data', data => process.stderr.write(data));
child.on('error', error => { process.stderr.write(`Failed to start Copilot CLI: ${error.message}\n`); process.exit(1); });
child.on('close', code => process.exit(code ?? 1));
