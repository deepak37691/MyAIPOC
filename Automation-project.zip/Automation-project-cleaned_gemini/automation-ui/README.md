# Automation Control Center

A local web UI that puts the existing QA agents behind explicit, user-controlled stages.

## Control model

1. Start GitLab MCP and Playwright MCP independently, or use **Start All**.
2. Enter a GitLab issue URL and create a session.
3. Start **Create Scenarios**.
4. Start **Test Strategy** only when you choose. Strategy pauses for approval.
5. Approve/reject the strategy in the UI.
6. Start **Squash TM Upload** only when you choose.
7. Start **Script Generation** only when you choose. It receives the Application URL.
8. Start **Test Execution** separately; the script-generation agent is now generation-only when `--generate-only` is used.
9. If tests fail, start **Test Healer**. Healing pauses for approval.
10. Prepare/approve **GitLab Commit** as the final controlled action.

## Agent bridge

The Markdown files under `.github/agents/` remain the source of truth for the agent instructions. The included `automation-ui/agent-runner.js` bridges the UI to GitHub Copilot CLI. Copy `.env.example` to `.env` and keep the default `AGENT_RUNNER_COMMAND=node ./automation-ui/agent-runner.js`, or configure stage-specific `AGENT_COMMAND_*` variables instead.

The command is invoked from the project root and receives environment variables:

- `ISSUE_ID`
- `ISSUE_URL`
- `FOLDER_ID`
- `APP_URL`
- `STAGE`
- `APPROVAL` (used only by approval-capable agents such as Test Healer; Test Strategy approval is handled entirely by the UI/backend)

This keeps the UI independent from whether the project uses VS Code agents, Copilot CLI, an internal agent runner, or another MCP-capable agent runtime.

The default runner requires GitHub Copilot CLI. Install it with `npm install -g @github/copilot`, authenticate with `copilot login`, and ensure the GitLab token has been entered in the UI before starting a GitLab-backed stage.

## Run

From the project root:

```bash
npm install
npm run ui:dev
```

Open `http://localhost:4173`.

For a compiled server:

```bash
npm run ui:build
npm run ui:start
```

## Security

- Do not put GitLab/Squash credentials into the browser.
- Keep `.env` local. Use `.env.example` as the template.
- MCP processes are started by the local backend, not by browser JavaScript.
- The commit stage preserves the existing exclusions for `test-results`, reports, `node_modules`, and `.env`.

### Runtime token security

The UI now has password-style fields for the GitLab MCP token and Squash bearer token. Clicking **Update Tokens** sends them to the local backend, which keeps them only in process memory. The values are not returned by the API, are not written to `.automation-ui/session.json`, and are not written to `.env`. The input fields are cleared after a successful update. The backend also strips legacy `GITLAB_PERSONAL_ACCESS_TOKEN` and `SQUASH_BEARER_TOKEN` values from the environment passed to agent/Playwright child processes; the GitLab MCP child receives only the current runtime token.

After restarting the UI server, enter the tokens again.

### Windows `spawn npx ENOENT` fix

On Windows the backend uses `npx.cmd` instead of `npx` when starting MCP servers. This avoids Node's `spawn npx ENOENT` error when `npx` is available through the npm Windows command shim.
