let session=null,poll=null,stageSignature='';
const labels={scenarios:'Test Scenarios',strategy:'Test Strategy',squash:'Squash Upload',scriptGeneration:'Test Script Generation',execution:'Test Execution',healer:'Test Healer',gitlabCommit:'GitLab Commit'};
const descriptions={scenarios:'Generate structured test scenarios from the GitLab issue.',strategy:'Review the automation scope and approve the selected test cases.',squash:'Upload the approved test cases to Squash.',scriptGeneration:'Generate Playwright data, page objects, and test scripts.',execution:'Select test cases, configure the run, and review results.',healer:'Review proposed fixes for failed test cases and approve the repair.',gitlabCommit:'Review the final changes and approve the GitLab commit.'};
const $=id=>document.getElementById(id);
const statusLabels={ready:'Ready',running:'Running',completed:'Completed',failed:'Failed',waiting_for_approval:'Needs approval'};
function stageStatusLabel(status){return statusLabels[status]||String(status||'').replaceAll('_',' ');}
function stageMessage(s,n){
  if(s?.status==='failed') return n==='healer'?'Repair application failed. Review the diagnostic details below and retry when ready.':'This stage failed. Review the details and retry when ready.';
  if(s?.status==='waiting_for_approval') return n==='healer'?'A healing proposal is ready for review.':'Review the proposed changes and approve to continue.';
  if(s?.status==='running') return n==='healer' ? ((s.output?.approvalStatus==='approved' || s.output?.proposalStatus==='approved') ? 'Applying the approved repair and validating the result…' : 'Preparing the healing proposal for your review…') : 'Stage is running. You can monitor progress in the Activity log.';
  if(s?.status==='completed') return 'Stage completed successfully.';
  return s?.message||'Ready to run.';
}

async function api(url,opt={}){const r=await fetch(url,{headers:{'Content-Type':'application/json'},...opt});const d=await r.json();if(!r.ok)throw new Error(d.error||'Request failed');return d}
async function saveTokens(){try{const g=$('gitlabToken').value.trim(),q=$('squashToken').value.trim();if(!g&&!q)throw new Error('Enter at least one token.');const d=await api('/api/secrets',{method:'POST',body:JSON.stringify({gitlabToken:g||undefined,squashToken:q||undefined})});$('gitlabToken').value='';$('squashToken').value='';renderSecrets(d)}catch(e){alert(e.message)}}
async function clearTokens(){try{const d=await api('/api/secrets/clear',{method:'POST',body:'{}'});$('gitlabToken').value='';$('squashToken').value='';renderSecrets(d);renderMcp(await api('/api/mcp/status'))}catch(e){alert(e.message)}}
async function refreshSecrets(){try{renderSecrets(await api('/api/secrets/status'))}catch{}}function renderSecrets(d){$('tokenStatus').textContent=d.gitlabConfigured&&d.squashConfigured?'GitLab configured • Squash configured':d.gitlabConfigured?'GitLab configured • Squash not configured':d.squashConfigured?'GitLab not configured • Squash configured':'Tokens not configured'}
async function mcp(kind,action){try{renderMcp(await api('/api/mcp/'+action,{method:'POST',body:JSON.stringify({kind})}))}catch(e){alert(e.message)}}
async function refreshMcp(){try{renderMcp(await api('/api/mcp/status'))}catch{}}function renderMcp(d){[['gitlab','GitLab'],['playwright','Playwright']].forEach(([k])=>{const el=$(k==='gitlab'?'gitlabStatus':'pwStatus');el.textContent=d[k]?'Running':'Stopped';el.className='dot '+(d[k]?'running':'stopped')});$('health').textContent=d.gitlab&&d.playwright?'MCP READY':'MCP NOT READY';$('health').className='health '+(d.gitlab&&d.playwright?'ok':'')}
async function createSession(){try{expandedStages.clear();stageSignature='';if(!issueUrl.value.trim())throw new Error('Enter a GitLab issue URL.');session=await api('/api/session',{method:'POST',body:JSON.stringify({issueUrl:issueUrl.value.trim(),folderId:folderId.value,appUrl:appUrl.value.trim()})});render();startPoll()}catch(e){alert(e.message)}}
function startPoll(){if(poll)clearInterval(poll);poll=setInterval(refresh,1000)}async function refresh(){if(!session)return;try{session=await api('/api/session/'+session.id);render()}catch(e){console.error(e)}}
function cleanCaseTitle(id,title){
  const caseId=String(id||'').trim().toUpperCase();
  const raw=String(title||'').trim();
  if(!raw) return '';
  const escaped=caseId.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  return raw.replace(new RegExp('^'+escaped+'(?:\\s*[-:|]\\s*|\\s+)?','i'),'').trim() || raw;
}
function testCases(){
  const catalog=session?.stages?.execution?.output?.catalog || [];
  return catalog.map(x=>{const id=String(x.id).toUpperCase();return {key:String(x.key),issueId:String(x.issueId),id,title:cleanCaseTitle(id,x.title||x.id),spec:x.spec}});
}
function strategyCases(){
  return session?.stages?.strategy?.output?.proposal?.strategies || session?.stages?.strategy?.output?.strategies || [];
}
function updateStrategySelectionCount(){
  const rows=strategyCases();
  const count=document.querySelectorAll('input[name="strategyCase"]:checked').length;
  const el=document.getElementById('strategySelectionCount');
  if(el) el.textContent=`${count} of ${rows.length} test cases selected for approval`;
  document.querySelectorAll('.strategy-case').forEach(label=>{
    const input=label.querySelector('input[name="strategyCase"]');
    label.classList.toggle('selected',!!input?.checked);
    label.classList.toggle('offload',!input?.checked);
  });
}
function renderStrategyReview(s){
  if(s.status!=='waiting_for_approval') return '';
  const rows=strategyCases();
  if(!rows.length) return '<div class="strategy-review empty-review"><strong>No test cases available.</strong><span>The Test Scenarios artifact did not contain any TC-* scenarios to review.</span></div>';
  const selected=rows.filter(x=>/^AUTOMATE/i.test(x.decision||''));
  return `<div class="strategy-review">
    <div class="review-head">
      <div><strong>Automation scope</strong><span id="strategySelectionCount">${selected.length} of ${rows.length} test cases selected for approval</span></div>
      <span class="review-badge">Review selection</span>
    </div>
    <div class="strategy-checks">
      ${rows.map(x=>{
        const isSelected=/^AUTOMATE/i.test(x.decision||'');
        return `<label class="strategy-case${isSelected?' selected':' offload'}">
          <input type="checkbox" name="strategyCase" value="${esc(x.id)}"${isSelected?' checked':''} onchange="updateStrategySelectionCount()">
          <span class="case-id">${esc(x.id)}</span>
          <span class="case-title">${esc(x.description)}</span>
          <span class="case-decision">${esc(x.decision)}</span>
          <span class="case-tier">${esc(x.tier)}</span>
        </label>`;
      }).join('')}
    </div>
    <div class="review-note">All test scenarios are shown. Only the Test Strategy Agent's recommended <strong>AUTOMATE (E2E)</strong> cases are checked initially. Change any checkbox to define exactly which cases you approve; only checked cases will be written to the final strategy.md.</div>
  </div>`;
}

async function startStage(n){try{let body={};if(n==='scriptGeneration')body.appUrl=$('appUrl').value.trim();if(n==='execution'){const checks=[...document.querySelectorAll('input[name="testcase"]:checked')].map(x=>x.value);if(!checks.length){alert('Select at least one test case before starting execution.');return}const workers=Number(document.getElementById('executionWorkers')?.value||'');if(!Number.isInteger(workers)||workers<1){alert('Workers must be a whole number greater than 0.');return}const headless=!!document.getElementById('executionHeadless')?.checked;body.testCases=[...new Set(checks.map(x=>String(x).trim().toUpperCase()).filter(Boolean))];body.workers=workers;body.headless=headless;}session=await api(`/api/session/${session.id}/stage/${n}/start`,{method:'POST',body:JSON.stringify(body)});render()}catch(e){alert(e.message);refresh()}}
async function stopStage(n){try{session=await api(`/api/session/${session.id}/stage/${n}/stop`,{method:'POST',body:'{}'});render()}catch(e){alert(e.message);refresh()}}
let approvalBusy=false;
const expandedStages=new Set();
function toggleStage(n){const card=document.querySelector(`.stage-card[data-stage="${n}"]`);if(!card)return;const open=card.classList.toggle('expanded');if(open)expandedStages.add(n);else expandedStages.delete(n);const body=card.querySelector('.stage-body');if(body)body.hidden=!open;const toggle=card.querySelector('.stage-toggle');if(toggle){toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'−':'+';toggle.setAttribute('aria-label',`${open?'Collapse':'Expand'} ${labels[n]}`);}}
async function approval(n,a){
  if(approvalBusy)return;
  let body={};
  if(n==='strategy'){
    body.includedTestCases=[...document.querySelectorAll('input[name="strategyCase"]:checked')].map(x=>x.value);
    if(a==='approve'&&!body.includedTestCases.length){alert('Select at least one test case before approving the strategy.');return}
  }
  const buttons=[...document.querySelectorAll('.approve-btn,.reject-btn')];
  approvalBusy=true;
  buttons.forEach(b=>{b.disabled=true;b.classList.add('busy');});
  if(a==='approve'&&n==='strategy'){const b=document.querySelector('.approve-btn');if(b)b.innerHTML='<span class="spinner"></span> Approving...'}
  try{
    session=await api(`/api/session/${session.id}/stage/${n}/${a}`,{method:'POST',body:JSON.stringify(body)});
    render();
  }catch(e){
    alert(e.message);
    await refresh();
  }finally{
    approvalBusy=false;
    // Do not re-enable a successfully approved action. If the API failed and the
    // stage is still waiting for approval, restore the controls for another try.
    if(session?.stages?.[n]?.status==='waiting_for_approval'){
      document.querySelectorAll('.approve-btn,.reject-btn').forEach(b=>{b.disabled=false;b.classList.remove('busy');});
      const b=document.querySelector('.approve-btn');if(b)b.innerHTML='<span>✓</span> Approve Strategy';
    }
  }
}
function reportLink(n,s){
  // The Playwright HTML report is the canonical preview for generated/executable
  // test work. Once execution has produced a report, let the Test Case Agent,
  // Script Generation, and Execution cards all open that same interactive report.
  const execution=session?.stages?.execution;
  const hasExecutionReport=!!(execution && ['completed','failed'].includes(execution.status) && execution.output?.reportUrl);
  const wantsPlaywrightReport=['scenarios','squash','scriptGeneration','execution'].includes(n);
  if(wantsPlaywrightReport && hasExecutionReport){
    return `<a class="preview" onclick="event.stopPropagation()" href="/api/session/${session.id}/report/execution" target="_blank" rel="noopener">Open Preview ↗</a>`;
  }
  const enabled=s.status==='completed';
  return enabled?`<a class="preview" onclick="event.stopPropagation()" href="/api/session/${session.id}/report/${n}" target="_blank" rel="noopener">Open Preview ↗</a>`:`<button class="preview disabled" disabled>Open Preview ↗</button>`;
}
function updateExecutionSelection(){
  const boxes=[...document.querySelectorAll('input[name="testcase"]')];
  const selected=boxes.filter(x=>x.checked).length;
  const all=boxes.length>0 && selected===boxes.length;
  const selectAll=document.getElementById('executionSelectAll');
  const start=document.getElementById('executionStart');
  const count=document.getElementById('executionSelectionCount');
  if(selectAll){selectAll.checked=all;selectAll.indeterminate=selected>0 && !all;}
  if(start) start.disabled=selected===0;
  if(count) count.textContent=`${selected} of ${boxes.length} selected`;
  document.querySelectorAll('.execution-case').forEach(label=>{
    const input=label.querySelector('input[name="testcase"]');
    label.classList.toggle('selected',!!input?.checked);
  });
}
function toggleAllExecutionCases(checked){
  document.querySelectorAll('input[name="testcase"]').forEach(input=>{input.checked=checked;});
  updateExecutionSelection();
}
function healerReview(s){
  if(!s || !['ready','waiting_for_approval','completed'].includes(s.status)) return '';
  const cases=s.output?.failedTestCases || [];
  if(!cases.length) return `<div class="healer-empty"><span class="hint">No failed or impacted test cases are currently queued. Run Test Execution and select a failing case to populate Test Healer.</span></div>`;
  const healerApproved=s.output?.approvalStatus==='approved' || s.output?.proposalStatus==='approved' || s.status==='completed';
  const proposal=s.output?.proposalHtml || (s.output?.proposalMarkdown ? `<pre class="healer-proposal-raw">${esc(s.output.proposalMarkdown)}</pre>` : '');
  const proposalBlock=proposal
    ? `<section class="healer-proposal"><div class="healer-proposal-head"><div><div class="mini-title">Healing Proposal</div><span class="hint">${healerApproved?'Approved by user. The healing proposal has been approved and the changes were applied.':'Review this diagnostic and proposed code change before approving.'}</span></div><span class="proposal-status ${healerApproved?'approved':''}">${healerApproved?'Approved':'Waiting for approval'}</span></div><div class="healer-proposal-body markdown-document">${proposal}</div></section>`
    : `<section class="healer-proposal missing"><div class="mini-title">Healing Proposal</div><span class="hint">The healer did not return a reviewable proposal yet. Approval is disabled until a proposal is available.</span></section>`;
  return `<div class="healer-review">
    <div class="mini-title">Failed / impacted test cases <span class="case-count">${cases.length}</span></div>
    <div class="healer-cases">${cases.map(x=>`<div class="healer-case"><div class="case-id-title"><span class="exec-case-id">${esc(x.id)}</span><span class="exec-case-title">${esc(cleanCaseTitle(x.id,x.title))}</span></div><div class="healer-case-meta">${esc(x.spec||'')}</div></div>`).join('')}</div>
    ${proposalBlock}
    <span class="hint">These cases were derived from the latest Playwright execution. The proposal above is the exact review artifact returned by Test Healer.</span>
  </div>`;
}

function executionResults(s){
  const results=Array.isArray(s.output?.executionCaseResults)?s.output.executionCaseResults:[];
  if(!results.length) return '';
  return `<section class="execution-results"><div class="mini-title">Latest execution results</div><div class="execution-result-list">${results.map(x=>{
    const failed=x.status==='failed';
    const detail=x.errorDetails?.length ? x.errorDetails.map((e,i)=>{
      const location=e.location?.file?`\nLocation: ${e.location.file}:${e.location.line||''}:${e.location.column||''}`:'';
      const message=e.message||'';
      const stack=e.stack&&e.stack!==message?`\n\n${e.stack}`:'';
      return `Error ${i+1}: ${message}${location}${stack}`;
    }).join('\n\n') : (x.error||'');
    const logId=`execution-log-${String(x.id||'').replace(/[^a-zA-Z0-9_-]/g,'-')}-${Math.random().toString(36).slice(2,7)}`;
    const logContent=detail?`<pre id="${logId}" class="execution-error-detail" hidden>${esc(detail)}</pre>`:'<div class="execution-result-ok">No error reported for this test case.</div>';
    const toggle=detail?`<button type="button" class="log-toggle" aria-expanded="false" onclick="toggleExecutionLog('${logId}',this)">Show log</button>`:'';
    return `<article class="execution-result ${failed?'failed':'passed'}"><div class="execution-result-head"><div class="case-id-title"><span class="exec-case-id">${esc(x.id)}</span><span class="exec-case-title">${esc(cleanCaseTitle(x.id,x.title))}</span></div><div class="execution-result-actions">${toggle}<span class="execution-result-status">${failed?'Failed':'Passed'}</span></div></div>${logContent}</article>`;
  }).join('')}</div></section>`;
}

function executionCaseStatusLabel(status){
  return ({running:'Running',completed:'Completed',failed:'Failed',not_started:'Not Started',not_run:'Not Run'}[status]||'Not Started');
}
function executionSelector(s){
  // Keep the full catalog visible during and after execution so each test case has
  // an explicit lifecycle state. Inputs are locked while a run is active.
  if(!['running','ready','failed','completed'].includes(s.status)) return '';
  const cases=testCases();
  if(!cases.length) return '<div class="execution-select disabled"><div class="mini-title">Project test cases</div><span class="hint">No executable Playwright test cases were found in the project tests folder.</span></div>';
  const groups={};
  cases.forEach(x=>{(groups[x.issueId] ||= []).push(x)});
  const issueIds=Object.keys(groups).sort((a,b)=>Number(a)-Number(b));
  const total=cases.length;
  const statusByKey=new Map((s.output?.executionCaseStatuses||[]).map(x=>[x.key,x.status]));
  const running=s.status==='running';
  const selectedKeys=s.output?.selectedTestCases||[];
  return `<div class="execution-select">
    <div class="execution-select-head"><div><div class="mini-title">Project test cases <span class="case-count">${total}</span></div><span id="executionSelectionCount" class="selection-count">0 of ${total} selected</span></div><div class="execution-options"><label class="execution-option">Workers<input id="executionWorkers" type="number" min="1" step="1" value="${esc(s.output?.workers||8)}" ${running?'disabled':''}></label><label class="execution-option checkbox-option"><input id="executionHeadless" type="checkbox" ${s.output?.headless!==false?'checked':''} ${running?'disabled':''}><span>Headless</span></label><label class="select-all"><input id="executionSelectAll" type="checkbox" onchange="toggleAllExecutionCases(this.checked)" ${running?'disabled':''}><span>Select All</span></label></div></div>
    <div class="execution-checks issue-groups">${issueIds.map(issueId=>`<section class="execution-issue-group"><div class="execution-issue-title">Issue #${esc(issueId)} <span>${groups[issueId].length} test case${groups[issueId].length===1?'':'s'}</span></div>${groups[issueId].map(x=>{const st=statusByKey.get(x.key)||((selectedKeys.includes(x.key))?'running':(s.output?.executionCaseStatuses?'not_run':'not_started'));return `<label class="execution-case case-status-${esc(st)}" title="${esc(x.title)}"><input type="checkbox" name="testcase" value="${esc(x.key)}" ${selectedKeys.includes(x.key)?'checked':''} ${running?'disabled':''} onchange="updateExecutionSelection()"><span class="exec-case-id">${esc(x.id)}</span><span class="exec-case-title">${esc(x.title)}</span><span class="execution-case-status">${executionCaseStatusLabel(st)}</span></label>`}).join('')}</section>`).join('')}</div>
    <span class="hint">Selected cases show Running while Playwright is executing, then Completed or Failed. Cases not selected are shown as Not Started before any run and Not Run after an execution.</span>
  </div>`;
}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function render(){
  if(!session)return;
  $('sessionBadge').textContent=`Issue #${session.issueId}`;
  $('sessionInfo').innerHTML=`<span>Session ${esc(session.id)}</span><span>Issue #${esc(session.issueId)}</span><span>Folder ${esc(session.folderId)}</span>`;
  const sig=JSON.stringify(Object.entries(session.stages).map(([n,s])=>[n,s.status,s.message,s.error,!!s.output,n==='strategy'?strategyCases().length:0,n==='scriptGeneration'?JSON.stringify(s.output?.executionCases||s.output?.testCases||[]):'',n==='execution'?JSON.stringify({catalog:s.output?.catalog||[],selected:s.output?.selectedTestCases||[],results:s.output?.executionCaseResults||[],caseStatuses:s.output?.executionCaseStatuses||[]}):n==='healer'?JSON.stringify({cases:s.output?.failedTestCases||[],proposal:s.output?.proposalMarkdown||s.output?.proposal||'',status:s.status}):'']));
  if(sig!==stageSignature){
    stageSignature=sig;
    const box=$('stages'); box.innerHTML='';
    Object.entries(session.stages).forEach(([n,s],i)=>{
      let controls='';
      if(s.status==='running') {
        controls+=`<button class="primary small stop-btn" onclick="event.stopPropagation();stopStage('${n}')">Stop stage</button>`;
      } else if(['ready','failed','completed'].includes(s.status)) controls+=n==='execution'
        ?`<button id="executionStart" class="primary small" disabled onclick="event.stopPropagation();startStage('execution')">Run selected tests</button>`
        :`<button class="primary small" onclick="event.stopPropagation();startStage('${n}')">${s.status==='failed'?'Retry stage':'Run stage'}</button>`;
      if(s.status==='waiting_for_approval'){
        const label=n==='strategy'?'Approve Strategy':'Approve repair';
        const healerReady=n==='healer' ? !!(s.output?.proposalMarkdown || s.output?.proposal || s.output?.proposalHtml) : true;
        controls+=`<div class="approval-actions" onclick="event.stopPropagation()"><button class="approve-btn" ${healerReady?'':'disabled title="A reviewable healing proposal is required before approval"'} onclick="approval('${n}','approve')"><span>✓</span>${label}</button><button class="reject-btn" onclick="approval('${n}','reject')">Reject</button></div>`;
      } else if(n==='strategy' && s.status==='completed'){
        const count=s.output?.includedTestCases?.length ?? s.output?.proposal?.strategies?.length ?? 0;
        controls+=`<div class="approval-actions" onclick="event.stopPropagation()"><button class="approve-btn" disabled title="Strategy already approved"><span>✓</span> Strategy Approved (${count})</button></div>`;
      }
      const isExpanded=expandedStages.has(n);
      const headerControls=`<div class="stage-header-actions"><span class="status ${s.status}">${stageStatusLabel(s.status)}</span>${reportLink(n,s)}${controls}<button class="stage-toggle" type="button" aria-label="${isExpanded?'Collapse':'Expand'} ${esc(labels[n])}" aria-expanded="${isExpanded}" onclick="event.stopPropagation();toggleStage('${n}')">${isExpanded?'−':'+'}</button></div>`;
      box.insertAdjacentHTML('beforeend',`
        <article class="stage-card${isExpanded?' expanded':''}" data-stage="${n}">
          <div class="stage-header" onclick="toggleStage('${n}')">
            <div class="stage-index">${String(i+1).padStart(2,'0')}</div>
            <div class="stage-summary">
              <div class="stage-top"><div><h3>${labels[n]}</h3><p>${descriptions[n]}</p></div></div>
            </div>
            ${headerControls}
          </div>
          <div class="stage-body"${isExpanded?'':' hidden'}>
            <div class="stage-bottom"><span>${esc(stageMessage(s,n))}</span></div>
            ${n==='strategy'?renderStrategyReview(s):''}${n==='execution'?executionSelector(s)+executionResults(s):''}${n==='healer'?healerReview(s):''}${n==='healer'&&s.status==='failed'?`<details class="technical-details"><summary>View technical diagnostic</summary><pre class="healer-proposal-raw">${esc(s.error||s.message||'No diagnostic details available.')}</pre></details>`:''}
          </div>
        </article>`);
    });
    if(document.querySelector('input[name="testcase"]')) updateExecutionSelection();
  }
  renderEvents();
}

function renderEvents(){const el=$('events');if(!el)return;const wasNearBottom=el.scrollHeight-el.scrollTop-el.clientHeight<28;const events=session?.events||[];el.textContent=events.map(e=>{const time=new Date(e.at).toLocaleTimeString();const stream=e.type?.startsWith('backend.')?` ${e.type.replace('backend.','').toUpperCase()}:`:'';return `${time}${e.stage?` [${e.stage}]`:''}${stream} ${e.message}`}).join('\n');if(wasNearBottom)el.scrollTop=el.scrollHeight}
function toggleExecutionLog(id,button){const el=$(id);if(!el)return;const opening=el.hidden;el.hidden=!opening;button.textContent=opening?'Hide log':'Show log';button.setAttribute('aria-expanded',String(opening));}
function clearLogsView(){$('events').textContent=''}function selectLogs(){const r=document.createRange();r.selectNodeContents($('events'));const s=getSelection();s.removeAllRanges();s.addRange(r)}async function copyLogs(){selectLogs();try{await navigator.clipboard.writeText($('events').textContent||'')}catch{document.execCommand('copy')}}
refreshMcp();refreshSecrets();setInterval(refreshMcp,1500);setInterval(refreshSecrets,1500);
