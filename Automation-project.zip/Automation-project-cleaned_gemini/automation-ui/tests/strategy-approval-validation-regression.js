const assert = require('assert');
function parsePipeRow(line) {
  if (!/^\s*\|/.test(line)) return null;
  const body = line.replace(/^\s*\|/, '').replace(/\|\s*$/, '');
  return body.split('|').map(x => x.replace(/[\*_`]/g, '').trim());
}
function extractDecisionMatrixIds(text) {
  const lines = text.replace(/\r/g, '').split('\n');
  const start = lines.findIndex(x => /^##\s+1\.\s+Scope\s*&\s*Automation\s+Decision\s+Matrix/i.test(x));
  const end = lines.findIndex((x, i) => i > start && /^##\s+2\./.test(x));
  assert(start >= 0 && end >= 0);
  return lines.slice(start + 1, end)
    .map(parsePipeRow)
    .filter(c => c && /^TC-\d+$/i.test(c[0] || ''))
    .map(c => c[0].toUpperCase())
    .sort();
}
const md = `## 1. Scope & Automation Decision Matrix
| Scenario ID | Description | Decision |
|---|---|---|
| **TC-001** | One | **AUTOMATE (E2E)** |
| **TC-004** | Four | **AUTOMATE (E2E)** |

## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)
### Approved Test Cases
| **TC-001** | One |
| **TC-004** | Four |
### Candidate 1: TC-001 - One
### Candidate 2: TC-004 - Four
`;
assert.deepStrictEqual(extractDecisionMatrixIds(md), ['TC-001', 'TC-004']);
assert.strictEqual(extractDecisionMatrixIds(md).length, 2);
console.log('Strategy approval validation regression passed.');
