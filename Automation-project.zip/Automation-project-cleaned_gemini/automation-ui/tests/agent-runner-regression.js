const fs = require('node:fs');
const path = require('node:path');
const runner = fs.readFileSync(path.join(__dirname, 'agent-runner.js'), 'utf8');
const checks = [
  ['Windows command line quotes every Copilot argument', /\[command, \.\.\.args\]\.map\(quoteWindowsArg\)\.join\(' '\)/.test(runner)],
  ['Prompt is passed as one --prompt argument', /const args = \['--prompt', prompt,/.test(runner)],
  ['Script generation explicitly forbids Playwright execution', /DO NOT run any Playwright test command/.test(runner)],
  ['Script generation does not append a headed CLI flag', !/stage === 'scriptGeneration'.*args\.push\('--headed'\)/s.test(runner)],
];
const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  console.error(failed.map(([name]) => `FAIL: ${name}`).join('\n'));
  process.exit(1);
}
console.log('Agent runner regression checks passed.');
