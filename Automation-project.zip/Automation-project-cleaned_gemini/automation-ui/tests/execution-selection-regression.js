const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const app = fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8');
const server = fs.readFileSync(path.join(root, 'dist', 'server.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'public', 'app.css'), 'utf8');

const checks = [
  ['execution list renders test-case checkboxes', app.includes('name="testcase" value="${esc(x.id)}"')],
  ['Select All control exists', /id="executionSelectAll"/.test(app) && /Select All/.test(app)],
  ['selection counter exists', /executionSelectionCount/.test(app)],
  ['Start is disabled until selection', /id="executionStart" class="primary small" disabled/.test(app)],
  ['UI sends selected test cases only', /body\.testCases=\[\.\.\.new Set/.test(app)],
  ['backend deduplicates selected ids', /new Set\(b\.testCases\.filter/.test(server)],
  ['backend rejects empty execution selection', /Select at least one test case before starting execution\./.test(server)],
  ['execution selector styling exists', /\.execution-checks\{/.test(css) && /\.select-all\{/.test(css)],
  ['execution list prefers generated execution cases', app.includes('scriptGeneration?.output?.executionCases') && app.includes('scriptGeneration?.output?.testCases')],
  ['execution list does not require strategy completion', !/if\(s\.stages\?\.strategy\?\.status!==['\"]completed['\"]\)/.test(app)],
  ['server execution cases can use generated artifacts without strategy', server.includes('Script Generation is the source of truth') && server.includes('generatedExecutionCases(s)')],
  ['generated spec parser includes test and it declarations', server.includes('(?:test|it)\\s*\\(')],
  ['server builds execution cases from generated artifacts', server.includes('function executionCases(s)') && server.includes('test-data/issue-${s.issueId}.json')],
  ['session refresh backfills execution cases', server.includes('s.stages.scriptGeneration.status') && server.includes('const currentCases = executionCases(s)')],
  ['execution heading uses requested label', /Test cases to be executed/.test(app)],
  ['execution empty-state mentions Script Generation', /Test cases will appear here after Script Generation\./.test(app)],
];
const failed = checks.filter(([, ok]) => !ok);
if (failed.length) {
  console.error(failed.map(([name]) => `FAIL: ${name}`).join('\n'));
  process.exit(1);
}
console.log('Execution selection regression checks passed.');
