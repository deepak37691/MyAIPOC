// Lightweight regression checks for the strategy approval contract.
const assert = (condition, message) => { if (!condition) throw new Error(message); };

function rewrite(source, selectedIds) {
  const selected = [...new Set(selectedIds.map(x => String(x).trim().toUpperCase()))];
  const lines = source.replace(/\r/g, '').split('\n');
  const selectedSet = new Set(selected);
  const matrixStart = lines.findIndex(x => /^##\s+1\.\s+Scope\s*&\s*Automation\s+Decision\s+Matrix/i.test(x));
  const section2Start = lines.findIndex(x => /^##\s+2\.\s+Selected\s+E2E\s+Scenarios/i.test(x));
  const section3Start = lines.findIndex((x, i) => i > Math.max(matrixStart, section2Start) && /^##\s+3\./.test(x));
  assert(matrixStart >= 0 && section2Start >= 0, 'Expected strategy sections are missing');

  const before = lines.slice(0, matrixStart);
  const matrix = lines.slice(matrixStart, section2Start);
  const filteredMatrix = [];
  for (const line of matrix) {
    const tc = line.match(/^\s*\|\s*\*\*(TC-\d+)\*\*/i);
    if (tc) {
      if (selectedSet.has(tc[1].toUpperCase())) filteredMatrix.push(line);
      continue;
    }
    if (/\*\*Approved for E2E Automation\*\*\s*:/i.test(line)) {
      filteredMatrix.push(line.replace(/(\*\*Approved for E2E Automation\*\*\s*:\s*)\d+/i, `$1${selected.length}`));
      continue;
    }
    filteredMatrix.push(line);
  }

  const candidateEnd = section3Start >= 0 ? section3Start : lines.length;
  const selectedSection = lines.slice(section2Start, candidateEnd);
  const kept = [];
  let keep = false;
  for (const line of selectedSection) {
    const heading = line.match(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)\b/i);
    if (heading) keep = selectedSet.has(heading[1].toUpperCase());
    if (/^##\s+2\./i.test(line)) { kept.push(line); continue; }
    if (keep) kept.push(line);
  }
  const after = section3Start >= 0 ? lines.slice(section3Start) : [];
  return [...before, ...filteredMatrix, '', '## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)', '', ...kept.slice(1), ...after]
    .join('\n')
    .replace(/(\*\*Approved for E2E Automation\*\*\s*:\s*)\d+/i, `$1${selected.length}`)
    .replace(/\n{4,}/g, '\n\n\n');
}

const source = `# E2E Test Strategy Proposal: Issue #3

- **Approved for E2E Automation**: 2

## 1. Scope & Automation Decision Matrix

| Scenario ID | Scenario Description | Automation Decision | Tier / Frequency | Justification |
| :--- | :--- | :--- | :--- | :--- |
| **TC-001** | One | **AUTOMATE (E2E)** | Smoke | One |
| **TC-002** | Two | **OFFLOAD (Unit/API)** | Unit | Two |
| **TC-003** | Three | **AUTOMATE (E2E)** | Smoke | Three |

## 2. Selected E2E Scenarios (Squash TM & Script Generator Inputs)

### Candidate 1: TC-001 - One
- **Reference**: TC-001

### Candidate 2: TC-003 - Three
- **Reference**: TC-003

## 3. Environment & Mocking Strategy
- **Base URL**: https://example.test/
`;

const one = rewrite(source, ['TC-001']);
assert([...one.matchAll(/^\|\s*\*\*(TC-\d+)\*\*/gmi)].map(m => m[1]).join(',') === 'TC-001', 'One-selection matrix mismatch');
assert([...one.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)/gmi)].map(m => m[1]).join(',') === 'TC-001', 'One-selection candidates mismatch');
assert(one.includes('**Approved for E2E Automation**: 1'), 'One-selection count mismatch');

// The final strategy intentionally repeats approved TC IDs in the separate
// 'Approved Test Cases' table. Validation must scope matrix IDs to section 1,
// otherwise approving one case produces a false duplicate such as TC-001, TC-001.
const finalWithRepeatedApprovedTable = one.replace(
  '## 3. Environment & Mocking Strategy',
  '### Approved Test Cases\n\n| Scenario ID | Test Case | Priority | Decision | Tier / Frequency |\n| :--- | :--- | :--- | :--- | :--- |\n| **TC-001** | One | P0 | **AUTOMATE (E2E)** | Smoke |\n\n## 3. Environment & Mocking Strategy'
);
function validateScoped(text, selectedIds) {
  const selected = [...new Set(selectedIds.map(x => x.toUpperCase()))].sort();
  const lines = text.replace(/\r/g, '').split('\n');
  const matrixStart = lines.findIndex(x => /^##\s+1\.\s+Scope\s*&\s*Automation\s+Decision\s+Matrix/i.test(x));
  const section2Start = lines.findIndex((x, i) => i > matrixStart && /^##\s+2\.\s+Selected\s+E2E\s+Scenarios/i.test(x));
  assert(matrixStart >= 0 && section2Start >= 0, 'Validation sections are missing');
  const matrixText = lines.slice(matrixStart, section2Start).join('\n');
  const matrixIds = [...matrixText.matchAll(/^\|\s*\*\*(TC-\d+)\*\*/gmi)].map(m => m[1].toUpperCase()).sort();
  assert(matrixIds.length === selected.length && matrixIds.every((id, i) => id === selected[i]), `Scoped validation failed: ${matrixIds.join(',')}`);
}
validateScoped(finalWithRepeatedApprovedTable, ['TC-001']);

const sixSource = source.replace(
  '| **TC-003** | Three | **AUTOMATE (E2E)** | Smoke | Three |',
  '| **TC-003** | Three | **AUTOMATE (E2E)** | Smoke | Three |\n| **TC-004** | Four | **AUTOMATE (E2E)** | Smoke | Four |\n| **TC-005** | Five | **AUTOMATE (E2E)** | Smoke | Five |\n| **TC-006** | Six | **AUTOMATE (E2E)** | Smoke | Six |'
).replace(
  '### Candidate 2: TC-003 - Three\n- **Reference**: TC-003',
  '### Candidate 2: TC-003 - Three\n- **Reference**: TC-003\n\n### Candidate 3: TC-004 - Four\n- **Reference**: TC-004\n\n### Candidate 4: TC-005 - Five\n- **Reference**: TC-005\n\n### Candidate 5: TC-006 - Six\n- **Reference**: TC-006'
);
const six = rewrite(sixSource, ['TC-001','TC-002','TC-003','TC-004','TC-005','TC-006']);
assert([...six.matchAll(/^\|\s*\*\*(TC-\d+)\*\*/gmi)].map(m => m[1]).length === 6, 'Six-selection matrix count mismatch');
assert([...six.matchAll(/^###\s+Candidate\s+\d+\s*:\s*(TC-\d+)/gmi)].map(m => m[1]).length === 5, 'Only candidates that existed in proposal should remain');
assert(six.includes('**Approved for E2E Automation**: 6'), 'Six-selection count mismatch');

console.log('Strategy approval regression checks passed.');
