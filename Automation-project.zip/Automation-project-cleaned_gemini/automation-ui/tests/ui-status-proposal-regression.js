const fs=require('node:fs'),path=require('node:path');
const app=fs.readFileSync(path.join(__dirname,'public','app.js'),'utf8');
const server=fs.readFileSync(path.join(__dirname,'dist','server.js'),'utf8');
const checks=[
 ['execution renders persisted per-case status panel',app.includes('case-status-panel')&&app.includes('s.output?.testCaseStatuses')],
 ['running execution remains visible',app.includes("if(stage.status!=='ready' && stage.status!=='failed') return statusPanel")],
 ['failure reason is rendered',app.includes('Why it failed:')],
 ['healer keeps selected cases visible while running',app.includes('Test cases being healed')],
 ['healer has per-case approve/reject actions',app.includes("healerProposalAction('${esc(id)}','approve')")&&app.includes("healerProposalAction('${esc(id)}','reject')")],
 ['missing healer proposal still shows its test case',app.includes('No proposal returned for this test case.')],
 ['server initializes execution cases as running',/status:"running"|status:'running'/.test(server) && /testCaseStatuses/.test(server)],
 ['server captures Playwright failure reason',server.includes('errorText')&&server.includes('Playwright assertion or execution error')],
 ['per-case healer endpoint exists',server.includes('healer/proposal')],
 ['Playwright report preview is enabled for failed execution',app.includes("['completed','failed'].includes(s.status)")],
 ['stop endpoint remains available',server.includes('stage/([^/]+)/stop')],
];
const bad=checks.filter(x=>!x[1]); if(bad.length){console.error(bad.map(x=>'FAIL: '+x[0]).join('\n'));process.exit(1)} console.log('UI status/proposal regression checks passed.');
