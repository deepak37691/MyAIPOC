const fs=require('node:fs'),path=require('node:path');
const root=__dirname;
const app=fs.readFileSync(path.join(root,'public','app.js'),'utf8');
const server=fs.readFileSync(path.join(root,'dist','server.js'),'utf8');
const runner=fs.readFileSync(path.join(root,'agent-runner.js'),'utf8');
const agent=fs.readFileSync(path.join(root,'..','.github','agents','test-healer-agent.md'),'utf8');
const checks=[
 ['Per-case healer proposal UI',/healerProposalAction\(testCaseId, action\)/.test(app)&&/case-proposal-actions/.test(app)],
 ['Per-case approve/reject endpoints',server.includes('healerProposalAction')&&server.includes('approval.rejected')],
 ['Exact proposal passed on approval',/HEALING_PROPOSAL: exactProposal/.test(server)],
 ['Verification runs once',/verifyHealedTestCase/.test(server)&&/--workers=1/.test(server)&&/--retries=0/.test(server)],
 ['Healer result persisted per case',/caseResults/.test(server)&&/verificationStatus/.test(app)],
 ['Execution status updated after healing',/updateExecutionCaseAfterHealing/.test(server)&&/All healed test cases are now passed/.test(server)],
 ['Playwright report route serves index',/report\/execution/.test(server)&&server.includes("serveReportFile(res, executionReportDir, 'index.html')") || server.includes("serveReportFile(res,executionReportDir,'index.html')")],
 ['No generic healer approval',/Use the per-test-case healer proposal actions/.test(server)],
 ['Approved healer gets exact-only instruction',runner.includes('EXACTLY this one machine-readable proposal')&&agent.includes('Apply **only** the exact proposal')],
];
const bad=checks.filter(([,ok])=>!ok);if(bad.length){console.error(bad.map(x=>'FAIL: '+x[0]).join('\n'));process.exit(1)}console.log('Per-case healer regression checks passed.');
