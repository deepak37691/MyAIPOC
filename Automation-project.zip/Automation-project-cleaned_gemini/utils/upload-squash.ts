import 'dotenv/config'; // Automatically reads variables from the .env file
import { request, APIRequestContext } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

interface TestCaseStep {
  _type: string;
  action: string;
  expected_result: string;
}

interface TestCasePayload {
  _type: string;
  name: string;
  reference: string;
  prerequisite?: string;
  description?: string;
  importance: 'LOW' | 'MEDIUM' | 'HIGH' | 'VERY_HIGH';
  status: string;
  parent: {
    _type: string;
    id: number;
  };
  steps?: TestCaseStep[];
}

async function uploadSquashTestCases() {
  const args = process.argv.slice(2);
  const jsonFilePath = args[0];

  if (!jsonFilePath) {
    console.error('❌ Error: Please provide the path to the generated JSON payload file.');
    console.log('Usage: npx ts-node utils/upload-squash.ts test-scenarios/squash/testcase_<ISSUE_ID>.json');
    process.exit(1);
  }

  // Pick token from command args OR environment variables (.env file)
  const bearerToken = args[1] || process.env.SQUASH_BEARER_TOKEN || '';
  const baseUrl = process.env.SQUASH_BASE_URL || 'http://localhost:8080/squash/api/rest/latest/test-cases';

  if (!bearerToken) {
    console.error('❌ Error: SQUASH_BEARER_TOKEN is missing in your .env file.');
    process.exit(1);
  }

  const resolvedPath = path.resolve(jsonFilePath);
  if (!fs.existsSync(resolvedPath)) {
    console.error(`❌ Error: JSON payload file not found at path: ${resolvedPath}`);
    process.exit(1);
  }

  const rawData = fs.readFileSync(resolvedPath, 'utf-8');
  const testCases: TestCasePayload[] = JSON.parse(rawData);

  console.log(`🚀 Found ${testCases.length} test case(s) in ${path.basename(jsonFilePath)}`);
  console.log(`🌐 Target Endpoint: ${baseUrl}\n`);

  const apiContext: APIRequestContext = await request.newContext({
    extraHTTPHeaders: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${bearerToken}`
    }
  });

  let successCount = 0;
  let failureCount = 0;

  for (let i = 0; i < testCases.length; i++) {
    const payload = testCases[i];
    const ref = payload.reference || `Index-${i + 1}`;
    console.log(`[${i + 1}/${testCases.length}] Uploading ${ref}: "${payload.name}"...`);

    try {
      const response = await apiContext.post(baseUrl, { data: payload });

      if (response.status() === 200 || response.status() === 201) {
        const responseData = await response.json();
        console.log(`  ✅ Successfully created ${ref} (Squash ID: ${responseData.id || 'N/A'})`);
        successCount++;
      } else {
        console.error(`  ❌ Failed to upload ${ref}. Status Code: ${response.status()}`);
        console.error(`     Response: ${await response.text()}`);
        failureCount++;
      }
    } catch (err) {
      console.error(`  💥 Exception while uploading ${ref}:`, err);
      failureCount++;
    }
  }

  await apiContext.dispose();

  console.log('\n========================================');
  console.log(`📊 Upload Summary: ${successCount} Successful | ${failureCount} Failed`);
  console.log('========================================');

  if (failureCount > 0) process.exit(1);
}

uploadSquashTestCases();